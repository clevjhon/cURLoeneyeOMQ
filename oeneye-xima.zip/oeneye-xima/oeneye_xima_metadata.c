/*
 * oeneye_xima_metadata.c — embeds a plain identifying token string into a
 * .xima intermediate-file metadata block.
 *
 * This is a build/provenance tag writer, not a reasoning or AGI component:
 * it copies a bounded string into a caller-owned buffer and reports
 * success/failure. Nothing more.
 */
#include <string.h>
#include <stddef.h>

/*@
  // Preconditions: Ensure the target buffer is safely allocated and
  // the token identifier is readable.
  requires valid_buffer: \valid(xima_buffer + (0 .. buffer_size - 1));
  requires non_zero_size: buffer_size > 0;
  requires valid_token: \valid_read(token_id);

  // Frame condition: Restrict buffer modifications strictly to the allocated size.
  assigns xima_buffer[0 .. buffer_size - 1];

  // Postconditions: Returns 0 on success or a negative error code on failure.
  ensures \result == 0 || \result == -1;
*/
int embed_xima_metadata_block(char *xima_buffer, size_t buffer_size, const char *token_id)
{
    size_t token_len = strlen(token_id);

    /* Reserve 1 byte for the NUL terminator. If the token (plus NUL)
     * doesn't fit, fail cleanly rather than truncate silently — a
     * truncated provenance tag is worse than a rejected one. */
    if (token_len >= buffer_size) {
        return -1;
    }

    /* Zero the whole buffer first so any bytes past the token are a
     * known, deterministic value (0x00) rather than leftover stack/heap
     * data — relevant since this buffer may be flushed to disk as part
     * of a .xima file. */
    memset(xima_buffer, 0, buffer_size);
    memcpy(xima_buffer, token_id, token_len);
    /* xima_buffer[token_len] is already 0 from the memset above. */

    return 0;
}
