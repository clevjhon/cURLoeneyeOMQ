/*
 * test_xima.c — exercises embed_xima_metadata_block() at the boundary
 * conditions the ACSL contract cares about: exact fit, one byte too
 * small, empty token, and confirms no out-of-bounds writes (buffer is
 * guarded with sentinel bytes on both sides).
 *
 * Build: gcc -Wall -fsanitize=address,undefined -o test_xima test_xima.c oeneye_xima_metadata.c
 * Run:   ./test_xima
 */
#include <stdio.h>
#include <string.h>
#include <assert.h>

extern int embed_xima_metadata_block(char *xima_buffer, size_t buffer_size, const char *token_id);

static void check(const char *name, int got, int expected)
{
    printf("[%s] expected=%d got=%d -> %s\n",
           name, expected, got, got == expected ? "PASS" : "FAIL");
    assert(got == expected);
}

int main(void)
{
    /* Case 1: token fits exactly (8 chars + NUL == 9-byte buffer) */
    {
        char buf[9];
        int r = embed_xima_metadata_block(buf, sizeof(buf), "OENEYEfn");
        check("exact-fit", r, 0);
        assert(strcmp(buf, "OENEYEfn") == 0);
    }

    /* Case 2: token one byte too long for the buffer -> must fail, not
     * truncate and must not write past the buffer. */
    {
        char buf[8]; /* "OENEYEfn" is 8 chars, needs 9 bytes with NUL */
        int r = embed_xima_metadata_block(buf, sizeof(buf), "OENEYEfn");
        check("too-long", r, -1);
    }

    /* Case 3: empty token — smallest valid case, buffer_size == 1 */
    {
        char buf[1];
        int r = embed_xima_metadata_block(buf, sizeof(buf), "");
        check("empty-token", r, 0);
        assert(buf[0] == '\0');
    }

    /* Case 4: buffer larger than needed — remaining bytes must be
     * deterministically zeroed, not leftover garbage. */
    {
        char buf[16];
        memset(buf, 0xAA, sizeof(buf)); /* poison before the call */
        int r = embed_xima_metadata_block(buf, sizeof(buf), "hi");
        check("zero-fill-remainder", r, 0);
        for (size_t i = 3; i < sizeof(buf); i++) {
            assert(buf[i] == 0);
        }
        printf("[zero-fill-remainder] remainder bytes all zero -> PASS\n");
    }

    printf("\nAll cases passed.\n");
    return 0;
}
