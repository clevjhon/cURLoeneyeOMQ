# oeneye OS Artwork – Locked Bundle (ReFS Style)

**oeneye OS - ReFS Secure Filesystem - Locked Bundle**

Version: 1.0  
Status: Secure • Read-Only • Integrity Verified  
Secure Boot: ENABLED

This is the official locked artwork package for oeneye OS.

## Bundle Contents
- Logos & branding assets
- Infinity Loader 8-frame concept sheets & pixel animations
- Custom mouse cursors (32×32 / 64×64 pixel art)
- BIOS / VBR boot visuals
- Animated video assets (glowing infinity eyes, pixel loaders)

## Color Palette
- Dark Navy `#0A2F5A`
- Light Blue `#2399FF`

## Security Notes
- Bundle is locked and read-only
- Designed for Secure Boot environments
- Compatible with ReFS locked bundle workflow
- All assets integrity-checked

oeneye OS – ReFS – Secure Filesystem – Locked Bundle
