# oeneye OS Artwork – Master Package v1.1

**oeneye OS – ReFS Secure Filesystem – Locked Bundle**

Secure • Read-Only Ready • Secure Boot Enabled

## Package contents

### clean_png/
- `oeneye_logo_512_transparent.png` / `_white.png` – primary logo
- `oeneye_logo_256.png` … `oeneye_logo_32.png` – standard sizes
- Boot screen, cursor sheets, loader concept sheet
- Source frames from the official animations

### clean_ico/
- `oeneye_logo.ico` – multi-resolution icon / favicon
- `oeneye_infinity.ico` – alternative

### animated/
- `glowing_infinity.gif` – main logo animation
- `pixel_loader_dark.gif` / `pixel_loader_white.gif` – busy indicators

### packages/
- ReFS-style locked ZIP
- FAT32 disk image (`.img`, volume label `OENEYEART`)
- Full original locked-bundle folder structure

### docs/
- This README
- `preview.html` – open in a browser to see the assets

## Color palette
- Dark Navy `#0A2F5A`
- Light Blue `#2399FF`

## How to use
1. Write the `.img` to USB/SD for FAT media.
2. Use the locked ZIP inside ReFS / secure bundle workflows.
3. Drop the clean PNGs, ICO and GIFs into UI, websites, boot screens or documentation.

oeneye OS – ReFS – Secure Filesystem – Locked Bundle
