REAL ReFS CANNOT BE CREATED ON LINUX.
This archive contains the oeneye content that would go into a ReFS volume.
Use the NTFS image (oeneye-ntfs.img) instead - it has a real Master File Table (MFT).
