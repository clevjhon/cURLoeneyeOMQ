MOSFETQ DOS 0.4-rc1
===================

Release candidate adding write support foundation + DEL command
to the original MOSFETQ DOS 0.3 (Zenodo 10.5281/zenodo.22845198).

What is new
-----------
- write_sector / write_sectors
- fat_get / fat_set  (updates both FAT copies on disk)
- find_free_cluster
- free_chain
- DEL filename   command (deletes file and frees its clusters)

Still read-only for creation / writing file contents.
Full file write path is the natural next step.

Build
-----
  as --32 -o mosfetq-dos.o mosfetq-dos.s
  ld -m elf_i386 -Ttext=0x7C00 --oformat binary -o mosfetq-dos.bin mosfetq-dos.o
  python3 mkimage.py          # (adapt to use the new binary name if needed)

Or just use the provided mosfetq-dos-0.4-rc1.img

Test under QEMU:
  qemu-system-i386 -fda mosfetq-dos-0.4-rc1.img -boot a

Commands of interest
--------------------
  DIR
  TYPE README.TXT
  DEL HELLO.TXT
  DIR                 (HELLO.TXT should be gone)
  TYPE HELLO.TXT      (should say File not found)

