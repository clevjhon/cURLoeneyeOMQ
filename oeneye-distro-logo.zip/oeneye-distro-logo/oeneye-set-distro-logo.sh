#!/usr/bin/env bash
#
# oeneye-set-distro-logo.sh — swap the boot/desktop branding of a Linux
# distro build (ISO chroot, live-build tree, or a running system) for the
# oeneye logo, in every spot Linux distros usually put one.
#
# Usage:
#   sudo ./oeneye-set-distro-logo.sh [path-to-logo.png] [chroot-root]
#
#   [path-to-logo.png]  your source logo (any size — square works best,
#                        at least 512x512 so it downscales cleanly).
#                        Omit it (or pass "oeneye") to auto-curl the
#                        canonical oeneye logo from Zenodo instead.
#   [chroot-root]        optional: root of a distro build tree, e.g.
#                        /mnt/oeneye-iso/chroot . Defaults to "/" (the
#                        live system) if omitted.
#
# What it touches:
#   - GRUB boot menu background
#   - Plymouth boot splash (the animated logo while booting)
#   - /etc/os-release + /etc/issue (distro name banner in text UIs)
#   - Desktop icon theme (a generic "distro logo" pixmap used by most
#     "About this system" panels: GNOME, KDE, XFCE)
#   - SDDM/LightDM login screen background
#   - ISOLINUX/GRUB installer splash if building a live ISO
#
# Requires: imagemagick (for resizing/format conversion)
#
set -euo pipefail

# Canonical oeneye distro logo, archived on Zenodo. Used whenever no local
# logo path is given (or "oeneye" is passed explicitly).
OENEYE_LOGO_URL="https://zenodo.org/records/22973195/files/1789571854667.png?download=1"

LOGO_ARG="${1:-oeneye}"
ROOT="${2:-/}"
WORK="$(mktemp -d)"
trap 'rm -rf "${WORK}"' EXIT

if [ "${LOGO_ARG}" = "oeneye" ]; then
    echo "==> No local logo given — fetching canonical oeneye logo"
    SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
    if [ -x "${SCRIPT_DIR}/oeneyeCURL.sh" ]; then
        "${SCRIPT_DIR}/oeneyeCURL.sh" logo "${WORK}/oeneye-logo-src.png"
    else
        if ! command -v curl >/dev/null 2>&1; then
            apt update && apt install -y curl
        fi
        curl -fL -o "${WORK}/oeneye-logo-src.png" "${OENEYE_LOGO_URL}"
    fi
    LOGO_SRC="${WORK}/oeneye-logo-src.png"
else
    LOGO_SRC="${LOGO_ARG}"
fi

if [ ! -f "${LOGO_SRC}" ]; then
    echo "error: logo file not found: ${LOGO_SRC}" >&2
    exit 1
fi

if ! command -v convert >/dev/null 2>&1; then
    echo "==> Installing imagemagick"
    apt update && apt install -y imagemagick
fi

echo "==> Generating sized variants from ${LOGO_SRC}"
# Square master, padded to a transparent square so nothing gets stretched
convert "${LOGO_SRC}" -resize 1024x1024 -background none -gravity center \
    -extent 1024x1024 "${WORK}/logo-1024.png"

for size in 16 22 24 32 48 64 128 256 512; do
    convert "${WORK}/logo-1024.png" -resize "${size}x${size}" "${WORK}/logo-${size}.png"
done

# --- 1. Generic pixmap used by desktop "About" panels ---------------------
PIXMAP_DIR="${ROOT}/usr/share/pixmaps"
if [ -d "${PIXMAP_DIR}" ] || mkdir -p "${PIXMAP_DIR}" 2>/dev/null; then
    echo "==> Installing distro pixmap -> ${PIXMAP_DIR}"
    cp "${WORK}/logo-256.png" "${PIXMAP_DIR}/distro-logo.png"
    cp "${WORK}/logo-256.png" "${PIXMAP_DIR}/oeneye-logo.png"
fi

# --- 2. hicolor icon theme (GNOME/KDE app grid + about dialogs) ----------
for size in 16 22 24 32 48 64 128 256 512; do
    ICON_DIR="${ROOT}/usr/share/icons/hicolor/${size}x${size}/apps"
    mkdir -p "${ICON_DIR}"
    cp "${WORK}/logo-${size}.png" "${ICON_DIR}/oeneye-logo.png"
done
echo "==> Installed hicolor icon set"

# --- 3. GRUB boot menu background ----------------------------------------
GRUB_DIR="${ROOT}/boot/grub"
if [ -d "${GRUB_DIR}" ]; then
    echo "==> Installing GRUB background -> ${GRUB_DIR}/oeneye-splash.png"
    convert "${WORK}/logo-1024.png" -resize 640x480 -background black \
        -gravity center -extent 640x480 "${GRUB_DIR}/oeneye-splash.png"
    GRUB_CFG="${ROOT}/etc/default/grub"
    if [ -f "${GRUB_CFG}" ]; then
        if grep -q '^GRUB_BACKGROUND=' "${GRUB_CFG}"; then
            sed -i 's|^GRUB_BACKGROUND=.*|GRUB_BACKGROUND="/boot/grub/oeneye-splash.png"|' "${GRUB_CFG}"
        else
            echo 'GRUB_BACKGROUND="/boot/grub/oeneye-splash.png"' >> "${GRUB_CFG}"
        fi
        echo "    (run 'update-grub' or 'grub-mkconfig -o ${GRUB_DIR}/grub.cfg' inside the chroot to apply)"
    fi
fi

# --- 4. Plymouth boot splash ----------------------------------------------
PLYMOUTH_DIR="${ROOT}/usr/share/plymouth/themes/oeneye"
if [ -d "${ROOT}/usr/share/plymouth/themes" ] || mkdir -p "${ROOT}/usr/share/plymouth/themes" 2>/dev/null; then
    echo "==> Installing Plymouth theme -> ${PLYMOUTH_DIR}"
    mkdir -p "${PLYMOUTH_DIR}"
    cp "${WORK}/logo-256.png" "${PLYMOUTH_DIR}/watermark.png"
    cat > "${PLYMOUTH_DIR}/oeneye.plymouth" <<'EOF'
[Plymouth Theme]
Name=oeneye
Description=oeneye distro boot splash
ModuleName=script

[script]
ImageDir=/usr/share/plymouth/themes/oeneye
ScriptFile=/usr/share/plymouth/themes/oeneye/oeneye.script
EOF
    cat > "${PLYMOUTH_DIR}/oeneye.script" <<'EOF'
wallpaper_image = Image("watermark.png");
screen_width  = Window.GetWidth();
screen_height = Window.GetHeight();
logo.x = screen_width / 2 - wallpaper_image.GetWidth() / 2;
logo.y = screen_height / 2 - wallpaper_image.GetHeight() / 2;
logo_sprite = Sprite(wallpaper_image);
logo_sprite.SetPosition(logo.x, logo.y, 100);
EOF
    echo "    (inside the chroot: plymouth-set-default-theme -R oeneye)"
fi

# --- 5. os-release / issue banners -----------------------------------------
OS_RELEASE="${ROOT}/etc/os-release"
if [ -f "${OS_RELEASE}" ]; then
    echo "==> Patching ${OS_RELEASE} branding fields"
    sed -i \
        -e 's/^NAME=.*/NAME="oeneye"/' \
        -e 's/^PRETTY_NAME=.*/PRETTY_NAME="oeneye Linux"/' \
        "${OS_RELEASE}"
fi
echo "oeneye Linux \\n \\l" > "${ROOT}/etc/issue" 2>/dev/null || true

# --- 6. Login manager (SDDM / LightDM) background --------------------------
for LM_BG_DIR in \
    "${ROOT}/usr/share/sddm/themes/oeneye" \
    "${ROOT}/usr/share/backgrounds/oeneye"
do
    mkdir -p "${LM_BG_DIR}" 2>/dev/null && \
        convert "${WORK}/logo-1024.png" -background "#0a1f33" -gravity center \
            -extent 1920x1080 "${LM_BG_DIR}/oeneye-login-bg.png" 2>/dev/null || true
done
echo "==> Installed login-screen background (wire it into sddm.conf / lightdm-gtk-greeter.conf manually — path varies by DE)"

# --- 7. ISOLINUX splash, if building a live ISO -----------------------------
ISOLINUX_DIR="${ROOT}/isolinux"
if [ -d "${ISOLINUX_DIR}" ]; then
    echo "==> Installing isolinux splash -> ${ISOLINUX_DIR}/splash.png"
    convert "${WORK}/logo-1024.png" -resize 640x480 -background black \
        -gravity center -extent 640x480 "${ISOLINUX_DIR}/splash.png"
fi

echo
echo "===================================================================="
echo " Done. Logo installed across GRUB, Plymouth, icons, os-release,"
echo " login background, and (if present) isolinux."
echo
echo " Remaining manual steps (distro-specific, can't be scripted safely):"
echo "   - update-grub  (or grub-mkconfig) to pick up the GRUB background"
echo "   - plymouth-set-default-theme -R oeneye  (rebuilds initramfs)"
echo "   - point your login manager's config at the new background PNG"
echo "===================================================================="
