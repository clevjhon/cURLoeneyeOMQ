# oeneye-set-distro-logo

One script to rebrand a Linux distro build with the oeneye logo — GRUB,
Plymouth boot splash, desktop icon theme, `/etc/os-release`, login-manager
background, and the ISOLINUX splash if you're building a live ISO.

## Usage

Run with no arguments and it auto-`curl`s the canonical oeneye logo from
Zenodo (`22973195/files/1789571854667.png`) and applies it to the live
system:

```bash
sudo ./oeneye-set-distro-logo.sh
```

Point it at a chroot / live-build tree instead of the host by passing the
root as the first argument, keeping the default logo:

```bash
sudo ./oeneye-set-distro-logo.sh oeneye /mnt/oeneye-iso/chroot
```

Or supply your own logo file instead of the default:

```bash
sudo ./oeneye-set-distro-logo.sh /path/to/other-logo.png /mnt/oeneye-iso/chroot
```

Requires `curl` and `imagemagick` (both installed automatically if
missing).

## What it does automatically

- Generates every icon size Linux desktops expect (16px–512px) into the
  hicolor icon theme and `/usr/share/pixmaps`
- Builds a GRUB background PNG and points `GRUB_BACKGROUND` at it in
  `/etc/default/grub`
- Creates a minimal Plymouth theme (`oeneye.plymouth` + script) that
  centers the logo on boot
- Patches `NAME=` / `PRETTY_NAME=` in `/etc/os-release` and `/etc/issue`
- Drops a login-background PNG for SDDM/LightDM (you still point the
  greeter's own config at it — that file lives in a different place per
  desktop environment, so it's not safely scriptable)
- Writes an ISOLINUX splash if `/isolinux` exists in the target root

## Manual finishing steps (distro/DE-specific, intentionally not scripted)

```bash
update-grub                              # or: grub-mkconfig -o /boot/grub/grub.cfg
plymouth-set-default-theme -R oeneye     # rebuilds the initramfs with the new theme
```

Then point your login manager's config at
`/usr/share/backgrounds/oeneye/oeneye-login-bg.png` — for SDDM that's
usually a `[General] background=` line in `/etc/sddm.conf` or a theme's
`theme.conf`; for LightDM it's in the greeter's own config
(`lightdm-gtk-greeter.conf`, etc).

## Fits into

This slots in alongside `build-oeneyeLinux.sh` / `build-oeneyeDongle-linux.sh`
in the OENEYE OS Project — run it as a post-build step on the chroot before
you package the ISO.
