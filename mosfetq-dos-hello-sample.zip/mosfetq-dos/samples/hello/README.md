# hello — MOSFETQ DOS sample program

A minimal DOS .COM program that prints a greeting via INT 0x21 (DOS
"print string", AH=9) then exits via INT 0x20. Intended as the
smallest possible demo app for MOSFETQ DOS / oeneyeVMx86.

## Files
- `hello.s`   — GNU `as` (AT&T-ready, Intel syntax via `.intel_syntax noprefix`) source.
- `hello.asm` — NASM syntax port of the same program.
- `hello.com` — pre-built 38-byte flat binary (org 0x100), built from hello.s
                with GNU binutils since NASM is not available in this sandbox.

## Build
GNU as / ld / objcopy (used to produce the included hello.com):

    as --32 -o hello.o hello.s
    ld -m elf_i386 -T link.ld -o hello.elf hello.o
    objcopy -O binary hello.elf hello.com

NASM (once available on your toolchain — not installed in this sandbox,
so hello.asm has not been assembled/verified here):

    nasm -f bin -o hello.com hello.asm

Both sources produce byte-identical output: `ba 09 01 b4 09 cd 21 cd 20`
followed by the message string.

## Run
Load/execute hello.com under DOSBox, oeneyeVMx86, or any MOSFETQ DOS /
DOS-compatible emulator that provides INT 0x21 AH=9.
