; hello.asm — NASM syntax port of hello.s
; Assemble with: nasm -f bin -o hello.com hello.asm
BITS 16
ORG 0x100

start:
    mov dx, msg
    mov ah, 9
    int 0x21
    int 0x20

msg: db "Hello from a .COM program!", 0x0D, 0x0A, '$'
