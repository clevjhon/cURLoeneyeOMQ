#!/usr/bin/env bash
#
# oeneye-wg-setup.sh — bring up a WireGuard VPN server on a fresh
# Ubuntu 22.04+/Debian 12+ VPS (Hetzner, DigitalOcean, Contabo, etc).
#
# Run as root (or with sudo) on the server itself:
#   chmod +x oeneye-wg-setup.sh
#   sudo ./oeneye-wg-setup.sh
#
set -euo pipefail

WG_IF="wg0"
WG_PORT="51820"
WG_NET="10.8.0.0/24"
SERVER_WG_IP="10.8.0.1/24"
CONF="/etc/wireguard/${WG_IF}.conf"

echo "==> Installing WireGuard"
apt update
apt install -y wireguard qrencode

echo "==> Enabling IPv4 forwarding"
sed -i 's/^#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
sysctl -p

# Detect the primary outbound interface (used for NAT masquerade rules)
EXT_IF=$(ip route get 1.1.1.1 | awk '{print $5; exit}')

echo "==> Detected external interface: ${EXT_IF}"

if [ ! -f /etc/wireguard/server_private.key ]; then
    echo "==> Generating server keypair"
    umask 077
    wg genkey | tee /etc/wireguard/server_private.key | wg pubkey > /etc/wireguard/server_public.key
fi

SERVER_PRIVATE_KEY=$(cat /etc/wireguard/server_private.key)
SERVER_PUBLIC_KEY=$(cat /etc/wireguard/server_public.key)

echo "==> Writing ${CONF}"
cat > "${CONF}" <<EOF
[Interface]
Address = ${SERVER_WG_IP}
ListenPort = ${WG_PORT}
PrivateKey = ${SERVER_PRIVATE_KEY}

# NAT: route peer traffic out through the server's public interface
PostUp   = iptables -t nat -A POSTROUTING -o ${EXT_IF} -j MASQUERADE
PostDown = iptables -t nat -D POSTROUTING -o ${EXT_IF} -j MASQUERADE

# Peers are appended below by oeneye-add-client.sh
EOF

chmod 600 "${CONF}"

echo "==> Opening UDP ${WG_PORT} in ufw (if active)"
if command -v ufw >/dev/null 2>&1; then
    ufw allow "${WG_PORT}/udp" || true
fi

echo "==> Enabling and starting wg-quick@${WG_IF}"
systemctl enable --now "wg-quick@${WG_IF}"

echo
echo "===================================================================="
echo " Server public key (put this in the client's [Peer] PublicKey):"
echo "   ${SERVER_PUBLIC_KEY}"
echo
echo " Server endpoint (put this in the client's [Peer] Endpoint):"
echo "   $(curl -s ifconfig.me):${WG_PORT}"
echo
echo " IMPORTANT: also open UDP ${WG_PORT} in your VPS provider's"
echo " cloud firewall / security group panel — ufw alone is not enough"
echo " on most providers (Hetzner Cloud Firewall, DO Cloud Firewall, etc)."
echo
echo " Next: run ./oeneye-add-client.sh <client-name> to generate a peer"
echo " config for the Android app / any WireGuard client."
echo "===================================================================="
