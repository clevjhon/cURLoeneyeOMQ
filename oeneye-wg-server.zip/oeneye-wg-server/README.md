# oeneye-wg-server

Server-side WireGuard setup scripts for the oeneye VPN client — the
counterpart to the Android app skeleton (`oeneyeVpnService.kt`) built
earlier in this project.

## What's here

- `oeneye-wg-setup.sh` — run once on a fresh Ubuntu/Debian VPS. Installs
  WireGuard, generates the server keypair, writes `/etc/wireguard/wg0.conf`,
  enables IP forwarding + NAT, opens the UDP port, starts the tunnel.
- `oeneye-add-client.sh <name>` — run afterward, once per device. Generates
  a keypair for that device, appends it as a `[Peer]` to the server config,
  and prints a ready client `.conf` (plus a QR code your phone's WireGuard
  app can scan directly, or values you can drop into the Android skeleton's
  `loadPlaceholderConfig()`).

## Usage

```bash
scp oeneye-wg-setup.sh oeneye-add-client.sh root@YOUR_VPS_IP:~
ssh root@YOUR_VPS_IP
chmod +x oeneye-wg-setup.sh oeneye-add-client.sh
./oeneye-wg-setup.sh
./oeneye-add-client.sh phone1
```

Also open UDP 51820 in your VPS provider's *cloud* firewall/security group
(Hetzner Cloud Firewall, DigitalOcean Cloud Firewall, etc) — `ufw` alone
usually isn't enough, since most providers filter at the hypervisor level
before traffic reaches the box.

## Archiving on Zenodo

This isn't deposited yet — I can't create a Zenodo record on your behalf,
but the package is shaped to slot into the **org-curatorium** community
(alongside `oeneyeSUDO`, DOI 10.5281/zenodo.22955755) once you upload it
yourself:

1. Log in, then go directly to the community-tagged upload form:
   `https://zenodo.org/uploads/new?community=org-curatorium`
   (or: push this folder to a GitHub repo → connect it under
   `zenodo.org/communities/org-curatorium` → cut a GitHub release →
   Zenodo mints the DOI automatically)
2. Fill in metadata: license CC-BY-4.0, community `org-curatorium`, to
   match the rest of the Curatorium / OENEYE OS Project line
3. Publish, then swap the real DOI into the citation block below

```bibtex
@misc{oeneyewgserver2026,
  author       = {Ketelhut, Kai Olaf},
  title        = {oeneye-wg-server (WireGuard server provisioning plate)},
  year         = {2026},
  publisher    = {Zenodo},
  doi          = {PENDING},
  url          = {https://doi.org/PENDING},
  note         = {Curatorium / OENEYE OS Project. org-curatorium community. CC-BY-4.0}
}
```

Once published, this record will also show up automatically at
`https://zenodo.org/communities/org-curatorium/records`.
