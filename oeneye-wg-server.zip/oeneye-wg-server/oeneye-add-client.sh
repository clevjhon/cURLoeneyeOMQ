#!/usr/bin/env bash
#
# oeneye-add-client.sh <name> — generate a new WireGuard peer and print
# a ready-to-use client .conf (plus a QR code for the mobile app).
#
# Run on the server, after oeneye-wg-setup.sh:
#   sudo ./oeneye-add-client.sh phone1
#
set -euo pipefail

WG_IF="wg0"
WG_PORT="51820"
CLIENTS_DIR="/etc/wireguard/clients"
CONF="/etc/wireguard/${WG_IF}.conf"

NAME="${1:?usage: oeneye-add-client.sh <client-name>}"
mkdir -p "${CLIENTS_DIR}"

SERVER_PUBLIC_KEY=$(cat /etc/wireguard/server_public.key)
SERVER_ENDPOINT="$(curl -s ifconfig.me):${WG_PORT}"

# Pick the next free /32 in 10.8.0.0/24 (server is .1, clients start at .2)
LAST_OCTET=$(( $(grep -c "^AllowedIPs" "${CONF}" 2>/dev/null || echo 0) + 2 ))
CLIENT_IP="10.8.0.${LAST_OCTET}/32"

umask 077
wg genkey | tee "${CLIENTS_DIR}/${NAME}_private.key" | wg pubkey > "${CLIENTS_DIR}/${NAME}_public.key"
CLIENT_PRIVATE_KEY=$(cat "${CLIENTS_DIR}/${NAME}_private.key")
CLIENT_PUBLIC_KEY=$(cat "${CLIENTS_DIR}/${NAME}_public.key")

echo "==> Adding peer '${NAME}' (${CLIENT_IP}) to ${CONF}"
cat >> "${CONF}" <<EOF

[Peer]
# ${NAME}
PublicKey = ${CLIENT_PUBLIC_KEY}
AllowedIPs = ${CLIENT_IP}
EOF

wg syncconf "${WG_IF}" <(wg-quick strip "${WG_IF}")

CLIENT_CONF="${CLIENTS_DIR}/${NAME}.conf"
cat > "${CLIENT_CONF}" <<EOF
[Interface]
PrivateKey = ${CLIENT_PRIVATE_KEY}
Address = ${CLIENT_IP}
DNS = 1.1.1.1

[Peer]
PublicKey = ${SERVER_PUBLIC_KEY}
Endpoint = ${SERVER_ENDPOINT}
AllowedIPs = 0.0.0.0/0
EOF

echo "==> Client config written to ${CLIENT_CONF}"
echo
cat "${CLIENT_CONF}"
echo
if command -v qrencode >/dev/null 2>&1; then
    echo "==> Scan this with the WireGuard app, or paste the config above"
    echo "    into oeneye's OeneyeVpnService.kt placeholder:"
    qrencode -t ansiutf8 < "${CLIENT_CONF}"
fi
