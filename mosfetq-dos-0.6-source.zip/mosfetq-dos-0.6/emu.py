#!/usr/bin/env python3
"""Minimal 16-bit x86 interpreter + stub BIOS, just enough to boot mosfetq-dos.img."""
import sys, struct

class Done(Exception): pass
class Reboot(Exception): pass

M16 = 0xFFFF
class CPU:
    def __init__(self, img, keys):
        self.mem = bytearray(1 << 20)
        self.img = bytearray(img); self.keys = list(keys); self.out = []
        self.r = [0] * 8            # AX CX DX BX SP BP SI DI
        self.s = [0] * 4            # ES CS SS DS
        self.ip = 0x7C00
        self.f = dict(C=0, Z=0, S=0, O=0, P=0, D=0, I=1)
        self.mem[0x7C00:0x7E00] = img[:512]
        self.r[2] = 0x0000          # DL = boot drive 0
        self.r[4] = 0x7000
        self.steps = 0
        self.disk_reads = []; self.disk_writes = []; self.printer = bytearray(); self.printer_fail = False
    # ---- registers ----
    def get8(self, n):
        v = self.r[n & 3]; return (v >> 8) & 0xFF if n & 4 else v & 0xFF
    def set8(self, n, v):
        i = n & 3; v &= 0xFF
        if n & 4: self.r[i] = (self.r[i] & 0x00FF) | (v << 8)
        else:     self.r[i] = (self.r[i] & 0xFF00) | v
    # ---- memory ----
    def lin(self, seg, off): return ((self.s[seg] << 4) + (off & M16)) & 0xFFFFF
    def rd8(self, seg, off): return self.mem[self.lin(seg, off)]
    def rd16(self, seg, off): return self.rd8(seg, off) | (self.rd8(seg, off + 1) << 8)
    def wr8(self, seg, off, v): self.mem[self.lin(seg, off)] = v & 0xFF
    def wr16(self, seg, off, v): self.wr8(seg, off, v); self.wr8(seg, off + 1, v >> 8)
    def fetch8(self):
        v = self.mem[self.lin(1, self.ip)]; self.ip = (self.ip + 1) & M16; return v
    def fetch16(self): lo = self.fetch8(); return lo | (self.fetch8() << 8)
    def fetchs8(self): v = self.fetch8(); return v - 256 if v & 0x80 else v
    def push(self, v): self.r[4] = (self.r[4] - 2) & M16; self.wr16(2, self.r[4], v)
    def pop(self): v = self.rd16(2, self.r[4]); self.r[4] = (self.r[4] + 2) & M16; return v
    # ---- modrm ----
    def modrm(self):
        b = self.fetch8(); mod, reg, rm = b >> 6, (b >> 3) & 7, b & 7
        if mod == 3: return reg, ("r", rm)
        r = self.r
        base = [r[3]+r[6], r[3]+r[7], r[5]+r[6], r[5]+r[7], r[6], r[7], r[5], r[3]][rm]
        seg = 2 if rm in (2, 3) or (rm == 6 and mod) else 3
        if mod == 0 and rm == 6: base = self.fetch16(); seg = 3
        elif mod == 1: base += self.fetchs8()
        elif mod == 2: base += self.fetch16()
        return reg, ("m", seg, base & M16)
    def rdop(self, op, size):
        if op[0] == "r": return self.get8(op[1]) if size == 1 else self.r[op[1]]
        return self.rd8(op[1], op[2]) if size == 1 else self.rd16(op[1], op[2])
    def wrop(self, op, size, v):
        if op[0] == "r":
            if size == 1: self.set8(op[1], v)
            else: self.r[op[1]] = v & M16
        elif size == 1: self.wr8(op[1], op[2], v)
        else: self.wr16(op[1], op[2], v)
    def packf(self):
        f = self.f
        return 0x0002 | f['C'] | (f['P'] << 2) | (f['Z'] << 6) | (f['S'] << 7) | (f['I'] << 9) | (f['D'] << 10) | (f['O'] << 11)
    def unpackf(self, v):
        f = self.f
        f['C'] = v & 1; f['P'] = (v >> 2) & 1; f['Z'] = (v >> 6) & 1; f['S'] = (v >> 7) & 1
        f['I'] = (v >> 9) & 1; f['D'] = (v >> 10) & 1; f['O'] = (v >> 11) & 1
    def soft_int(self, n):
        self.push(self.packf()); self.push(self.s[1]); self.push(self.ip)
        off = self.mem[n * 4] | (self.mem[n * 4 + 1] << 8); seg = self.mem[n * 4 + 2] | (self.mem[n * 4 + 3] << 8)
        assert (seg, off) != (0, 0), f"INT {n:#x} not hooked"
        self.s[1] = seg; self.ip = off
    # ---- flags / ALU ----
    def szp(self, res, size):
        m = 0xFF if size == 1 else M16; sb = 0x80 if size == 1 else 0x8000
        res &= m; self.f['Z'] = int(res == 0); self.f['S'] = int(bool(res & sb))
        self.f['P'] = int(bin(res & 0xFF).count("1") % 2 == 0); return res
    def alu(self, op, a, b, size):
        m = 0xFF if size == 1 else M16; sb = 0x80 if size == 1 else 0x8000
        c = self.f['C']
        if op in (0, 2):   # add, adc
            t = a + b + (c if op == 2 else 0)
            self.f['C'] = int(t > m); self.f['O'] = int(bool(~(a ^ b) & (a ^ t) & sb)); return self.szp(t, size)
        if op in (3, 5, 7):  # sbb, sub, cmp
            t = a - b - (c if op == 3 else 0)
            self.f['C'] = int(t < 0); self.f['O'] = int(bool((a ^ b) & (a ^ t) & sb)); r = self.szp(t, size)
            return a if op == 7 else r
        t = {1: a | b, 4: a & b, 6: a ^ b}[op]
        self.f['C'] = 0; self.f['O'] = 0; return self.szp(t, size)
    def cond(self, c):
        f = self.f
        t = [f['O'], f['C'], f['Z'], f['C'] | f['Z'], f['S'], f['P'], f['S'] ^ f['O'], (f['S'] ^ f['O']) | f['Z']][c >> 1]
        return bool(t) != bool(c & 1)
    def shift(self, kind, v, n, size):
        m = 0xFF if size == 1 else M16; bits = 8 * size; n &= 31
        if n == 0: return v
        if kind == 5:   # shr
            self.f['C'] = (v >> (n - 1)) & 1; v >>= n
        elif kind == 4: # shl
            self.f['C'] = (v >> (bits - n)) & 1 if n <= bits else 0; v = (v << n) & m
        elif kind == 7: # sar
            sv = v - (m + 1) if v & (1 << (bits - 1)) else v
            self.f['C'] = (sv >> (n - 1)) & 1; v = (sv >> n) & m
        else: raise NotImplementedError(f"shift kind {kind}")
        return self.szp(v, size)
    # ---- BIOS ----
    def bios(self, n):
        r = self.r; ah = (r[0] >> 8) & 0xFF; al = r[0] & 0xFF
        if n == 0x10:
            if ah == 0x0E: self.out.append(chr(al))
            elif ah == 0x00: self.out.append("\f")
            else: raise NotImplementedError(f"int 10h ah={ah:#x}")
        elif n == 0x13:
            if ah == 0: self.f['C'] = 0; r[0] &= 0x00FF; return
            assert ah in (2, 3), f"int 13h ah={ah:#x}"
            cyl = ((r[1] >> 8) & 0xFF) | (((r[1] & 0xC0)) << 2); sec = r[1] & 0x3F; head = (r[2] >> 8) & 0xFF
            assert (r[2] & 0xFF) == 0, "wrong drive"
            assert 1 <= sec <= 18 and head < 2 and cyl < 80, f"bad CHS {cyl}/{head}/{sec}"
            lba = (cyl * 2 + head) * 18 + sec - 1
            if ah == 3:
                for i in range(al):
                    a = self.lin(0, r[3] + i * 512)
                    self.img[(lba + i) * 512:(lba + i + 1) * 512] = self.mem[a:a + 512]
                    self.disk_writes.append(lba + i)
                self.f['C'] = 0; r[0] = al; return
            for i in range(al):
                d = self.img[(lba + i) * 512:(lba + i + 1) * 512]
                self.mem[self.lin(0, r[3] + i * 512): self.lin(0, r[3] + i * 512) + 512] = d
                self.disk_reads.append(lba + i)
            self.f['C'] = 0; r[0] = al
        elif n == 0x16:
            if ah == 1:
                self.f['Z'] = int(not self.keys)
                if self.keys: r[0] = ord(self.keys[0])
                return
            if not self.keys: raise Done()
            k = self.keys.pop(0); r[0] = ord(k)
        elif n == 0x17:                       # BIOS printer services (LPT1)
            if self.printer_fail: r[0] = (r[0] & 0x00FF) | 0x0100; return        # AH=01: time-out
            if ah == 0: self.printer.append(al)
            elif ah not in (1, 2): raise NotImplementedError(f"int 17h ah={ah:#x}")
            r[0] = (r[0] & 0x00FF) | 0x9000                                    # AH=90h: selected, not busy
        elif n == 0x12: r[0] = 639
        elif n == 0x1A:
            if ah == 2: r[1] = 0x1234; r[2] = 0x5600      # 12:34:56
            elif ah == 4: r[1] = 0x2026; r[2] = 0x0919     # 2026-09-19
            self.f['C'] = 0
        else: raise NotImplementedError(f"int {n:#x}")
    # ---- run ----
    def run(self, limit=20_000_000):
        r = self.r
        while self.steps < limit:
            self.steps += 1
            ip0 = self.ip
            op = self.fetch8(); rep = False
            if op == 0xF3: rep = True; op = self.fetch8()
            if op < 0x40 and (op & 7) < 6:
                k = op >> 3; t = op & 7
                if t in (0, 1, 2, 3):
                    size = 1 if t % 2 == 0 else 2; reg, rm = self.modrm()
                    if t < 2: res = self.alu(k, self.rdop(rm, size), self.rdop(("r", reg), size), size); (k != 7) and self.wrop(rm, size, res)
                    else:     res = self.alu(k, self.rdop(("r", reg), size), self.rdop(rm, size), size); (k != 7) and self.wrop(("r", reg), size, res)
                elif t == 4: res = self.alu(k, r[0] & 0xFF, self.fetch8(), 1); (k != 7) and self.set8(0, res)
                else:        res = self.alu(k, r[0], self.fetch16(), 2); (k != 7) and r.__setitem__(0, res)
            elif 0x40 <= op < 0x50:
                i = op & 7; c = self.f['C']
                r[i] = self.alu(0 if op < 0x48 else 5, r[i], 1, 2); self.f['C'] = c
            elif 0x50 <= op < 0x58: self.push(r[op & 7])
            elif 0x58 <= op < 0x60: r[op & 7] = self.pop()
            elif 0x70 <= op < 0x80:
                d = self.fetchs8()
                if self.cond(op & 15): self.ip = (self.ip + d) & M16
            elif op == 0x0F:
                op2 = self.fetch8(); assert 0x80 <= op2 < 0x90, f"0F {op2:#x} @ {ip0:#x}"
                d = self.fetch16(); d = d - 65536 if d & 0x8000 else d
                if self.cond(op2 & 15): self.ip = (self.ip + d) & M16
            elif op in (0x80, 0x81, 0x83):
                size = 1 if op == 0x80 else 2; reg, rm = self.modrm()
                imm = self.fetch8() if op != 0x81 else self.fetch16()
                if op == 0x83 and imm & 0x80: imm |= 0xFF00
                res = self.alu(reg, self.rdop(rm, size), imm & (0xFF if size == 1 else M16), size)
                if reg != 7: self.wrop(rm, size, res)
            elif op in (0x84, 0x85):
                size = 1 if op == 0x84 else 2; reg, rm = self.modrm()
                self.alu(4, self.rdop(rm, size), self.rdop(("r", reg), size), size)
            elif op in (0x86, 0x87):
                size = 1 if op == 0x86 else 2; reg, rm = self.modrm()
                a = self.rdop(rm, size); b = self.rdop(("r", reg), size); self.wrop(rm, size, b); self.wrop(("r", reg), size, a)
            elif op in (0x88, 0x89):
                size = 1 if op == 0x88 else 2; reg, rm = self.modrm(); self.wrop(rm, size, self.rdop(("r", reg), size))
            elif op in (0x8A, 0x8B):
                size = 1 if op == 0x8A else 2; reg, rm = self.modrm(); self.wrop(("r", reg), size, self.rdop(rm, size))
            elif op == 0x8C: reg, rm = self.modrm(); self.wrop(rm, 2, self.s[reg])
            elif op == 0x8E: reg, rm = self.modrm(); self.s[reg] = self.rdop(rm, 2)
            elif op == 0x8D: reg, rm = self.modrm(); assert rm[0] == "m"; r[reg] = rm[2]
            elif op == 0x90: pass
            elif 0x91 <= op <= 0x97: i = op & 7; r[0], r[i] = r[i], r[0]
            elif op == 0xA0: self.set8(0, self.rd8(3, self.fetch16()))
            elif op == 0xA1: r[0] = self.rd16(3, self.fetch16())
            elif op == 0xA2: self.wr8(3, self.fetch16(), r[0])
            elif op == 0xA3: self.wr16(3, self.fetch16(), r[0])
            elif op in (0xA8, 0xA9):
                if op == 0xA8: self.alu(4, r[0] & 0xFF, self.fetch8(), 1)
                else: self.alu(4, r[0], self.fetch16(), 2)
            elif op in (0xAA, 0xAB, 0xAC, 0xAD, 0xA4, 0xA5):
                size = 1 if op in (0xAA, 0xAC, 0xA4) else 2
                n = r[1] if rep else 1
                while n:
                    if op in (0xAA, 0xAB):
                        (self.wr8 if size == 1 else self.wr16)(0, r[7], r[0]); r[7] = (r[7] + size) & M16
                    elif op in (0xAC, 0xAD):
                        v = (self.rd8 if size == 1 else self.rd16)(3, r[6]); r[6] = (r[6] + size) & M16
                        (self.set8(0, v) if size == 1 else r.__setitem__(0, v))
                    else:
                        v = (self.rd8 if size == 1 else self.rd16)(3, r[6]); (self.wr8 if size == 1 else self.wr16)(0, r[7], v)
                        r[6] = (r[6] + size) & M16; r[7] = (r[7] + size) & M16
                    n -= 1
                if rep: r[1] = 0
            elif 0xB0 <= op < 0xB8: self.set8(op & 7, self.fetch8())
            elif 0xB8 <= op < 0xC0: r[op & 7] = self.fetch16()
            elif op in (0xC0, 0xC1, 0xD0, 0xD1, 0xD2, 0xD3):
                size = 1 if op in (0xC0, 0xD0, 0xD2) else 2; reg, rm = self.modrm()
                n = self.fetch8() if op in (0xC0, 0xC1) else (1 if op in (0xD0, 0xD1) else r[1] & 0xFF)
                self.wrop(rm, size, self.shift(reg, self.rdop(rm, size), n, size))
            elif op == 0xC3: self.ip = self.pop()
            elif op in (0xC6, 0xC7):
                size = 1 if op == 0xC6 else 2; reg, rm = self.modrm()
                self.wrop(rm, size, self.fetch8() if size == 1 else self.fetch16())
            elif op == 0xCD:
                n = self.fetch8()
                if n in (0x10, 0x12, 0x13, 0x16, 0x17, 0x1A): self.bios(n)
                else: self.soft_int(n)
            elif op == 0xCF: self.ip = self.pop(); self.s[1] = self.pop(); self.unpackf(self.pop())
            elif op == 0x9C: self.push(self.packf())
            elif op == 0x9D: self.unpackf(self.pop())
            elif op in (0x06, 0x0E, 0x16, 0x1E): self.push(self.s[op >> 3])
            elif op in (0x07, 0x17, 0x1F): self.s[op >> 3] = self.pop()
            elif op == 0xE2:
                d = self.fetchs8(); r[1] = (r[1] - 1) & M16
                if r[1]: self.ip = (self.ip + d) & M16
            elif op == 0xE8: d = self.fetch16(); self.push(self.ip); self.ip = (self.ip + d) & M16
            elif op == 0xE9: d = self.fetch16(); self.ip = (self.ip + d) & M16
            elif op == 0x9A:
                off = self.fetch16(); seg = self.fetch16(); self.push(self.s[1]); self.push(self.ip); self.s[1] = seg; self.ip = off
            elif op == 0xCB: self.ip = self.pop(); self.s[1] = self.pop()
            elif op == 0xEA:
                off = self.fetch16(); seg = self.fetch16()
                if seg == 0xFFFF and off == 0: raise Reboot()
                self.s[1] = seg; self.ip = off
            elif op == 0xEB: d = self.fetchs8(); self.ip = (self.ip + d) & M16
            elif op == 0xF4: raise Done()
            elif op == 0xF8: self.f['C'] = 0
            elif op == 0xF9: self.f['C'] = 1
            elif op in (0xFA, 0xFB): self.f['I'] = int(op == 0xFB)
            elif op == 0xFC: self.f['D'] = 0
            elif op == 0xFD: self.f['D'] = 1
            elif op in (0xF6, 0xF7):
                size = 1 if op == 0xF6 else 2; reg, rm = self.modrm()
                if reg == 0:
                    self.alu(4, self.rdop(rm, size), self.fetch8() if size == 1 else self.fetch16(), size)
                elif reg == 6:
                    d = self.rdop(rm, size); assert d, "divide by zero"
                    if size == 1:
                        n = r[0]; q, rem = divmod(n, d); assert q < 256; r[0] = (rem << 8) | q
                    else:
                        n = (r[2] << 16) | r[0]; q, rem = divmod(n, d); assert q <= M16, "divide overflow"; r[0], r[2] = q, rem
                else: raise NotImplementedError(f"F6/F7 /{reg}")
            elif op in (0xFE, 0xFF):
                size = 1 if op == 0xFE else 2; reg, rm = self.modrm()
                if reg in (0, 1):
                    c = self.f['C']; v = self.alu(0 if reg == 0 else 5, self.rdop(rm, size), 1, size); self.f['C'] = c; self.wrop(rm, size, v)
                else: raise NotImplementedError(f"FF /{reg}")
            else:
                raise NotImplementedError(f"opcode {op:#04x} at {self.s[1]:04x}:{ip0:04x}")
        raise RuntimeError("step limit")

def boot(img, keys, printer_fail=False):
    cpu = CPU(img, keys); cpu.printer_fail = printer_fail
    try: cpu.run()
    except Done: pass
    except Reboot: cpu.out.append("<<REBOOT>>")
    return cpu

if __name__ == "__main__":
    img = open("mosfetq-dos.img", "rb").read()
    keys = sys.argv[1].encode().decode("unicode_escape") if len(sys.argv) > 1 else ""
    c = boot(img, keys)
    print("".join(c.out).replace("\r", ""))
