#!/usr/bin/env python3
"""Generate the sample .EXE (MZ) programs and .BAT files in progs/.
The EXEs are hand-assembled here so that they contain real relocations."""
import struct

def mz(image, relocs, hdr_paras, ss, sp, ip, cs, minalloc, maxalloc=0xFFFF):
    hdr_len = hdr_paras * 16
    total = hdr_len + len(image)
    h = struct.pack("<2s13H", b"MZ", total % 512, (total + 511) // 512, len(relocs), hdr_paras,
                    minalloc, maxalloc, ss, sp, 0, ip, cs, 0x1C, 0)
    assert len(h) == 0x1C
    h += b"".join(struct.pack("<HH", o, s) for o, s in relocs)
    assert len(h) <= hdr_len
    return h.ljust(hdr_len, b"\0") + image

class Asm:
    def __init__(s): s.b = bytearray(); s.fix = []; s.lab = {}
    def db(s, *x): s.b.extend(x)
    def dw(s, v): s.b.extend(struct.pack("<H", v))
    def label(s, n): s.lab[n] = len(s.b)
    def jcc(s, op, n): s.b.append(op); s.fix.append((len(s.b), n)); s.b.append(0)
    def done(s):
        for pos, n in s.fix:
            rel = s.lab[n] - (pos + 1); assert -128 <= rel <= 127, n; s.b[pos] = rel & 0xFF
        return bytes(s.b)

JNE = 0x75

# ---------- EXETEST.EXE: one relocation, own data/stack segments, exit code 5 ----------
a = Asm()
a.db(0xB8); reloc1 = len(a.b); a.dw(2)          # mov ax, DATASEG (paragraph 2 of the image) -> relocated
a.db(0x8E, 0xD8)                                # mov ds, ax
a.db(0xBA, 0, 0)                                # mov dx, 0
a.db(0xB4, 9); a.db(0xCD, 0x21)                 # mov ah, 9 ; int 21h
a.db(0xB8, 0x05, 0x4C); a.db(0xCD, 0x21)        # mov ax, 4C05h ; int 21h
code = a.done().ljust(0x20, b"\0")
data = b"Hello from an EXE!\r\n$"
image = code + data
image = image.ljust(0x40, b"\0")                # stack segment = paragraph 4, SP = 0x100 (beyond the image)
open("progs/EXETEST.EXE", "wb").write(mz(image, [(reloc1, 0)], hdr_paras=0x20, ss=4, sp=0x100, ip=0, cs=0, minalloc=0x14))

# ---------- EXE2.EXE: two code segments (far call), 544-byte header, data word relocation ----------
pattern = bytes((i * 3 + 1) & 0xFF for i in range(1024))
expect = sum(pattern) & 0xFFFF
a = Asm(); relocs = []
a.db(0x8C, 0xD8); a.db(0x3D); a.dw(0x1000); a.jcc(JNE, "fail")     # DS == PSP segment (1000h)
a.db(0x8C, 0xC0); a.db(0x3D); a.dw(0x1000); a.jcc(JNE, "fail")     # ES == PSP segment
a.db(0x8C, 0xD0); a.db(0x3D); a.dw(0x1080); a.jcc(JNE, "fail")     # SS == load segment 1010h + 70h
a.db(0x81, 0xFC); a.dw(0x0100); a.jcc(JNE, "fail")                 # SP == 100h
a.db(0xB8); relocs.append((len(a.b), 0)); a.dw(0x20)              # mov ax, DATASEG            (reloc)
a.db(0x8E, 0xD8)                                                   # mov ds, ax
a.db(0x81, 0x3E); a.dw(0x0420); a.dw(0x0030); a.jcc(JNE, "fail")   # cmp [0420h], 30h (relocated word: 20h+1010h = 1030h -> compare with 1030h)
a.db(0x9A); a.dw(0); relocs.append((len(a.b), 0)); a.dw(0x10)     # call far CODE2:0           (reloc)
a.db(0x81, 0xFA); a.dw(expect); a.jcc(JNE, "fail")                 # cmp dx, checksum
a.db(0xBA); a.dw(0x0400); a.db(0xB4, 9, 0xCD, 0x21)               # print "EXE2 OK"
a.db(0xB8, 0x00, 0x4C, 0xCD, 0x21)                                 # exit 0
a.label("fail")
a.db(0xBA); a.dw(0x0410); a.db(0xB4, 9, 0xCD, 0x21)               # print "EXE2 FAIL"
a.db(0xB8, 0x01, 0x4C, 0xCD, 0x21)                                 # exit 1
main = a.done()
# fix the compare-with-relocated-word immediate: LOADSEG(0x1010) + 0x20 = 0x1030
main = bytearray(main); i = main.index(bytes([0x81, 0x3E, 0x20, 0x04])); main[i + 4:i + 6] = struct.pack("<H", 0x1030); main = bytes(main)
code2 = bytes([0x31, 0xF6, 0xB9, 0x00, 0x04, 0x31, 0xD2, 0xAC, 0x00, 0xC2, 0x80, 0xD6, 0x00, 0xE2, 0xF8, 0xCB])
assert len(main) < 0x100 and len(code2) < 0x100
datas = pattern + b"EXE2 OK\r\n$".ljust(16, b"\0") + b"EXE2 FAIL\r\n$".ljust(16, b"\0") + struct.pack("<H", 0x0020)
assert len(datas) == 0x422
image = main.ljust(0x100, b"\0") + code2.ljust(0x100, b"\0") + datas
relocs.append((0x0420, 0x20))                                      # the data word itself
open("progs/EXE2.EXE", "wb").write(mz(image, relocs, hdr_paras=0x22, ss=0x70, sp=0x100, ip=0, cs=0, minalloc=0x20))

# ---------- malformed EXEs: must all be refused with "Bad program" ----------
open("progs/BADMZ.EXE", "wb").write(b"X" * 600)                                              # no MZ signature
open("progs/TINY.EXE", "wb").write(b"MZ" + bytes(18))                                        # smaller than a header
good = mz(b"\xCD\x20".ljust(0x40, b"\0"), [], 0x20, 0, 0x100, 0, 0, 0x10)
open("progs/HDRBIG.EXE", "wb").write(struct.pack("<2s13H", b"MZ", 88, 2, 0, 0x40, 0, 0xFFFF, 0, 0x100, 0, 0, 0, 0x1C, 0) + bytes(572))  # header (1024 B) larger than the file
open("progs/BADREL.EXE", "wb").write(struct.pack("<2s13H", b"MZ", 88, 2, 200, 0x20, 0, 0xFFFF, 0, 0x100, 0, 0, 0, 0x1C, 0).ljust(600, b"\0"))   # claims 200 relocations: table would not fit in sector 0
open("progs/BADSEG.EXE", "wb").write(mz(b"\xCD\x20".ljust(0x40, b"\0"), [(0, 0x9000)], 0x20, 0, 0x100, 0, 0, 0x10))   # relocation target 9000h+1010h = A010h: above the program area (only the bound check catches it)
open("progs/OKEXIT.EXE", "wb").write(good)                                                   # valid minimal EXE: INT 20h

# ---------- batch files ----------
def bat(name, text, eol=b"\r\n"): open(f"progs/{name}", "wb").write(text if isinstance(text, bytes) else eol.join(t.encode() for t in text) + eol)
bat("AUTOEXEC.BAT", ["@ECHO OFF", "REM MOSFETQ DOS startup script", "ECHO AUTOEXEC.BAT done"])
bat("TEST.BAT", ["@ECHO OFF", "REM this comment must not run", ":skipped label", "ECHO batch start", "HELLO", "ARGS a  b",
                 "CAT HELLO.TXT", "ECHO ON", "ECHO echoed now", "@ECHO but not this line", "rem lower case rem too", "   ECHO indented"])
bat("NEST.BAT", ["ECHO before", "TEST", "ECHO after"])
open("progs/LF.BAT", "wb").write(b"ECHO one\nECHO two")                                       # LF only, no final newline
open("progs/EMPTY.BAT", "wb").write(b"")
bat("LONGLN.BAT", ["@ECHO OFF", "ECHO " + "x" * 100, "ECHO after long line"])
print("generated progs/*.EXE, progs/*.BAT")
