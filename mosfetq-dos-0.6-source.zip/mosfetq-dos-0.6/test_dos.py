import re, sys
from emu import boot
img = open("mosfetq-dos.img", "rb").read()
fails = 0
def run(cmds):
    c = boot(img, "".join(x + "\r" for x in cmds) if isinstance(cmds, list) else cmds)
    return "".join(c.out), c
def norm(b):  # what TYPE should print: CR dropped, LF -> CRLF
    return b.replace(b"\r", b"").replace(b"\n", b"\r\n").decode() 
def check(name, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  " + extra))
    fails += (not cond)
def after(out, cmd):  # text between the echoed command and the next prompt
    i = out.index(cmd + "\r\n") + len(cmd) + 2
    return out[i: out.index("A:\\>", i)]

files = {}
import struct
root = img[35*512: 35*512 + 14*512]
def clusters(first):
    fat = img[17*512: 17*512 + 9*512]; ch = []; c = first
    while 2 <= c < 0xFF8:
        ch.append(c); o = c + c // 2; w = fat[o] | fat[o+1] << 8; c = (w >> 4) if c & 1 else (w & 0xFFF)
    return ch
for i in range(0, len(root), 32):
    e = root[i:i+32]
    if e[0] in (0, 0xE5) or e[11] & 0x18: continue
    name = (e[:8].decode().strip() + "." + e[8:11].decode().strip()).rstrip(".")
    first, size = struct.unpack_from("<HI", e, 26)
    data = b"".join(img[(49 + c - 2) * 512:(49 + c - 1) * 512] for c in clusters(first))[:size]
    files[name] = data

out, cpu = run(["dir"])
d = after(out, "dir")
print(d)
check("boot banner", "MOSFETQ DOS 0.6" in out and "Loading MOSFETQ DOS" in out)
check("DIR lists all files", all(n in d for n in files) and f"{len(files)} file(s)" in d and "1 dir(s)" in d, d)
check("DIR shows <DIR> for DOCS", re.search(r"DOCS\s+<DIR>", d) is not None)
check("DIR hides label and deleted entries", "OLD" not in d and "MOSFETQ" not in d.split("\r\n",2)[2])
check("DIR sizes correct", all(re.search(re.escape(n) + r"\s+" + str(len(v)) + r" bytes", d) for n, v in files.items()), d)

for n in ["README.TXT", "HELLO.TXT", "LONG.TXT", "FRAG.TXT", "BIG.TXT"]:
    out, _ = run(["type " + n])
    got = after(out, "type " + n)
    exp = norm(files[n]) + "\r\n"
    check(f"TYPE {n} ({len(files[n])} B) exact", got == exp, f"got {len(got)} chars, want {len(exp)}")
out, _ = run(["TyPe   frag.txt"])   # case-insensitive + extra spaces
check("case-insensitive TYPE + multiple spaces", after(out, "TyPe   frag.txt") == norm(files["FRAG.TXT"]) + "\r\n")
out, _ = run(["type nofile.txt", "type readme", "type DOCS", "type", "type MOSFETQ"])
check("TYPE missing file", after(out, "type nofile.txt") == "File not found\r\n")
check("TYPE name without extension not found", after(out, "type readme") == "File not found\r\n")
check("TYPE on a directory refused", after(out, "type DOCS") == "File not found\r\n")
check("TYPE with no argument", after(out, "type") == "Usage: TYPE filename\r\n")
check("TYPE volume label refused", after(out, "type MOSFETQ") == "File not found\r\n")
out, _ = run(["frobnicate", "dirx", "echo Hi  There", "mem", "time", "date", "help", "ver"])
check("unknown command", after(out, "frobnicate") == "Bad command or file name\r\n")
check("'dirx' is not DIR", after(out, "dirx") == "Bad command or file name\r\n")
check("ECHO keeps case/spacing", after(out, "echo Hi  There") == "Hi  There\r\n")
check("MEM", after(out, "mem") == "639 KB conventional memory\r\n")
check("TIME", after(out, "time") == "12:34:56\r\n")
check("DATE", after(out, "date") == "2026-09-19\r\n")
check("HELP lists TYPE", "TYPE f" in after(out, "help"))
out2, _ = run("dirz\x08\r")        # "dirz" + backspace = "dir"
check("backspace editing", f"{len(files)} file(s)" in out2 and "Bad command" not in out2, out2[-80:])
out3, _ = run("\x08\x08\x08ver\r")   # backspace on empty line must not underflow
check("backspace on empty line is harmless", "MOSFETQ DOS 0.6 (real" in out3)
out4, _ = run("abcdefghij" * 7 + "\rver\r")
check("input longer than 63 chars is truncated safely", "Bad command" in out4 and "MOSFETQ DOS 0.6 (real" in out4)

# ---------------- .COM loader / INT 21h ----------------
out, cpu = run(["hello", "HELLO.COM", "run hello", "RUN Hello.Com", "dir"])
hello = "Hello from a .COM program!\r\n"
check("bare name runs NAME.COM", after(out, "hello") == hello)
check("explicit extension + uppercase", after(out, "HELLO.COM") == hello)
check("RUN command", after(out, "run hello") == hello)
check("RUN mixed case", after(out, "RUN Hello.Com") == hello)
check("kernel intact after 4 program runs (DIR still works)", f"{len(files)} file(s)" in after(out, "dir"))
out, _ = run(["run args", "args a b  c", "ARGS"])
check("PSP command tail: none", after(out, "run args") == "[]\r\nExit code 7\r\n", repr(after(out, "run args")))
check("PSP command tail: args keep spacing", after(out, "args a b  c") == "[ a b  c]\r\nExit code 7\r\n", repr(after(out, "args a b  c")))
out, _ = run("line\rBob\rline\rABCDEFGHIJKLMNOP\r")
check("AH=0Ah buffered input", "Name? Bob\r\nYou typed: Bob\r\n" in out, repr(out[-120:]))
check("AH=0Ah honours the max length (9 chars + CR)", "You typed: ABCDEFGHI\r\n" in out, repr(out[-120:]))
out, _ = run("line\rabc\x08\x08Z\rver\r")
check("AH=0Ah backspace", "You typed: aZ\r\n" in out, repr(out[-120:]))
out, _ = run(["vec"])
check("AH=25/35 vectors + user INT 60h", after(out, "vec") == "Hok\r\n", repr(after(out, "vec")))
out, _ = run(["segs"])
check("startup env: DS=ES=SS=CS, SP, PSP INT 20h, DOS version, unknown fn -> CF", after(out, "segs") == "SEGS OK\r\n", repr(after(out, "segs")))
out, _ = run("key\rq")
check("AH=0Bh poll + AH=08 read key", after(out, "key") == "Key: q\r\n", repr(after(out, "key")))
out, _ = run(["ret", "ver"])
check("plain RET terminates via PSP:0", after(out, "ret") == "R\n" and "MOSFETQ DOS 0.6 (real" in out, repr(out[-80:]))
out, _ = run(["toobig", "empty", "run toobig.com", "run empty", "run", "nothere", "run nothere", "run readme.txt", "run docs", "README.TXT"])
check("too big refused", after(out, "toobig") == "Program too big\r\n", repr(after(out, "toobig")))
check("empty refused", after(out, "empty") == "Bad program\r\n")
check("RUN with no arg", after(out, "run") == "Usage: RUN program [arguments]\r\n")
check("unknown bare name", after(out, "nothere") == "Bad command or file name\r\n")
check("RUN missing program", after(out, "run nothere") == "File not found\r\n")
check("RUN of a non-.COM file", after(out, "run readme.txt") == "File not found\r\n")
check("RUN of a directory", after(out, "run docs") == "File not found\r\n")
check("bare non-.COM file name is a bad command", after(out, "README.TXT") == "Bad command or file name\r\n")
out, _ = run(["help"])
check("HELP mentions RUN", "RUN p" in out)
out, _ = run(["segs", "vec", "hello", "args", "dir", "type long.txt"])
check("run programs then TYPE a multi-cluster file", norm(files["LONG.TXT"]) in out)

# ---------------- INT 21h file services ----------------
def cat(name, keys_extra=""):
    c = boot(img, f"cat {name}\r" + keys_extra)
    o = "".join(c.out); i = o.index(f"cat {name}\r\n") + len(f"cat {name}\r\n")
    return o[i: o.rindex("A:\\>")]
for n in ["README.TXT", "HELLO.TXT", "TAIL.TXT", "LONG.TXT", "FRAG.TXT", "PAD.BIN", "SPAN.DAT", "BIG.TXT", "hello.com", "Readme.Txt"]:
    key = n.upper()
    got = cat(n).encode("latin-1")
    check(f"CAT {n}: {len(files[key]):5d} bytes read via 3Dh/3Fh/40h are byte-exact", got == files[key], f"got {len(got)} bytes, want {len(files[key])}")
out, _ = run(["cat nothere.txt", "cat docs", "cat", "cat A:\\readme.txt"])
check("CAT missing file -> DOS error 2, exit code 1", after(out, "cat nothere.txt") == "CAT error 2\r\nExit code 1\r\n", repr(after(out, "cat nothere.txt")))
check("CAT directory -> DOS error 2", after(out, "cat docs") == "CAT error 2\r\nExit code 1\r\n")
check("CAT with no argument -> usage, exit code 2", after(out, "cat") == "Usage: CAT file\r\nExit code 2\r\n")
check("open() accepts A:\\NAME", norm(files["README.TXT"]).replace("\r\n", "\r\n") in after(out, "cat A:\\readme.txt").replace("\r", "").replace("\n", "\r\n"))
out, _ = run(["fstest"])
check("FSTEST (seek/EOF/close/errors/handle table/console write/register preservation)", "FSTEST OK\r\n" in out and "<1><2>" in out, repr(after(out, "fstest")))
out, _ = run(["bigread"])
check("BIGREAD: 60000-byte reads, 32-bit positions, short read at EOF", after(out, "bigread") == "BIGREAD OK\r\n", repr(after(out, "bigread")))
out, _ = run(["fstest", "fstest", "cat long.txt", "fstest", "dir"])
check("handle table is reset for every program (fstest x3 with a CAT between)", out.count("FSTEST OK") == 3 and f"{len(files)} file(s)" in out)

# ---------------- DEL / write path, verified against an independent FAT12 parser ----------------
import fatcheck
def del_test(cmds, victims):
    c = boot(img, "".join(x + "\r" for x in cmds))
    before = fatcheck.parse(img)[2]
    fats, ent, after_files, used = fatcheck.parse(c.img)
    marked = {n for n in range(2, 2847) if ent(fats[0], n) != 0}
    o = "".join(c.out)
    ok_gone = all(v not in after_files for v in victims)
    ok_others = all(after_files[n]["data"] == f["data"] and after_files[n]["chain"] == f["chain"] for n, f in before.items() if n not in victims)
    freed = {cl for v in victims for cl in before[v]["chain"]}
    ok_freed = all(ent(fats[k], cl) == 0 for cl in freed for k in (0, 1))
    leaked = sorted(marked - used)
    ram_fat = bytes(c.mem[0xC000:0xC000 + 9 * 512])
    return dict(c=c, out=o, gone=ok_gone, others=ok_others, freed=ok_freed, leaked=leaked,
                fats_equal=(fats[0] == fats[1]), ram_matches=(ram_fat == fats[0]), fats=fats, ent=ent, files=after_files)
r = del_test(["del hello.txt"], ["HELLO.TXT"])
check("DEL small file: entry gone, cluster freed in both FAT copies, others untouched", r["gone"] and r["freed"] and r["others"] and not r["leaked"] and r["fats_equal"], str(r["leaked"]))
check("DEL: message printed", after(r["out"], "del hello.txt") == "File deleted\r\n")
check("DEL: in-RAM FAT cache equals the FAT on disk", r["ram_matches"])
r = del_test(["del frag.txt", "dir", "type frag.txt", "cat pad.bin"], ["FRAG.TXT"])
check("DEL fragmented file (interleaved with PAD.BIN): chain freed, PAD.BIN intact", r["gone"] and r["freed"] and r["others"] and not r["leaked"] and r["fats_equal"], str(r["leaked"]))
check("after DEL: DIR no longer lists it, TYPE says not found", "FRAG.TXT" not in after(r["out"], "dir") and after(r["out"], "type frag.txt") == "File not found\r\n")
assert fatcheck.parse(img)[2]["SPAN.DAT"]["chain"][-1] == 341, "fixture drifted: SPAN.DAT must end at cluster 341"
r = del_test(["del span.dat"], ["SPAN.DAT"])
check("DEL file whose LAST cluster is 341 (FAT entry straddles a sector): entry is 0, no leak", r["gone"] and r["freed"] and r["ent"](r["fats"][0], 341) == 0 and not r["leaked"], f"entry341={r['ent'](r['fats'][0], 341):#x} leaked={r['leaked'][:5]}")
check("DEL straddling entry: both FAT copies identical and match the RAM copy", r["fats_equal"] and r["ram_matches"] and r["others"])
check("DEL straddling entry: both FAT sectors of BOTH copies were written", {17, 18, 26, 27} <= set(r["c"].disk_writes), str(sorted(set(r["c"].disk_writes))))
r = del_test(["del big.txt", "del long.txt", "del span.dat", "del tail.txt", "del readme.txt"], ["BIG.TXT", "LONG.TXT", "SPAN.DAT", "TAIL.TXT", "README.TXT"])
check("DEL five files in a row (137-cluster chain included)", r["gone"] and r["freed"] and r["others"] and not r["leaked"] and r["fats_equal"] and r["ram_matches"], str(r["leaked"][:6]))
r2 = boot(bytes(r["c"].img), "dir\r"); d2 = after("".join(r2.out), "dir")
check("image still mounts after DELs; DIR agrees with the independent parser", all(n in d2 for n in r["files"]) and not any(n in d2 for n in ["BIG.TXT", "LONG.TXT", "SPAN.DAT", "TAIL.TXT", "README.TXT"]), d2)
out, _ = run(["del", "del nothere.txt", "del docs", "del hello.txt", "del hello.txt", "hello", "del hello.com", "hello"])
check("DEL with no argument", after(out, "del") == "Usage: DEL filename\r\n")
check("DEL missing file / directory", after(out, "del nothere.txt") == "File not found\r\n" and after(out, "del docs") == "File not found\r\n")
i2 = out.index("del hello.txt\r\n"); rest = out[i2: out.index("hello\r\n", i2 + 20)]
check("DEL twice: second time File not found", rest.count("File deleted\r\n") == 1 and "File not found\r\n" in rest)
check("DEL a .COM program: it can no longer be run", out.rstrip().endswith("Bad command or file name\r\nA:\\>") and out.count("Hello from a .COM program!") == 1, repr(out[-140:]))
out, _ = run(["help"])
check("HELP mentions DEL", "DEL f" in out)

# ---------------- AUTOEXEC.BAT / .BAT files ----------------
def one(cmd, before=()):
    o = "".join(boot(img, "".join(x + "\r" for x in before) + cmd + "\r").out)
    i = o.rindex(cmd + "\r\n") + len(cmd) + 2
    return o[i: o.rindex("A:\\>")]
out, _ = run(["ver"])
check("AUTOEXEC.BAT runs at boot (ECHO OFF hides its own lines)", "commands.\r\n\r\nAUTOEXEC.BAT done\r\nA:\\>" in out, repr(out[:200]))
r = del_test(["del autoexec.bat"], ["AUTOEXEC.BAT"])
noauto = bytes(r["c"].img)
o2 = "".join(boot(noauto, "ver\r").out)
check("no AUTOEXEC.BAT: boots straight to the prompt", "commands.\r\n\r\nA:\\>" in o2 and "AUTOEXEC.BAT done" not in o2, repr(o2[:160]))
exp_test = ("batch start\r\n" + "Hello from a .COM program!\r\n" + "[ a  b]\r\nExit code 7\r\n" + "Hello from the disk!\r\n"
            + "A:\\>ECHO echoed now\r\nechoed now\r\n" + "but not this line\r\n" + "A:\\>ECHO indented\r\nindented\r\n")
check("batch: ECHO OFF, REM, :label, @, programs with args, CAT, ECHO ON, indentation", one("test") == exp_test, repr(one("test")))
check("batch: explicit .BAT and RUN", one("TEST.BAT") == exp_test and one("run test") == exp_test)
lf_exp = "A:\\>ECHO one\r\none\r\nA:\\>ECHO two\r\ntwo\r\n"
check("nested batch refused", one("nest") == "A:\\>ECHO before\r\nbefore\r\nA:\\>TEST\r\nBatch files cannot be nested\r\nA:\\>ECHO after\r\nafter\r\n", repr(one("nest")))
check("LF-only line endings and no final newline", one("lf") == lf_exp, repr(one("lf")))
check("ECHO OFF in TEST.BAT does not leak into the next batch (LF.BAT echoes again)", one("lf", before=["test"]) == lf_exp, repr(one("lf", before=["test"])))
check("empty .BAT runs silently (and .COM wins over .BAT for a bare name: EMPTY.COM is refused)", one("empty.bat") == "" and one("empty") == "Bad program\r\n")
check("over-long line is truncated to 63 characters, batch continues", one("longln") == "x" * 58 + "\r\nafter long line\r\n", repr(one("longln")))
out, _ = run(["echo off the wall", "echo off", "echo hi", "echo on", "echo on it", "echo", "echo ON ", "ver"])
check("interactive ECHO: 'OFF THE WALL' is text, bare OFF/ON are silent", after(out, "echo off the wall") == "off the wall\r\n" and after(out, "echo off") == "" and after(out, "echo hi") == "hi\r\n" and after(out, "echo on") == "" and after(out, "echo on it") == "on it\r\n" and after(out, "echo") == "\r\n" and after(out, "echo ON ") == "")

# ---------------- .EXE (MZ) loader ----------------
out, _ = run(["exetest", "EXETEST.EXE", "run exetest", "dir"])
hx = "Hello from an EXE!\r\nExit code 5\r\n"
check("EXE: relocation, own data/stack segment, exit code", after(out, "exetest") == hx, repr(after(out, "exetest")))
check("EXE: explicit extension and RUN", after(out, "EXETEST.EXE") == hx and after(out, "run exetest") == hx)
check("EXE: kernel intact afterwards", f"{len(files)} file(s)" in after(out, "dir"))
out, _ = run(["exe2"])
check("EXE2: 544-byte header, 3 relocs, far call into 2nd code segment, SS:SP and DS=ES=PSP", after(out, "exe2") == "EXE2 OK\r\n", repr(after(out, "exe2")))
out, _ = run(["okexit", "badmz", "tiny", "hdrbig", "badrel", "badseg", "hello"])
check("minimal valid EXE (INT 20h) runs", after(out, "okexit") == "")
for n in ["badmz", "tiny", "hdrbig", "badrel", "badseg"]:
    check(f"malformed EXE refused: {n} -> Bad program", after(out, n) == "Bad program\r\n", repr(after(out, n)))
check("kernel still alive after 5 malformed EXEs", out.rstrip().endswith("Hello from a .COM program!\r\nA:\\>"), repr(out[-90:]))
out, _ = run(["run exe2.exe", "run exe2.com", "run exe2.bat"])
check("extension typed must match", after(out, "run exe2.exe") == "EXE2 OK\r\n" and after(out, "run exe2.com") == "File not found\r\n" and after(out, "run exe2.bat") == "File not found\r\n")

# ---------------- PRINT / PLOT (LPT1 via INT 17h) ----------------
def printed(cmds, fail=False):
    c = boot(img, "".join(x + "\r" for x in cmds), printer_fail=fail)
    return "".join(c.out), bytes(c.printer)
for n in ["README.TXT", "FRAG.TXT", "PAD.BIN", "SPAN.DAT", "BIG.TXT"]:
    o, p = printed([f"print {n.lower()}"])
    check(f"PRINT {n}: {len(files[n]):5d} bytes reach LPT1 unchanged (raw, no CRLF translation)", p == files[n] and after(o, f"print {n.lower()}") == f"{len(files[n])} bytes sent to LPT1\r\n", f"{len(p)} bytes, msg {after(o, 'print ' + n.lower())!r}")
o, p = printed(["print nothere.txt", "print", "print docs"])
check("PRINT: missing file / no argument / directory print nothing", p == b"" and after(o, "print nothere.txt") == "File not found\r\n" and after(o, "print") == "Usage: PRINT filename\r\n" and after(o, "print docs") == "File not found\r\n")
o, p = printed(["print readme.txt", "ver"], fail=True)
check("PRINT with a printer that times out: 'Printer not ready', nothing sent, shell survives", after(o, "print readme.txt") == "Printer not ready\r\n" and p == b"" and "MOSFETQ DOS 0.6 (real" in o, repr(o[-100:]))
hpgl = b"IN;SP1;PA0,0;PD;PA1000,0,1000,1000,0,1000,0,0;PU;PA0,0;PD;PA1000,1000;PU;SP0;"
o, p = printed(["box"])
check("BOX.COM plots an HPGL square+diagonal through handle 4 (PRN)", p == hpgl and after(o, "box") == "", repr(p))
o, p = printed(["box"], fail=True)
check("BOX.COM with a dead printer: DOS error 1Dh (write fault) -> message, exit code 1", after(o, "box") == "BOX: printer error\r\nExit code 1\r\n", repr(after(o, "box")))
o, p = printed(["prntest"])
check("INT 21h AH=05 + handle 4 writes; handle 3 (AUX) is invalid", p == b"OK-hpgl" and after(o, "prntest") == "PRNTEST OK\r\n", f"{p!r} {after(o, 'prntest')!r}")
o, p = printed(["help"])
check("HELP mentions PRINT", "PRINT f" in o)
out5, cpu = run(["reboot"])
check("REBOOT jumps to FFFF:0000", "<<REBOOT>>" in out5)
# boot sector only reads what it should
check("boot read 16 kernel sectors (LBA 1-16) then FAT/root", cpu.disk_reads[:16] == list(range(1, 17)) and cpu.disk_reads[16:30] == list(range(35, 49)) and cpu.disk_reads[30:39] == list(range(17, 26)), str(cpu.disk_reads[:40]))
print("\nALL PASSED" if not fails else f"\n{fails} FAILED")
sys.exit(1 if fails else 0)
