MOSFETQ DOS 0.6
===============
Builds on 0.5 (INT 21h file services, DEL fix).

What is new in 0.6
------------------
* .EXE programs (DOS MZ format): header parsing, relocations, own code/data/stack
  segments, far calls, images up to ~60 KB. Loaded at PSP+10h like real DOS.
* .BAT files and AUTOEXEC.BAT (run automatically at boot, like DOS):
  @ hides a line, REM and :label lines are skipped, ECHO OFF / ECHO ON,
  programs and other commands can be called. Batch files cannot be nested
  (refused with a message). Lines are limited to 63 characters, files to 2048 bytes.
* Name lookup: RUN name / bare name tries NAME.COM, then NAME.EXE, then NAME.BAT.
* Printing and plotting on LPT1 (BIOS INT 17h):
    PRINT file        sends a file byte for byte (text, or an HPGL plot file)
    INT 21h AH=05     print DL
    INT 21h AH=40h    write to handle 4 (PRN)
  BOX.COM is an example: it plots a square with HPGL. With QEMU:
    qemu-system-i386 -fda mosfetq-dos.img -parallel file:plot.hpg

Still missing
-------------
oeneye.exe (8086-emulator based multitasking), MINIX-style messages, LAN,
DXF/SVG -> HPGL conversion, file creation/writing, subdirectories, EXEC.

Build / test
------------
  ./build.sh                 # needs GNU as/ld + Python 3 -> mosfetq-dos.img
  python3 test_dos.py        # boots the image in emu.py and runs 117 checks
  qemu-system-i386 -fda mosfetq-dos.img

The tests run in emu.py, a small 8086 interpreter with a stub BIOS written for
this project. They have NOT been run on QEMU or real hardware.
fatcheck.py is an independent FAT12 reader used to verify what DEL writes to disk.
mkprogs.py hand-assembles the sample .EXE files and writes the .BAT files.
