oeneyeLinuxKernel build kit
============================
I could not build oeneyeLinuxKernel.img myself: this sandbox has no
outbound network access, and the build needs to download a Linux kernel
and a static BusyBox. Run it on your own machine instead.

Contents
--------
build-oeneyeLinux.sh   builds oeneyeLinux.img: standard Linux kernel +
                        BusyBox initramfs, with:
                          - root account, password from ROOT_PASS (default: Linux)
                          - account 36883 (or USER_ACCOUNT), password from
                            USER_PASSWORD (default: Linux)
                          - busybox httpd serving /var/www (a copy of the
                            oeneye payload) on port 80, started at boot
                          - a login prompt (root or 36883) instead of an
                            auto-shell
oeneyeVirtualLab.py     info / run / qemu / ls / add / build-linux front end
build-oeneyeDongle-linux.sh
                        builds oeneyeDongle-linux.img: a bootable Alpine
                        Linux LIVE USB (not the custom kernel/login setup
                        above) with your oeneye files under /oeneye.
                        Needs root, and a Linux host with syslinux+losetup.
build-oeneyeDongle-linux-cd.sh
                        same, but as a bootable ISO/CD image. No root
                        needed; needs xorriso.
                        Both need internet once, to fetch Alpine's ~200 MB
                        install ISO. Neither has been run/tested by me.

Requires: curl cpio gzip sfdisk mkfs.vfat mtools syslinux openssl
  Debian/Ubuntu: apt install curl cpio fdisk dosfstools mtools \
                 syslinux syslinux-common openssl

Build
-----
  mkdir payload && cp /path/to/oeneye/files payload/
  ROOT_PASS=Linux USER_ACCOUNT=36883 USER_PASSWORD=Linux \
      bash build-oeneyeLinux.sh
  # -> oeneyeLinux.img (rename to oeneyeLinuxKernel.img if you like)

Test
----
  python3 oeneyeVirtualLab.py qemu oeneyeLinux.img
  # log in as root or 36883, password Linux (change it first if this
  # will ever be reachable from a real network)
  # curl http://<vm-ip>/  should list /var/www if networking is up

Caveats (unverified - built with no network/QEMU to test against)
-------------------------------------------------------------------
- The Alpine kernel this script downloads by default keeps most drivers,
  including NICs, as loadable modules that are NOT included in the
  initramfs. httpd will start but nothing will reach it over a real NIC
  until you add the right kernel modules or point KERNEL at a
  monolithic build.
- BusyBox login's password check depends on how that BusyBox build was
  compiled (crypt/SHA-512 support). If login rejects the password,
  rebuild BusyBox with SHA-512 crypt enabled, or ask me to switch the
  script to DES/MD5 hashing instead.
- "Container" here means a bootable Linux image with its own kernel
  (like a small VM), not a Docker-style container sharing the host
  kernel.

Author tag: @claude
