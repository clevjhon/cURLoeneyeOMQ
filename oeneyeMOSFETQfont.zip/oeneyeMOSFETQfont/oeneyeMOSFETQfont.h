/*
 * oeneyeMOSFETQfont.h — 8x8 bitmap font for MOSFETQ DOS
 *
 * Original glyph set, hand-authored for this project (not derived from
 * any existing font file). Each glyph is 8 bytes; each byte is one
 * scanline, MSB = leftmost pixel. Covers space, digits 0-9, uppercase
 * A-Z, and a handful of punctuation marks used in boot/status messages
 * (":", ".", "-", "!", "/").
 *
 * Uses a sparse lookup table rather than a dense array over the full
 * ASCII range, since supported characters aren't contiguous. Unsupported
 * characters fall back to a blank glyph.
 *
 * Rendering is resolution/mode-agnostic: oeneyeMOSFETQfont_putchar() just
 * needs a pixel-set callback, so it works the same under VGA mode 13h,
 * a linear framebuffer, or a software test harness.
 */
#ifndef OENEYE_MOSFETQFONT_H
#define OENEYE_MOSFETQFONT_H

#include <stdint.h>

#define OENEYE_FONT_GLYPH_W 8
#define OENEYE_FONT_GLYPH_H 8

/* Build/session marker embedded alongside the font table — a plain
 * identifying tag (like a build ID), not a claim of any reasoning
 * capability. Safe to embed in a FAT12 OEM label field (8 bytes) as
 * provenance metadata, the same slot MOSFETQ DOS images already use. */
typedef struct {
    char     id[9];      /* e.g. "OENEYEfn" (8 chars max) + NUL */
    uint16_t glyph_count;
    uint8_t  glyph_w;
    uint8_t  glyph_h;
} oeneye_font_marker_t;

extern const oeneye_font_marker_t oeneyeMOSFETQfont_marker;

/* Pixel-set callback: framebuffer-agnostic so this compiles the same
 * for VGA mode 13h, a linear 32bpp framebuffer, or a unit-test stub. */
typedef void (*oeneye_pixel_set_fn)(int x, int y, uint8_t on, void *ctx);

/* Blit a single character at (x, y). Unsupported characters render as
 * a blank 8x8 cell (still advances the cursor in puts()). */
void oeneyeMOSFETQfont_putchar(char c, int x, int y,
                                oeneye_pixel_set_fn set_pixel, void *ctx);

/* Blit a NUL-terminated string, advancing 8px per character (no kerning —
 * this is a fixed-width boot/status font, not a UI typeface). */
void oeneyeMOSFETQfont_puts(const char *s, int x, int y,
                             oeneye_pixel_set_fn set_pixel, void *ctx);

#endif /* OENEYE_MOSFETQFONT_H */
