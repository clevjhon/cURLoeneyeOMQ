/*
 * test_render.c — renders a test string to a PPM image using
 * oeneyeMOSFETQfont, so glyphs can be sanity-checked on any machine
 * without needing a DOS/VGA target.
 *
 * Build:  gcc -o test_render test_render.c oeneyeMOSFETQfont.c
 * Run:    ./test_render > out.ppm
 */
#include <stdio.h>
#include <string.h>
#include "oeneyeMOSFETQfont.h"

#define CANVAS_W 200
#define CANVAS_H 16

static uint8_t canvas[CANVAS_H][CANVAS_W];

static void set_pixel(int x, int y, uint8_t on, void *ctx)
{
    (void)ctx;
    if (x < 0 || x >= CANVAS_W || y < 0 || y >= CANVAS_H) return;
    canvas[y][x] = on ? 255 : 0;
}

int main(void)
{
    memset(canvas, 0, sizeof(canvas));

    oeneyeMOSFETQfont_puts("OENEYE-MOSFETQ 1.0", 4, 4, set_pixel, NULL);

    printf("P2\n%d %d\n255\n", CANVAS_W, CANVAS_H);
    for (int y = 0; y < CANVAS_H; y++) {
        for (int x = 0; x < CANVAS_W; x++) {
            printf("%d ", canvas[y][x]);
        }
        printf("\n");
    }

    fprintf(stderr, "marker: id=%s glyphs=%u size=%ux%u\n",
            oeneyeMOSFETQfont_marker.id,
            oeneyeMOSFETQfont_marker.glyph_count,
            oeneyeMOSFETQfont_marker.glyph_w,
            oeneyeMOSFETQfont_marker.glyph_h);
    return 0;
}
