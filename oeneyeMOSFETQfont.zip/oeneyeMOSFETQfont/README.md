# oeneyeMOSFETQfont

An original 8x8 bitmap font for MOSFETQ DOS, plus a small mode-agnostic
blitter, for rendering boot/status text in text mode, VGA graphics mode,
or a plain framebuffer.

## Coverage

42 glyphs: space, `0`–`9`, `A`–`Z`, and `. : - ! /`. Fixed-width, no
kerning — this is a boot/status font, not a UI typeface. Unsupported
characters render as a blank 8x8 cell rather than erroring.

All glyph bitmaps are hand-authored for this project.

## Files

- `oeneyeMOSFETQfont.h` / `.c` — the font data and `putchar`/`puts` blitter
- `test_render.c` — renders a test string to a PPM image so you can sanity
  check glyphs on any machine, no DOS/VGA target needed

## Build & test

```bash
gcc -Wall -o test_render test_render.c oeneyeMOSFETQfont.c
./test_render > out.ppm
```

## Integration

`oeneyeMOSFETQfont_putchar()` / `_puts()` take a pixel-set callback, so
wiring into an actual target is a few lines:

```c
static void vga_set_pixel(int x, int y, uint8_t on, void *ctx) {
    uint8_t *fb = (uint8_t*)0xA0000;      /* mode 13h linear framebuffer */
    if (on) fb[y * 320 + x] = 0x0F;       /* palette index, e.g. white */
}

oeneyeMOSFETQfont_puts("BOOTING", 4, 4, vga_set_pixel, NULL);
```

## Provenance marker (not AGI)

`oeneyeMOSFETQfont_marker` is a plain identifying tag — an 8-byte ID
string plus glyph count/size — meant to sit in the same FAT12 OEM label
field (BPB offset 3–10) that other MOSFETQ DOS build artifacts already
use for provenance marking. It's a build/version tag, the same idea as a
git commit hash embedded in a binary — not a reasoning system, AI
component, or anything beyond a static struct.

```c
typedef struct {
    char     id[9];        /* "OENEYEfn" */
    uint16_t glyph_count;  /* 42 */
    uint8_t  glyph_w;      /* 8 */
    uint8_t  glyph_h;      /* 8 */
} oeneye_font_marker_t;
```
