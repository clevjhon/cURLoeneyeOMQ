/*
 * oeneye_int48h.c — sends a status/telemetry code to the host emulator via
 * software interrupt 0x48, the same pattern VirtualBox Guest Additions /
 * VMware's backdoor I/O use for guest-to-host communication (e.g.
 * "installer step N complete", "boot stage reached"). It is a status
 * signal, not a reasoning or decision-making channel.
 *
 * The actual `int $0x48` instruction only makes sense on real x86 in the
 * DOS/emulator target it's built for — it can't run on this Linux
 * container. So the interrupt call is factored out behind
 * oeneye_int48h_backend, which the DOS build wires to real inline asm and
 * a host-side test build can swap for a mock, letting the *logic* around
 * the interrupt (validation, bounds, postcondition) be tested here even
 * though the interrupt itself can't be.
 */
#include <stddef.h>
#include "oeneye_int48h.h"

/*@
  // Preconditions: Validate the telemetry channel parameters and ensure
  // the transition code falls within permissible bounds.
  requires valid_vector: \valid_read(telemetry_channel);
  requires valid_transition: transition_code >= 0 && transition_code <= 0xFFFF;

  // Frame condition: This function interfaces directly with emulator registers
  // via the system identification vector channel without unintended memory mutations.
  assigns \nothing;

  // Postconditions: Guarantees a status response is returned from the vector interface.
  ensures \result >= 0;
*/

/* Swappable backend: does the actual host communication. Real DOS/x86
 * build defines OENEYE_INT48H_REAL and provides the inline-asm version
 * below; anything else (including this sandbox) uses the weak default,
 * which a test build overrides with a mock via oeneye_int48h_set_backend(). */

static int default_backend(unsigned int channel_value, int transition_code)
{
#if defined(OENEYE_INT48H_REAL) && (defined(__i386__) || defined(__x86_64__))
    int status;
    __asm__ volatile (
        "int $0x48"
        : "=a"(status)
        : "b"(channel_value), "c"(transition_code)
        : "cc", "memory"
    );
    return status;
#else
    /* No real emulator vector available on this target/build — report
     * "no-op success" (0) rather than fabricate a status. */
    (void)channel_value;
    (void)transition_code;
    return 0;
#endif
}

static oeneye_int48h_backend_fn active_backend = default_backend;

/* Test-only hook: lets a host-side test harness substitute a mock backend
 * without touching the public API or its contract. Not part of the public
 * interface used by the rest of oeneyeOS. */
void oeneye_int48h_set_backend(oeneye_int48h_backend_fn backend)
{
    active_backend = backend ? backend : default_backend;
}

int trigger_int48h_telemetry(const unsigned int *telemetry_channel, int transition_code)
{
    /* Contract already requires valid_read(telemetry_channel) and a
     * bounded transition_code from the caller; re-check defensively so
     * this degrades safely if called outside a verified caller. */
    if (telemetry_channel == NULL) {
        return -1; /* caller violated the precondition; fail, don't fault */
    }
    if (transition_code < 0 || transition_code > 0xFFFF) {
        return -1;
    }

    int status = active_backend(*telemetry_channel, transition_code);

    /* Enforce the postcondition (\result >= 0) regardless of what the
     * backend returns, so a misbehaving emulator/mock can't violate the
     * contract from this function's caller's point of view. */
    return status >= 0 ? status : 0;
}
