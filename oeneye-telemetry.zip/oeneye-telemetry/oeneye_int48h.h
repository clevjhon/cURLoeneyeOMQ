#ifndef OENEYE_INT48H_H
#define OENEYE_INT48H_H

/* Public API, matches the ACSL contract exactly. */
int trigger_int48h_telemetry(const unsigned int *telemetry_channel, int transition_code);

/* Test-only: swap the low-level backend for a mock. Not used by the rest
 * of oeneyeOS — only by host-side test builds. */
typedef int (*oeneye_int48h_backend_fn)(unsigned int channel_value, int transition_code);
void oeneye_int48h_set_backend(oeneye_int48h_backend_fn backend);

#endif /* OENEYE_INT48H_H */
