/*
 * test_int48h.c — verifies trigger_int48h_telemetry()'s contract-required
 * behavior using a mock backend (the real `int $0x48` can't run on this
 * host). Covers: precondition rejection (bad transition_code), the
 * always-non-negative postcondition even when the backend misbehaves,
 * and that assigns \nothing holds for telemetry_channel (its pointee is
 * read, never written).
 *
 * Build: gcc -Wall -fsanitize=address,undefined -o test_int48h test_int48h.c oeneye_int48h.c
 * Run:   ./test_int48h
 */
#include <stdio.h>
#include <assert.h>
#include "oeneye_int48h.h"

static int calls = 0;
static unsigned int last_channel_value = 0;
static int last_transition_code = 0;

/* Mock backend: records what it was called with, and can be told to
 * return a negative status to check the postcondition is still enforced. */
static int force_negative = 0;
static int mock_backend(unsigned int channel_value, int transition_code)
{
    calls++;
    last_channel_value = channel_value;
    last_transition_code = transition_code;
    return force_negative ? -42 : (int)(channel_value ^ (unsigned)transition_code);
}

static void check(const char *name, int cond)
{
    printf("[%s] %s\n", name, cond ? "PASS" : "FAIL");
    assert(cond);
}

int main(void)
{
    oeneye_int48h_set_backend(mock_backend);

    /* Case 1: valid inputs -> backend is called, result matches, and the
     * channel value passed to the backend matches *telemetry_channel
     * (confirms it reads through the pointer, doesn't mutate it). */
    {
        unsigned int channel = 0xC0DE;
        int before = (int)channel;
        int r = trigger_int48h_telemetry(&channel, 0x1234);
        check("valid-input-calls-backend", calls == 1);
        check("channel-value-passed-through", last_channel_value == 0xC0DE);
        check("transition-code-passed-through", last_transition_code == 0x1234);
        check("channel-not-mutated", (int)channel == before); /* assigns \nothing */
        check("result-matches-backend", r == (int)(0xC0DE ^ 0x1234));
    }

    /* Case 2: transition_code out of the contract's bound (> 0xFFFF)
     * -> must fail before ever calling the backend. */
    {
        unsigned int channel = 1;
        int calls_before = calls;
        int r = trigger_int48h_telemetry(&channel, 0x10000);
        check("out-of-bounds-code-rejected", r == -1);
        check("out-of-bounds-code-no-backend-call", calls == calls_before);
    }

    /* Case 3: negative transition_code -> also rejected. */
    {
        unsigned int channel = 1;
        int r = trigger_int48h_telemetry(&channel, -5);
        check("negative-code-rejected", r == -1);
    }

    /* Case 4: NULL telemetry_channel -> rejected, not dereferenced. */
    {
        int r = trigger_int48h_telemetry(NULL, 10);
        check("null-channel-rejected", r == -1);
    }

    /* Case 5: postcondition \result >= 0 must hold even if the backend
     * itself returns a negative status. */
    {
        unsigned int channel = 1;
        force_negative = 1;
        int r = trigger_int48h_telemetry(&channel, 10);
        check("postcondition-enforced-despite-bad-backend", r >= 0);
        force_negative = 0;
    }

    printf("\nAll cases passed.\n");
    return 0;
}
