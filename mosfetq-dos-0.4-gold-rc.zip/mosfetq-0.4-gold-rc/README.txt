MOSFETQ DOS 0.4 Gold Release Candidate
======================================

Date: 2026-09-19

This is a gold release candidate of MOSFETQ DOS with the first write-support features.

Based on the original MOSFETQ DOS 0.3
  https://doi.org/10.5281/zenodo.22845198

What is new in 0.4 Gold RC
--------------------------
- write_sector / write_sectors
- fat_get / fat_set (writes both FAT copies)
- find_free_cluster
- free_chain
- DEL filename   command

Still missing (planned for later):
- Creating new files
- Writing data into files
- COPY / redirection

Quick test under QEMU
---------------------
  qemu-system-i386 -fda mosfetq-dos-0.4-gold-rc.img -boot a

Then try:
  DIR
  TYPE README.TXT
  DEL HELLO.TXT
  DIR
  TYPE HELLO.TXT

Files in this package
---------------------
  mosfetq-dos-0.4-gold-rc.img   Bootable 1.44 MB floppy image
  mosfetq-dos.s                 Full assembly source
  mosfetq-dos-write.bin         Linked binary (boot + kernel)
  progs/                        Sample .COM programs + sources
  build.sh, mkimage.py, emu.py  Build & test helpers
  README.txt                    This file

