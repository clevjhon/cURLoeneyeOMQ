# oeneye OS Artwork Bundle (FAT Compatible)

**oeneye OS - ReFS Secure Filesystem - Locked Bundle Artwork**

This is the official artwork package for oeneye OS, formatted for maximum compatibility with FAT12/FAT16/FAT32 filesystems.

## Contents

### /logos
- Bundle preview UI and branding assets

### /loaders
- Infinity eye loader animations (8-frame concepts)
- Busy indicators and pixel strips
- Concept sheets for 32x32 to 128x128

### /cursors
- Custom mouse cursors (Default Arrow, Pointer Hand with Infinity Eye, Text Select I-Beam)
- Pixel art at 32x32 and 64x64

### /boot
- BIOS boot screen (oeneye BIOS v2.1.4)
- VBR Sector 0 loader position reference

### /videos
- Animated loaders (pixel and glowing infinity eyes)
- Logo animations

## Color Palette
- Dark Navy: #0A2F5A
- Light Blue: #2399FF

## Notes
- All assets are read-only ready for locked bundles
- Designed for Secure Boot enabled environments
- Compatible with FAT filesystems for broad device support

oeneye OS - ReFS - Secure Filesystem - Locked Bundle
Version 1.0
