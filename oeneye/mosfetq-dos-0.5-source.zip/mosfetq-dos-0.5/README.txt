MOSFETQ DOS 0.5
===============
Builds on 0.4 Gold RC (write primitives + DEL). Adds INT 21h file services and
fixes a FAT corruption bug in DEL.

What is new
-----------
* INT 21h file services for .COM programs:
    3Dh open (read-only)   3Eh close   3Fh read   42h seek (start/current/end)
    40h write to handles 1 and 2 (console)
  Files get handles 5..12 (8 open files); 0-4 are the standard devices.
  Files are closed automatically when a program ends.
  Error codes: 2 not found, 4 too many open files, 5 access denied (write mode,
  or writing to a file), 6 invalid handle, 19h seek error, 1Eh read fault.
* BUG FIX (present in 0.4-rc1 / gold-rc / nt-oeneye): a FAT12 entry can straddle
  a sector boundary (cluster 341, 1365, 2389, ...). fat_set only wrote the first
  sector, so deleting a file whose chain ends on such a cluster left that entry
  as 0xFF0 (bad cluster) on disk in BOTH FAT copies, permanently leaking it.
  fat_set now flushes both sectors of both FAT copies.
* free_chain / del_entry now report disk errors instead of ignoring them.
* New sample programs: CAT.COM, FSTEST.COM, BIGREAD.COM (see progs/*.s).

Still missing
-------------
File creation and writing to files (3Ch/40h on files), COPY, subdirectories,
running programs from programs (EXEC).

Build / test
------------
  ./build.sh                 # needs GNU as/ld + Python 3 -> mosfetq-dos.img
  python3 test_dos.py        # boots the image in emu.py and runs 84 checks
  qemu-system-i386 -fda mosfetq-dos.img

The tests run in emu.py, a small 8086 interpreter with a stub BIOS written for
this project. They have NOT been run on QEMU or real hardware.
fatcheck.py is an independent FAT12 reader used to verify what DEL writes to
disk (it shares no code with the kernel).
