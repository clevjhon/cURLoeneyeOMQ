"""Independent FAT12 reader used by the tests (does not share code with the kernel)."""
import struct
def parse(img):
    fats = [bytes(img[(17 + i * 9) * 512:(17 + i * 9 + 9) * 512]) for i in range(2)]
    def ent(fat, n):
        o = n + n // 2; w = fat[o] | fat[o + 1] << 8
        return (w >> 4) if n & 1 else (w & 0xFFF)
    root = bytes(img[35 * 512:49 * 512])
    files = {}
    for i in range(0, len(root), 32):
        e = root[i:i + 32]
        if e[0] == 0: break
        if e[0] == 0xE5 or e[11] & 0x08: continue
        name = (e[:8].decode().strip() + "." + e[8:11].decode().strip()).rstrip(".")
        first, size = struct.unpack_from("<HI", e, 26)
        chain, c = [], first
        while 2 <= c < 0xFF8 and len(chain) < 3000:
            chain.append(c); c = ent(fats[0], c)
        data = b"".join(bytes(img[(49 + c - 2) * 512:(49 + c - 1) * 512]) for c in chain)[:size]
        files[name] = dict(first=first, size=size, chain=chain, data=data, attr=e[11])
    used = {c for f in files.values() for c in f["chain"]}
    return fats, ent, files, used
def problems(img):
    fats, ent, files, used = parse(img); out = []
    if fats[0] != fats[1]: 
        diff = [n for n in range(2, 2847) if ent(fats[0], n) != ent(fats[1], n)]
        out.append(f"FAT copies differ at clusters {diff[:8]}")
    marked = {n for n in range(2, 2847) if ent(fats[0], n) != 0}
    owned = used | {c for f in files.values() for c in f["chain"]}
    return out, marked, used
