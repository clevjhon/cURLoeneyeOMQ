# BIGREAD.COM: reads BIG.TXT (70000 bytes) with counts above 64 KB / 32-bit positions.
# Expected checksums come from mkimage.py's BIG.TXT (first 60000 bytes / last 10000 bytes).
.intel_syntax noprefix
.code16
.global _start
.equ BUF, 0x1000
.text
_start:
    mov dx, offset name
    mov ax, 0x3D00
    int 0x21
    jc f1
    mov [fh], ax
    mov bx, ax
    mov dx, BUF
    mov cx, 60000
    mov ah, 0x3F
    int 0x21                        # 1st read: 60000 bytes
    jc f2
    cmp ax, 60000
    jne f2
    call checksum                   # DX = sum of BUF[0..60000)
    cmp dx, 50028
    jne f3
    mov bx, [fh]
    mov dx, BUF
    mov cx, 60000                   # asks for 60000, only 10000 are left
    mov ah, 0x3F
    int 0x21
    jc f4
    cmp ax, 10000
    jne f4
    mov cx, 10000
    call checksum_n
    cmp dx, 51755
    jne f5
    mov bx, [fh]
    mov dx, BUF
    mov cx, 100                     # at EOF: 0 bytes
    mov ah, 0x3F
    int 0x21
    jc f6
    test ax, ax
    jnz f6
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
checksum:
    mov cx, 60000
checksum_n:
    mov si, BUF
    xor dx, dx
sum:
    lodsb
    add dl, al
    adc dh, 0
    loop sum
    ret
f1: mov al, '1'
    jmp fail
f2: mov al, '2'
    jmp fail
f3: mov al, '3'
    jmp fail
f4: mov al, '4'
    jmp fail
f5: mov al, '5'
    jmp fail
f6: mov al, '6'
fail:
    mov [code], al
    mov dx, offset bad
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
fh:   .word 0
name: .asciz "BIG.TXT"
ok:   .ascii "BIGREAD OK\r\n$"
bad:  .ascii "BIGREAD FAILED at step "
code: .ascii "?\r\n$"
