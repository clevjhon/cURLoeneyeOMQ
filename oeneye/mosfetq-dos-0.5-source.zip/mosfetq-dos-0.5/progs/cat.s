# CAT.COM file: copies a file to the console using INT 21h 3Dh/3Fh/40h/3Eh.
# Reads in 100-byte pieces on purpose (not a multiple of the 512-byte sector).
# Exit code 0 = ok, 1 = a DOS call failed (prints "CAT error <code>"), 2 = usage.
.intel_syntax noprefix
.code16
.global _start
.equ BUF,  0x1000
.equ NAME, 0x0F00
.text
_start:
    mov si, 0x81
skip:
    mov al, [si]
    cmp al, ' '
    jne skipped
    inc si
    jmp skip
skipped:
    cmp al, 13
    je usage
    mov di, NAME
copy:
    mov al, [si]
    cmp al, 13
    je copied
    cmp al, ' '
    je copied
    mov [di], al
    inc si
    inc di
    jmp copy
copied:
    mov byte ptr [di], 0
    mov dx, NAME
    mov ax, 0x3D00                  # open, read-only
    int 0x21
    jc fail
    mov [fh], ax
again:
    mov bx, [fh]
    mov dx, BUF
    mov cx, 100
    mov ah, 0x3F                    # read
    int 0x21
    jc fail
    test ax, ax
    jz eof
    mov cx, ax
    mov bx, 1                       # stdout
    mov dx, BUF
    mov ah, 0x40
    int 0x21
    jc fail
    jmp again
eof:
    mov bx, [fh]
    mov ah, 0x3E                    # close
    int 0x21
    jc fail
    mov ax, 0x4C00
    int 0x21
fail:
    add al, '0'
    mov [code], al
    mov dx, offset msg
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
usage:
    mov dx, offset use
    mov ah, 9
    int 0x21
    mov ax, 0x4C02
    int 0x21
fh:   .word 0
msg:  .ascii "CAT error "
code: .ascii "?\r\n$"
use:  .ascii "Usage: CAT file\r\n$"
