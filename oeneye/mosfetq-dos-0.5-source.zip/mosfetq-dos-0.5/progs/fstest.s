# FSTEST.COM: checks INT 21h file services: open/read/seek/close, error codes,
# handle table limits and console writes. Prints "FSTEST OK" or "FSTEST FAILED <letter>"
# (A = test 1, B = test 2, ...). Expected bytes are slices of LONG.TXT from mkimage.py.
.intel_syntax noprefix
.code16
.global _start
.equ BUF, 0x1000
.text
_start:
    # A: open LONG.TXT -> first file handle is 5
    mov dx, offset f_long
    mov ax, 0x3D00
    int 0x21
    jc fA
    cmp ax, 5
    jne fA
    mov [h1], ax
    # B: seek to end -> DX:AX = size (2240)
    mov bx, [h1]
    xor cx, cx
    xor dx, dx
    mov ax, 0x4202
    int 0x21
    jc fB
    test dx, dx
    jnz fB
    cmp ax, 2240
    jne fB
    # C: read at EOF returns 0 bytes
    mov bx, [h1]
    mov dx, BUF
    mov cx, 10
    mov ah, 0x3F
    int 0x21
    jc fC
    test ax, ax
    jnz fC
    # D: seek start, read 8 bytes
    mov bx, [h1]
    xor cx, cx
    xor dx, dx
    mov ax, 0x4200
    int 0x21
    jc fD
    mov bx, [h1]
    mov dx, BUF
    mov cx, 8
    mov ah, 0x3F
    int 0x21
    jc fD
    cmp ax, 8
    jne fD
    mov si, BUF
    mov di, offset e1
    mov cx, 8
    call cmpn
    test ax, ax
    jnz fD
    # E: absolute seek to 1000, read 8 bytes (crosses no sector, offset 488 in sector 1)
    mov bx, [h1]
    xor cx, cx
    mov dx, 1000
    mov ax, 0x4200
    int 0x21
    jc fE
    cmp ax, 1000
    jne fE
    mov bx, [h1]
    mov dx, BUF
    mov cx, 8
    mov ah, 0x3F
    int 0x21
    jc fE
    cmp ax, 8
    jne fE
    mov si, BUF
    mov di, offset e2
    mov cx, 8
    call cmpn
    test ax, ax
    jnz fE
    # F: relative seek -16 from current (1008) -> 992, read 8 bytes (spans the 512-byte boundary? no: 992 is in sector 1)
    mov bx, [h1]
    mov cx, 0xFFFF
    mov dx, 0xFFF0
    mov ax, 0x4201
    int 0x21
    jc fF
    test dx, dx
    jnz fF
    cmp ax, 992
    jne fF
    mov bx, [h1]
    mov dx, BUF
    mov cx, 8
    mov ah, 0x3F
    int 0x21
    jc fF
    mov si, BUF
    mov di, offset e3
    mov cx, 8
    call cmpn
    test ax, ax
    jnz fF
    # G: seek before the start of the file -> CF=1, AX=19h
    mov bx, [h1]
    mov cx, 0xFFFF
    mov dx, 0xFFFF
    mov ax, 0x4200
    int 0x21
    jnc fG
    cmp ax, 0x19
    jne fG
    # H: seek to end-6, ask for 100 bytes, get exactly 6
    mov bx, [h1]
    mov cx, 0xFFFF
    mov dx, 0xFFFA
    mov ax, 0x4202
    int 0x21
    jc fH
    cmp ax, 2234
    jne fH
    mov bx, [h1]
    mov dx, BUF
    mov cx, 100
    mov ah, 0x3F
    int 0x21
    jc fH
    cmp ax, 6
    jne fH
    mov si, BUF
    mov di, offset e8
    mov cx, 6
    call cmpn
    test ax, ax
    jnz fH
    # I: close ok, second close -> CF=1 AX=6, read on closed handle -> AX=6
    mov bx, [h1]
    mov ah, 0x3E
    int 0x21
    jc fI
    mov bx, [h1]
    mov ah, 0x3E
    int 0x21
    jnc fI
    cmp ax, 6
    jne fI
    mov bx, [h1]
    mov dx, BUF
    mov cx, 1
    mov ah, 0x3F
    int 0x21
    jnc fI
    cmp ax, 6
    jne fI
    # J: missing file -> AX=2; a directory -> AX=2; write mode -> AX=5
    mov dx, offset f_none
    mov ax, 0x3D00
    int 0x21
    jnc fJ
    cmp ax, 2
    jne fJ
    mov dx, offset f_dir
    mov ax, 0x3D00
    int 0x21
    jnc fJ
    cmp ax, 2
    jne fJ
    mov dx, offset f_long
    mov ax, 0x3D01
    int 0x21
    jnc fJ
    cmp ax, 5
    jne fJ
    # K: "A:\README.TXT" (drive + backslash) opens; slot 0 is free again -> handle 5
    mov dx, offset f_path
    mov ax, 0x3D00
    int 0x21
    jc fK
    cmp ax, 5
    jne fK
    mov [h1], ax
    # L: writing to a file handle is refused (AX=5)
    mov bx, [h1]
    mov dx, offset e1
    mov cx, 1
    mov ah, 0x40
    int 0x21
    jnc fL
    cmp ax, 5
    jne fL
    # M: the open-file table holds 8 files: 7 more opens succeed, the 8th fails with AX=4
    mov word ptr [cnt], 1
mloop:
    mov dx, offset f_readme
    mov ax, 0x3D00
    int 0x21
    jc mfull
    inc word ptr [cnt]
    cmp word ptr [cnt], 20
    jb mloop
    jmp fM
mfull:
    cmp ax, 4
    jne fM
    cmp word ptr [cnt], 8
    jne fM
    # N: closing handle 7 frees exactly that slot -> next open returns 7
    mov bx, 7
    mov ah, 0x3E
    int 0x21
    jc fN
    mov dx, offset f_readme
    mov ax, 0x3D00
    int 0x21
    jc fN
    cmp ax, 7
    jne fN
    # O: console writes via handles 1 and 2 return the count; handles 0 and 3 are invalid (AX=6)
    mov bx, 1
    mov dx, offset s1
    mov cx, 3
    mov ah, 0x40
    int 0x21
    jc fO
    cmp ax, 3
    jne fO
    mov bx, 2
    mov dx, offset s2
    mov cx, 3
    mov ah, 0x40
    int 0x21
    jc fO
    cmp ax, 3
    jne fO
    mov bx, 0
    mov dx, offset s1
    mov cx, 1
    mov ah, 0x40
    int 0x21
    jnc fO
    cmp ax, 6
    jne fO
    mov bx, 3
    mov ah, 0x40
    int 0x21
    jnc fO
    cmp ax, 6
    jne fO
    # P: zero-byte read, and the registers a caller expects to survive really do
    mov si, 0x1234
    mov di, 0x5678
    mov bp, 0x9ABC
    mov bx, 5
    mov cx, 0
    mov dx, BUF
    mov ah, 0x3F
    int 0x21
    jc fP
    test ax, ax
    jnz fP
    cmp si, 0x1234
    jne fP
    cmp di, 0x5678
    jne fP
    cmp bp, 0x9ABC
    jne fP
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
cmpn:                               # SI=actual, DI=expected, CX=count -> AX=0 if equal
    mov al, [si]
    cmp al, [di]
    jne cmpbad
    inc si
    inc di
    loop cmpn
    xor ax, ax
    ret
cmpbad:
    mov ax, 1
    ret
fA: mov al, 'A'
    jmp fail
fB: mov al, 'B'
    jmp fail
fC: mov al, 'C'
    jmp fail
fD: mov al, 'D'
    jmp fail
fE: mov al, 'E'
    jmp fail
fF: mov al, 'F'
    jmp fail
fG: mov al, 'G'
    jmp fail
fH: mov al, 'H'
    jmp fail
fI: mov al, 'I'
    jmp fail
fJ: mov al, 'J'
    jmp fail
fK: mov al, 'K'
    jmp fail
fL: mov al, 'L'
    jmp fail
fM: mov al, 'M'
    jmp fail
fN: mov al, 'N'
    jmp fail
fO: mov al, 'O'
    jmp fail
fP: mov al, 'P'
fail:
    mov [code], al
    mov dx, offset bad
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
h1:   .word 0
cnt:  .word 0
f_long:   .asciz "LONG.TXT"
f_none:   .asciz "NOPE.TXT"
f_dir:    .asciz "DOCS"
f_path:   .asciz "A:\\README.TXT"
f_readme: .asciz "README.TXT"
s1:   .ascii "<1>"
s2:   .ascii "<2>"
e1:
    .byte 76, 105, 110, 101, 32, 48, 48, 49
e2:
    .byte 121, 32, 100, 111, 103, 46, 13, 10
e3:
    .byte 32, 116, 104, 101, 32, 108, 97, 122
e8:
    .byte 100, 111, 103, 46, 13, 10
ok:   .ascii "FSTEST OK\r\n$"
bad:  .ascii "FSTEST FAILED "
code: .ascii "?\r\n$"
