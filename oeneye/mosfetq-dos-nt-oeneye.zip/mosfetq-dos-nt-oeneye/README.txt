MOSFETQ DOS NT oeneye
=====================

Bootable real-mode DOS with FAT12 + first write support (DEL command).

Based on MOSFETQ DOS 0.3 (Zenodo 10.5281/zenodo.22845198)

Features
--------
- DIR, TYPE, DEL, RUN, HELP, VER, CLS, ECHO, MEM, TIME, DATE, REBOOT
- write_sector, fat_get/fat_set, find_free_cluster, free_chain
- Sample .COM programs

Test
----
  qemu-system-i386 -fda mosfetq-dos-nt-oeneye.img -boot a

  DIR
  DEL HELLO.TXT
  DIR
