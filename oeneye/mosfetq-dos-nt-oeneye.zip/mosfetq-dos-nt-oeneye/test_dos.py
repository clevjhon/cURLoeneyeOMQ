import re, sys
from emu import boot
img = open("mosfetq-dos.img", "rb").read()
fails = 0
def run(cmds):
    c = boot(img, "".join(x + "\r" for x in cmds) if isinstance(cmds, list) else cmds)
    return "".join(c.out), c
def norm(b):  # what TYPE should print: CR dropped, LF -> CRLF
    return b.replace(b"\r", b"").replace(b"\n", b"\r\n").decode() 
def check(name, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  " + extra))
    fails += (not cond)
def after(out, cmd):  # text between the echoed command and the next prompt
    i = out.index(cmd + "\r\n") + len(cmd) + 2
    return out[i: out.index("A:\\>", i)]

files = {}
import struct
root = img[35*512: 35*512 + 14*512]
def clusters(first):
    fat = img[17*512: 17*512 + 9*512]; ch = []; c = first
    while 2 <= c < 0xFF8:
        ch.append(c); o = c + c // 2; w = fat[o] | fat[o+1] << 8; c = (w >> 4) if c & 1 else (w & 0xFFF)
    return ch
for i in range(0, len(root), 32):
    e = root[i:i+32]
    if e[0] in (0, 0xE5) or e[11] & 0x18: continue
    name = (e[:8].decode().strip() + "." + e[8:11].decode().strip()).rstrip(".")
    first, size = struct.unpack_from("<HI", e, 26)
    data = b"".join(img[(49 + c - 2) * 512:(49 + c - 1) * 512] for c in clusters(first))[:size]
    files[name] = data

out, cpu = run(["dir"])
d = after(out, "dir")
print(d)
check("boot banner", "MOSFETQ DOS 0.3" in out and "Loading MOSFETQ DOS" in out)
check("DIR lists all files", all(n in d for n in files) and f"{len(files)} file(s)" in d and "1 dir(s)" in d, d)
check("DIR shows <DIR> for DOCS", re.search(r"DOCS\s+<DIR>", d) is not None)
check("DIR hides label and deleted entries", "OLD" not in d and "MOSFETQ" not in d.split("\r\n",2)[2])
check("DIR sizes correct", all(re.search(re.escape(n) + r"\s+" + str(len(v)) + r" bytes", d) for n, v in files.items()), d)

for n in ["README.TXT", "HELLO.TXT", "LONG.TXT", "FRAG.TXT", "BIG.TXT"]:
    out, _ = run(["type " + n])
    got = after(out, "type " + n)
    exp = norm(files[n]) + "\r\n"
    check(f"TYPE {n} ({len(files[n])} B) exact", got == exp, f"got {len(got)} chars, want {len(exp)}")
out, _ = run(["TyPe   frag.txt"])   # case-insensitive + extra spaces
check("case-insensitive TYPE + multiple spaces", after(out, "TyPe   frag.txt") == norm(files["FRAG.TXT"]) + "\r\n")
out, _ = run(["type nofile.txt", "type readme", "type DOCS", "type", "type MOSFETQ"])
check("TYPE missing file", after(out, "type nofile.txt") == "File not found\r\n")
check("TYPE name without extension not found", after(out, "type readme") == "File not found\r\n")
check("TYPE on a directory refused", after(out, "type DOCS") == "File not found\r\n")
check("TYPE with no argument", after(out, "type") == "Usage: TYPE filename\r\n")
check("TYPE volume label refused", after(out, "type MOSFETQ") == "File not found\r\n")
out, _ = run(["frobnicate", "dirx", "echo Hi  There", "mem", "time", "date", "help", "ver"])
check("unknown command", after(out, "frobnicate") == "Bad command or file name\r\n")
check("'dirx' is not DIR", after(out, "dirx") == "Bad command or file name\r\n")
check("ECHO keeps case/spacing", after(out, "echo Hi  There") == "Hi  There\r\n")
check("MEM", after(out, "mem") == "639 KB conventional memory\r\n")
check("TIME", after(out, "time") == "12:34:56\r\n")
check("DATE", after(out, "date") == "2026-09-19\r\n")
check("HELP lists TYPE", "TYPE f" in after(out, "help"))
out2, _ = run("dirz\x08\r")        # "dirz" + backspace = "dir"
check("backspace editing", f"{len(files)} file(s)" in out2 and "Bad command" not in out2, out2[-80:])
out3, _ = run("\x08\x08\x08ver\r")   # backspace on empty line must not underflow
check("backspace on empty line is harmless", "MOSFETQ DOS 0.3 (real" in out3)
out4, _ = run("abcdefghij" * 7 + "\rver\r")
check("input longer than 63 chars is truncated safely", "Bad command" in out4 and "MOSFETQ DOS 0.3 (real" in out4)

# ---------------- .COM loader / INT 21h ----------------
out, cpu = run(["hello", "HELLO.COM", "run hello", "RUN Hello.Com", "dir"])
hello = "Hello from a .COM program!\r\n"
check("bare name runs NAME.COM", after(out, "hello") == hello)
check("explicit extension + uppercase", after(out, "HELLO.COM") == hello)
check("RUN command", after(out, "run hello") == hello)
check("RUN mixed case", after(out, "RUN Hello.Com") == hello)
check("kernel intact after 4 program runs (DIR still works)", f"{len(files)} file(s)" in after(out, "dir"))
out, _ = run(["run args", "args a b  c", "ARGS"])
check("PSP command tail: none", after(out, "run args") == "[]\r\nExit code 7\r\n", repr(after(out, "run args")))
check("PSP command tail: args keep spacing", after(out, "args a b  c") == "[ a b  c]\r\nExit code 7\r\n", repr(after(out, "args a b  c")))
out, _ = run("line\rBob\rline\rABCDEFGHIJKLMNOP\r")
check("AH=0Ah buffered input", "Name? Bob\r\nYou typed: Bob\r\n" in out, repr(out[-120:]))
check("AH=0Ah honours the max length (9 chars + CR)", "You typed: ABCDEFGHI\r\n" in out, repr(out[-120:]))
out, _ = run("line\rabc\x08\x08Z\rver\r")
check("AH=0Ah backspace", "You typed: aZ\r\n" in out, repr(out[-120:]))
out, _ = run(["vec"])
check("AH=25/35 vectors + user INT 60h", after(out, "vec") == "Hok\r\n", repr(after(out, "vec")))
out, _ = run(["segs"])
check("startup env: DS=ES=SS=CS, SP, PSP INT 20h, DOS version, unknown fn -> CF", after(out, "segs") == "SEGS OK\r\n", repr(after(out, "segs")))
out, _ = run("key\rq")
check("AH=0Bh poll + AH=08 read key", after(out, "key") == "Key: q\r\n", repr(after(out, "key")))
out, _ = run(["ret", "ver"])
check("plain RET terminates via PSP:0", after(out, "ret") == "R\n" and "MOSFETQ DOS 0.3 (real" in out, repr(out[-80:]))
out, _ = run(["toobig", "empty", "run toobig.com", "run empty", "run", "nothere", "run nothere", "run readme.txt", "run docs", "README.TXT"])
check("too big refused", after(out, "toobig") == "Program too big\r\n", repr(after(out, "toobig")))
check("empty refused", after(out, "empty") == "Bad program\r\n")
check("RUN with no arg", after(out, "run") == "Usage: RUN program [arguments]\r\n")
check("unknown bare name", after(out, "nothere") == "Bad command or file name\r\n")
check("RUN missing program", after(out, "run nothere") == "File not found\r\n")
check("RUN of a non-.COM file", after(out, "run readme.txt") == "File not found\r\n")
check("RUN of a directory", after(out, "run docs") == "File not found\r\n")
check("bare non-.COM file name is a bad command", after(out, "README.TXT") == "Bad command or file name\r\n")
out, _ = run(["help"])
check("HELP mentions RUN", "RUN p" in out)
out, _ = run(["segs", "vec", "hello", "args", "dir", "type long.txt"])
check("run programs then TYPE a multi-cluster file", norm(files["LONG.TXT"]) in out)
out5, cpu = run(["reboot"])
check("REBOOT jumps to FFFF:0000", "<<REBOOT>>" in out5)
# boot sector only reads what it should
check("boot read 16 kernel sectors (LBA 1-16) then FAT/root", cpu.disk_reads[:16] == list(range(1, 17)) and cpu.disk_reads[16:30] == list(range(35, 49)) and cpu.disk_reads[30:39] == list(range(17, 26)), str(cpu.disk_reads[:40]))
print("\nALL PASSED" if not fails else f"\n{fails} FAILED")
sys.exit(1 if fails else 0)
