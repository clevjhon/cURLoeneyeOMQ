.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov dx, offset msg
    mov ah, 9
    int 0x21
    int 0x20
msg: .ascii "Hello from a .COM program!\r\n$"
