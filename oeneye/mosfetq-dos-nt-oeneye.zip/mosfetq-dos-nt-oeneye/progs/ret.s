# RET.COM: terminates with a plain RET (returns to PSP:0 = INT 20h)
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov dl, 'R'
    mov ah, 2
    int 0x21
    mov dl, 10
    int 0x21
    ret
