# ARGS.COM: prints the command tail as [ tail ], exits with code 7
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov dl, '['
    mov ah, 2
    int 0x21
    xor cx, cx
    mov cl, [0x80]              # length byte of the command tail
    test cx, cx
    jz done
    mov si, 0x81
next:
    lodsb
    mov dl, al
    mov ah, 2
    int 0x21
    loop next
done:
    mov dl, ']'
    mov ah, 2
    int 0x21
    mov dx, offset crlf
    mov ah, 9
    int 0x21
    mov ax, 0x4C07              # exit code 7
    int 0x21
crlf: .ascii "\r\n$"
