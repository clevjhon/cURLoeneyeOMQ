# KEY.COM: poll INT 21h AH=0Bh, then read one key with AH=08 (no echo)
.intel_syntax noprefix
.code16
.global _start
.text
_start:
wait:
    mov ah, 0x0B
    int 0x21
    test al, al
    jz wait
    mov ah, 8
    int 0x21
    mov [k], al
    mov dx, offset m
    mov ah, 9
    int 0x21
    mov dl, [k]
    mov ah, 2
    int 0x21
    mov dx, offset crlf
    mov ah, 9
    int 0x21
    int 0x20
k:    .byte 0
m:    .ascii "Key: $"
crlf: .ascii "\r\n$"
