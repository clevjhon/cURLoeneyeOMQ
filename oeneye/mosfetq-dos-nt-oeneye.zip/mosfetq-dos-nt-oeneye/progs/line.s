# LINE.COM: INT 21h AH=0Ah buffered input (max 10 chars incl. CR)
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov dx, offset prompt
    mov ah, 9
    int 0x21
    mov dx, offset buf
    mov ah, 0x0A
    int 0x21
    mov dx, offset typed
    mov ah, 9
    int 0x21
    xor cx, cx
    mov cl, [buf+1]
    mov si, offset buf + 2
    test cx, cx
    jz done
p:  lodsb
    mov dl, al
    mov ah, 2
    int 0x21
    loop p
done:
    mov dx, offset crlf
    mov ah, 9
    int 0x21
    int 0x20
buf:    .byte 10, 0
        .space 12
prompt: .ascii "Name? $"
typed:  .ascii "You typed: $"
crlf:   .ascii "\r\n$"
