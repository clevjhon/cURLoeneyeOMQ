# SEGS.COM: checks the .COM startup environment and error return of INT 21h
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov ax, cs
    mov bx, ds
    cmp ax, bx
    jne bad
    mov bx, es
    cmp ax, bx
    jne bad
    mov bx, ss
    cmp ax, bx
    jne bad
    cmp ax, 0x1000
    jne bad
    cmp sp, 0xFFFC              # 0 pushed as the return address
    jne bad
    cmp word ptr [0], 0x20CD    # PSP:0 = INT 20h
    jne bad
    cmp cx, 0x00FF
    jne bad
    mov ah, 0x30
    int 0x21
    cmp al, 3
    jne bad
    mov ah, 0x99                # unsupported function -> CF=1, AX=1
    int 0x21
    jnc bad
    cmp ax, 1
    jne bad
    mov dx, offset ok
    mov ah, 9
    int 0x21
    ret                         # ends via PSP:0 (INT 20h)
bad:
    mov dx, offset no
    mov ah, 9
    int 0x21
    mov ax, 0x4C02
    int 0x21
ok: .ascii "SEGS OK\r\n$"
no: .ascii "SEGS FAILED\r\n$"
