# VEC.COM: INT 21h AH=25/35 set/get vector, then call our own INT 60h
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov dx, offset handler
    mov ax, 0x2560
    int 0x21
    mov ax, 0x3560
    int 0x21                    # ES:BX = vector 60h
    mov ax, cs
    mov cx, es
    cmp ax, cx
    jne bad
    cmp bx, offset handler
    jne bad
    int 0x60
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
bad:
    mov dx, offset no
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
handler:
    mov dl, 'H'
    mov ah, 2
    int 0x21
    iret
ok: .ascii "ok\r\n$"
no: .ascii "VEC FAILED\r\n$"
