#!/bin/sh
# Needs GNU binutils (as, ld) and Python 3. Produces mosfetq-dos.img (1.44 MB FAT12 floppy).
set -e
as --32 -o mosfetq-dos.o mosfetq-dos.s
ld -m elf_i386 -Ttext=0x7C00 --oformat binary -o mosfetq-dos.bin mosfetq-dos.o
# sample .COM programs (flat binaries loaded at offset 0x100)
for f in progs/*.s; do
    n=$(basename "$f" .s)
    as --32 -o "progs/$n.o" "$f"
    ld -m elf_i386 -Ttext=0x100 --oformat binary -o "progs/$(echo $n | tr a-z A-Z).COM" "progs/$n.o"
done
python3 mkimage.py
