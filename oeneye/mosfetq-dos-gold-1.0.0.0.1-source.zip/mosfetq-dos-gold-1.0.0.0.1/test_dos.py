import os
import re, sys
from emu import boot
IMG = os.environ.get("IMG", "mosfetq-dos.img")
img = open(IMG, "rb").read()
import geom; G = geom.geom(img)
fails = 0
def run(cmds):
    c = boot(img, "".join(x + "\r" for x in cmds) if isinstance(cmds, list) else cmds)
    return "".join(c.out), c
def norm(b):  # what TYPE should print: CR dropped, LF -> CRLF
    return b.replace(b"\r", b"").replace(b"\n", b"\r\n").decode() 
def check(name, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  " + extra))
    fails += (not cond)
def after(out, cmd):  # text between the echoed command and the next prompt
    i = out.index(cmd + "\r\n") + len(cmd) + 2
    return out[i: out.index("A:\\>", i)]

files = {}
import struct
root = img[G['root_lba']*512: G['data_lba']*512]
def clusters(first):
    fat = img[G['fat_lba']*512: (G['fat_lba'] + G['fat_sect'])*512]; ch = []; c = first
    while 2 <= c < 0xFF8:
        ch.append(c); o = c + c // 2; w = fat[o] | fat[o+1] << 8; c = (w >> 4) if c & 1 else (w & 0xFFF)
    return ch
for i in range(0, len(root), 32):
    e = root[i:i+32]
    if e[0] in (0, 0xE5) or e[11] & 0x18: continue
    name = (e[:8].decode().strip() + "." + e[8:11].decode().strip()).rstrip(".")
    first, size = struct.unpack_from("<HI", e, 26)
    data = b"".join(img[(G['data_lba'] + c - 2) * 512:(G['data_lba'] + c - 1) * 512] for c in clusters(first))[:size]
    files[name] = data

out, cpu = run(["dir"])
d = after(out, "dir")
print(d)
check("boot banner", "MOSFETQ DOS Gold 1.0.0.0.1" in out and "Loading MOSFETQ DOS" in out)
check("DIR lists all files", all(n in d for n in files) and f"{len(files)} file(s)" in d and "1 dir(s)" in d, d)
check("DIR shows <DIR> for DOCS", re.search(r"DOCS\s+<DIR>", d) is not None)
check("DIR hides label and deleted entries", "OLD" not in d and "MOSFETQ" not in d.split("\r\n",2)[2])
check("DIR sizes correct", all(re.search(re.escape(n) + r"\s+" + str(len(v)) + r" bytes", d) for n, v in files.items()), d)

for n in ["README.TXT", "HELLO.TXT", "LONG.TXT", "FRAG.TXT", "BIG.TXT"]:
    out, _ = run(["type " + n])
    got = after(out, "type " + n)
    exp = norm(files[n]) + "\r\n"
    check(f"TYPE {n} ({len(files[n])} B) exact", got == exp, f"got {len(got)} chars, want {len(exp)}")
out, _ = run(["TyPe   frag.txt"])   # case-insensitive + extra spaces
check("case-insensitive TYPE + multiple spaces", after(out, "TyPe   frag.txt") == norm(files["FRAG.TXT"]) + "\r\n")
out, _ = run(["type nofile.txt", "type readme", "type DOCS", "type", "type MOSFETQ"])
check("TYPE missing file", after(out, "type nofile.txt") == "File not found\r\n")
check("TYPE name without extension not found", after(out, "type readme") == "File not found\r\n")
check("TYPE on a directory refused", after(out, "type DOCS") == "File not found\r\n")
check("TYPE with no argument", after(out, "type") == "Usage: TYPE filename\r\n")
check("TYPE volume label refused", after(out, "type MOSFETQ") == "File not found\r\n")
out, _ = run(["frobnicate", "dirx", "echo Hi  There", "mem", "time", "date", "help", "ver"])
check("unknown command", after(out, "frobnicate") == "Bad command or file name\r\n")
check("'dirx' is not DIR", after(out, "dirx") == "Bad command or file name\r\n")
check("ECHO keeps case/spacing", after(out, "echo Hi  There") == "Hi  There\r\n")
check("MEM", after(out, "mem") == "639 KB conventional memory\r\n")
check("TIME", after(out, "time") == "12:34:56\r\n")
check("DATE", after(out, "date") == "2026-09-19\r\n")
check("HELP lists TYPE", "TYPE f" in after(out, "help"))
out2, _ = run("dirz\x08\r")        # "dirz" + backspace = "dir"
check("backspace editing", f"{len(files)} file(s)" in out2 and "Bad command" not in out2, out2[-80:])
out3, _ = run("\x08\x08\x08ver\r")   # backspace on empty line must not underflow
check("backspace on empty line is harmless", "MOSFETQ DOS Gold 1.0.0.0.1 (real" in out3)
out4, _ = run("abcdefghij" * 14 + "\rver\r")
check("input longer than the 126-character line limit is truncated safely", "Bad command" in out4 and "MOSFETQ DOS Gold 1.0.0.0.1 (real" in out4)

# ---------------- .COM loader / INT 21h ----------------
out, cpu = run(["hello", "HELLO.COM", "run hello", "RUN Hello.Com", "dir"])
hello = "Hello from a .COM program!\r\n"
check("bare name runs NAME.COM", after(out, "hello") == hello)
check("explicit extension + uppercase", after(out, "HELLO.COM") == hello)
check("RUN command", after(out, "run hello") == hello)
check("RUN mixed case", after(out, "RUN Hello.Com") == hello)
check("kernel intact after 4 program runs (DIR still works)", f"{len(files)} file(s)" in after(out, "dir"))
out, _ = run(["run args", "args a b  c", "ARGS"])
check("PSP command tail: none", after(out, "run args") == "[]\r\nExit code 7\r\n", repr(after(out, "run args")))
check("PSP command tail: args keep spacing", after(out, "args a b  c") == "[ a b  c]\r\nExit code 7\r\n", repr(after(out, "args a b  c")))
out, _ = run("line\rBob\rline\rABCDEFGHIJKLMNOP\r")
check("AH=0Ah buffered input", "Name? Bob\r\nYou typed: Bob\r\n" in out, repr(out[-120:]))
check("AH=0Ah honours the max length (9 chars + CR)", "You typed: ABCDEFGHI\r\n" in out, repr(out[-120:]))
out, _ = run("line\rabc\x08\x08Z\rver\r")
check("AH=0Ah backspace", "You typed: aZ\r\n" in out, repr(out[-120:]))
out, _ = run(["vec"])
check("AH=25/35 vectors + user INT 60h", after(out, "vec") == "Hok\r\n", repr(after(out, "vec")))
out, _ = run(["segs"])
check("startup env: DS=ES=SS=CS, SP, PSP INT 20h, DOS version, unknown fn -> CF", after(out, "segs") == "SEGS OK\r\n", repr(after(out, "segs")))
out, _ = run("key\rq")
check("AH=0Bh poll + AH=08 read key", after(out, "key") == "Key: q\r\n", repr(after(out, "key")))
out, _ = run(["ret", "ver"])
check("plain RET terminates via PSP:0", after(out, "ret") == "R\n" and "MOSFETQ DOS Gold 1.0.0.0.1 (real" in out, repr(out[-80:]))
out, _ = run(["toobig", "empty", "run toobig.com", "run empty", "run", "nothere", "run nothere", "run readme.txt", "run docs", "README.TXT"])
check("too big refused", after(out, "toobig") == "Program too big\r\n", repr(after(out, "toobig")))
check("empty refused", after(out, "empty") == "Bad program\r\n")
check("RUN with no arg", after(out, "run") == "Usage: RUN program [arguments]\r\n")
check("unknown bare name", after(out, "nothere") == "Bad command or file name\r\n")
check("RUN missing program", after(out, "run nothere") == "File not found\r\n")
check("RUN of a non-.COM file", after(out, "run readme.txt") == "File not found\r\n")
check("RUN of a directory", after(out, "run docs") == "File not found\r\n")
check("bare non-.COM file name is a bad command", after(out, "README.TXT") == "Bad command or file name\r\n")
out, _ = run(["help"])
check("HELP mentions RUN", "RUN p" in out)
out, _ = run(["segs", "vec", "hello", "args", "dir", "type long.txt"])
check("run programs then TYPE a multi-cluster file", norm(files["LONG.TXT"]) in out)

# ---------------- INT 21h file services ----------------
def cat(name, keys_extra=""):
    c = boot(img, f"cat {name}\r" + keys_extra)
    o = "".join(c.out); i = o.index(f"cat {name}\r\n") + len(f"cat {name}\r\n")
    return o[i: o.rindex("A:\\>")]
for n in ["README.TXT", "HELLO.TXT", "TAIL.TXT", "LONG.TXT", "FRAG.TXT", "PAD.BIN", "SPAN.DAT", "BIG.TXT", "hello.com", "Readme.Txt"]:
    key = n.upper()
    got = cat(n).encode("latin-1")
    check(f"CAT {n}: {len(files[key]):5d} bytes read via 3Dh/3Fh/40h are byte-exact", got == files[key], f"got {len(got)} bytes, want {len(files[key])}")
out, _ = run(["cat nothere.txt", "cat docs", "cat", "cat A:\\readme.txt"])
check("CAT missing file -> DOS error 2, exit code 1", after(out, "cat nothere.txt") == "CAT error 2\r\nExit code 1\r\n", repr(after(out, "cat nothere.txt")))
check("CAT directory -> DOS error 2", after(out, "cat docs") == "CAT error 2\r\nExit code 1\r\n")
check("CAT with no argument -> usage, exit code 2", after(out, "cat") == "Usage: CAT file\r\nExit code 2\r\n")
check("open() accepts A:\\NAME", norm(files["README.TXT"]).replace("\r\n", "\r\n") in after(out, "cat A:\\readme.txt").replace("\r", "").replace("\n", "\r\n"))
out, _ = run(["fstest"])
check("FSTEST (seek/EOF/close/errors/handle table/console write/register preservation)", "FSTEST OK\r\n" in out and "<1><2>" in out, repr(after(out, "fstest")))
out, _ = run(["bigread"])
check("BIGREAD: 60000-byte reads, 32-bit positions, short read at EOF", after(out, "bigread") == "BIGREAD OK\r\n", repr(after(out, "bigread")))
out, _ = run(["fstest", "fstest", "cat long.txt", "fstest", "dir"])
check("handle table is reset for every program (fstest x3 with a CAT between)", out.count("FSTEST OK") == 3 and f"{len(files)} file(s)" in out)

# ---------------- DEL / write path, verified against an independent FAT12 parser ----------------
import fatcheck
def del_test(cmds, victims):
    c = boot(img, "".join(x + "\r" for x in cmds))
    before = fatcheck.parse(img)[2]
    fats, ent, after_files, used = fatcheck.parse(c.img)
    marked = {n for n in range(2, G['maxclu']) if ent(fats[0], n) != 0}
    o = "".join(c.out)
    ok_gone = all(v not in after_files for v in victims)
    ok_others = all(after_files[n]["data"] == f["data"] and after_files[n]["chain"] == f["chain"] for n, f in before.items() if n not in victims)
    freed = {cl for v in victims for cl in before[v]["chain"]}
    ok_freed = all(ent(fats[k], cl) == 0 for cl in freed for k in (0, 1))
    leaked = sorted(marked - used)
    ram_fat = bytes(c.mem[0xC000:0xC000 + G['fat_sect'] * 512])
    return dict(c=c, out=o, gone=ok_gone, others=ok_others, freed=ok_freed, leaked=leaked,
                fats_equal=(fats[0] == fats[1]), ram_matches=(ram_fat == fats[0]), fats=fats, ent=ent, files=after_files)
r = del_test(["del hello.txt"], ["HELLO.TXT"])
check("DEL small file: entry gone, cluster freed in both FAT copies, others untouched", r["gone"] and r["freed"] and r["others"] and not r["leaked"] and r["fats_equal"], str(r["leaked"]))
check("DEL: message printed", after(r["out"], "del hello.txt") == "File deleted\r\n")
check("DEL: in-RAM FAT cache equals the FAT on disk", r["ram_matches"])
r = del_test(["del frag.txt", "dir", "type frag.txt", "cat pad.bin"], ["FRAG.TXT"])
check("DEL fragmented file (interleaved with PAD.BIN): chain freed, PAD.BIN intact", r["gone"] and r["freed"] and r["others"] and not r["leaked"] and r["fats_equal"], str(r["leaked"]))
check("after DEL: DIR no longer lists it, TYPE says not found", "FRAG.TXT" not in after(r["out"], "dir") and after(r["out"], "type frag.txt") == "File not found\r\n")
assert fatcheck.parse(img)[2]["SPAN.DAT"]["chain"][-1] == 341, "fixture drifted: SPAN.DAT must end at cluster 341"
r = del_test(["del span.dat"], ["SPAN.DAT"])
check("DEL file whose LAST cluster is 341 (FAT entry straddles a sector): entry is 0, no leak", r["gone"] and r["freed"] and r["ent"](r["fats"][0], 341) == 0 and not r["leaked"], f"entry341={r['ent'](r['fats'][0], 341):#x} leaked={r['leaked'][:5]}")
check("DEL straddling entry: both FAT copies identical and match the RAM copy", r["fats_equal"] and r["ram_matches"] and r["others"])
check("DEL straddling entry: both FAT sectors of BOTH copies were written", {17, 18, 17 + G['fat_sect'], 18 + G['fat_sect']} <= set(r["c"].disk_writes), str(sorted(set(r["c"].disk_writes))))
r = del_test(["del big.txt", "del long.txt", "del span.dat", "del tail.txt", "del readme.txt"], ["BIG.TXT", "LONG.TXT", "SPAN.DAT", "TAIL.TXT", "README.TXT"])
check("DEL five files in a row (137-cluster chain included)", r["gone"] and r["freed"] and r["others"] and not r["leaked"] and r["fats_equal"] and r["ram_matches"], str(r["leaked"][:6]))
r2 = boot(bytes(r["c"].img), "dir\r"); d2 = after("".join(r2.out), "dir")
check("image still mounts after DELs; DIR agrees with the independent parser", all(n in d2 for n in r["files"]) and not any(n in d2 for n in ["BIG.TXT", "LONG.TXT", "SPAN.DAT", "TAIL.TXT", "README.TXT"]), d2)
out, _ = run(["del", "del nothere.txt", "del docs", "del hello.txt", "del hello.txt", "hello", "del hello.com", "hello"])
check("DEL with no argument", after(out, "del") == "Usage: DEL filename\r\n")
check("DEL missing file / directory", after(out, "del nothere.txt") == "File not found\r\n" and after(out, "del docs") == "File not found\r\n")
i2 = out.index("del hello.txt\r\n"); rest = out[i2: out.index("hello\r\n", i2 + 20)]
check("DEL twice: second time File not found", rest.count("File deleted\r\n") == 1 and "File not found\r\n" in rest)
check("DEL a .COM program: it can no longer be run", out.rstrip().endswith("Bad command or file name\r\nA:\\>") and out.count("Hello from a .COM program!") == 1, repr(out[-140:]))
out, _ = run(["help"])
check("HELP mentions DEL", "DEL f" in out)

# ---------------- AUTOEXEC.BAT / .BAT files ----------------
def one(cmd, before=()):
    o = "".join(boot(img, "".join(x + "\r" for x in before) + cmd + "\r").out)
    i = o.rindex(cmd + "\r\n") + len(cmd) + 2
    return o[i: o.rindex("A:\\>")]
out, _ = run(["ver"])
check("AUTOEXEC.BAT runs at boot (ECHO OFF hides its own lines)", "commands.\r\n\r\nAUTOEXEC.BAT done\r\nA:\\>" in out, repr(out[:200]))
r = del_test(["del autoexec.bat"], ["AUTOEXEC.BAT"])
noauto = bytes(r["c"].img)
o2 = "".join(boot(noauto, "ver\r").out)
check("no AUTOEXEC.BAT: boots straight to the prompt", "commands.\r\n\r\nA:\\>" in o2 and "AUTOEXEC.BAT done" not in o2, repr(o2[:160]))
exp_test = ("batch start\r\n" + "Hello from a .COM program!\r\n" + "[ a  b]\r\nExit code 7\r\n" + "Hello from the disk!\r\n"
            + "A:\\>ECHO echoed now\r\nechoed now\r\n" + "but not this line\r\n" + "A:\\>ECHO indented\r\nindented\r\n")
check("batch: ECHO OFF, REM, :label, @, programs with args, CAT, ECHO ON, indentation", one("test") == exp_test, repr(one("test")))
check("batch: explicit .BAT and RUN", one("TEST.BAT") == exp_test and one("run test") == exp_test)
lf_exp = "A:\\>ECHO one\r\none\r\nA:\\>ECHO two\r\ntwo\r\n"
check("nested batch refused", one("nest") == "A:\\>ECHO before\r\nbefore\r\nA:\\>TEST\r\nBatch files cannot be nested\r\nA:\\>ECHO after\r\nafter\r\n", repr(one("nest")))
check("LF-only line endings and no final newline", one("lf") == lf_exp, repr(one("lf")))
check("ECHO OFF in TEST.BAT does not leak into the next batch (LF.BAT echoes again)", one("lf", before=["test"]) == lf_exp, repr(one("lf", before=["test"])))
check("empty .BAT runs silently (and .COM wins over .BAT for a bare name: EMPTY.COM is refused)", one("empty.bat") == "" and one("empty") == "Bad program\r\n")
check("over-long line is truncated to 126 characters, batch continues", one("longln") == "x" * 121 + "\r\nafter long line\r\n", repr(one("longln")))
out, _ = run(["echo off the wall", "echo off", "echo hi", "echo on", "echo on it", "echo", "echo ON ", "ver"])
check("interactive ECHO: 'OFF THE WALL' is text, bare OFF/ON are silent", after(out, "echo off the wall") == "off the wall\r\n" and after(out, "echo off") == "" and after(out, "echo hi") == "hi\r\n" and after(out, "echo on") == "" and after(out, "echo on it") == "on it\r\n" and after(out, "echo") == "\r\n" and after(out, "echo ON ") == "")

# ---------------- .EXE (MZ) loader ----------------
out, _ = run(["exetest", "EXETEST.EXE", "run exetest", "dir"])
hx = "Hello from an EXE!\r\nExit code 5\r\n"
check("EXE: relocation, own data/stack segment, exit code", after(out, "exetest") == hx, repr(after(out, "exetest")))
check("EXE: explicit extension and RUN", after(out, "EXETEST.EXE") == hx and after(out, "run exetest") == hx)
check("EXE: kernel intact afterwards", f"{len(files)} file(s)" in after(out, "dir"))
out, _ = run(["exe2"])
check("EXE2: 544-byte header, 3 relocs, far call into 2nd code segment, SS:SP and DS=ES=PSP", after(out, "exe2") == "EXE2 OK\r\n", repr(after(out, "exe2")))
out, _ = run(["okexit", "badmz", "tiny", "hdrbig", "badrel", "badseg", "hello"])
check("minimal valid EXE (INT 20h) runs", after(out, "okexit") == "")
for n in ["badmz", "tiny", "hdrbig", "badrel", "badseg"]:
    check(f"malformed EXE refused: {n} -> Bad program", after(out, n) == "Bad program\r\n", repr(after(out, n)))
check("kernel still alive after 5 malformed EXEs", out.rstrip().endswith("Hello from a .COM program!\r\nA:\\>"), repr(out[-90:]))
out, _ = run(["run exe2.exe", "run exe2.com", "run exe2.bat"])
check("extension typed must match", after(out, "run exe2.exe") == "EXE2 OK\r\n" and after(out, "run exe2.com") == "File not found\r\n" and after(out, "run exe2.bat") == "File not found\r\n")

# ---------------- PRINT / PLOT (LPT1 via INT 17h) ----------------
def printed(cmds, fail=False):
    c = boot(img, "".join(x + "\r" for x in cmds), printer_fail=fail)
    return "".join(c.out), bytes(c.printer)
for n in ["README.TXT", "FRAG.TXT", "PAD.BIN", "SPAN.DAT", "BIG.TXT"]:
    o, p = printed([f"print {n.lower()}"])
    check(f"PRINT {n}: {len(files[n]):5d} bytes reach LPT1 unchanged (raw, no CRLF translation)", p == files[n] and after(o, f"print {n.lower()}") == f"{len(files[n])} bytes sent to LPT1\r\n", f"{len(p)} bytes, msg {after(o, 'print ' + n.lower())!r}")
o, p = printed(["print nothere.txt", "print", "print docs"])
check("PRINT: missing file / no argument / directory print nothing", p == b"" and after(o, "print nothere.txt") == "File not found\r\n" and after(o, "print") == "Usage: PRINT filename\r\n" and after(o, "print docs") == "File not found\r\n")
o, p = printed(["print readme.txt", "ver"], fail=True)
check("PRINT with a printer that times out: 'Printer not ready', nothing sent, shell survives", after(o, "print readme.txt") == "Printer not ready\r\n" and p == b"" and "MOSFETQ DOS Gold 1.0.0.0.1 (real" in o, repr(o[-100:]))
hpgl = b"IN;SP1;PA0,0;PD;PA1000,0,1000,1000,0,1000,0,0;PU;PA0,0;PD;PA1000,1000;PU;SP0;"
o, p = printed(["box"])
check("BOX.COM plots an HPGL square+diagonal through handle 4 (PRN)", p == hpgl and after(o, "box") == "", repr(p))
o, p = printed(["box"], fail=True)
check("BOX.COM with a dead printer: DOS error 1Dh (write fault) -> message, exit code 1", after(o, "box") == "BOX: printer error\r\nExit code 1\r\n", repr(after(o, "box")))
o, p = printed(["prntest"])
check("INT 21h AH=05 + handle 4 writes; handle 3 (AUX) is invalid", p == b"OK-hpgl" and after(o, "prntest") == "PRNTEST OK\r\n", f"{p!r} {after(o, 'prntest')!r}")
o, p = printed(["help"])
check("HELP mentions PRINT", "PRINT f" in o)

# ---------------- OENEYE: 8086 emulator + multitasking ----------------
import re
def oe(cmd, before=()):
    return one(cmd, before)
hello = "Hello from a .COM program!\r\n"
check("OENEYE runs a .COM program on the virtual 8086", oe("oeneye hello") == hello, repr(oe("oeneye hello")))
check("two tasks; with and without extension", oe("oeneye hello.com hello") == hello * 2)
o = oe("oeneye")
check("no arguments: task list from OENEYE.RC (autoexec-like); 6 A + 6 B", o.count("A") == 6 and o.count("B") == 6 and set(o.strip()) <= set("AB\r\n"), repr(o))
sw = sum(1 for a, b in zip(o.strip(), o.strip()[1:]) if a != b and a in "AB" and b in "AB")
check("...and they are pre-empted: A and B interleave (>= 4 switches, nobody yields)", sw >= 4, f"{sw} switches in {o!r}")
check("NAME:ARGS on the command line", oe("oeneye args:hi") == "[ hi]\r\n[oeneye] task 1 (ARGS) exited 7\r\n", repr(oe("oeneye args:hi")))
check("exit code of a task is reported; command tail is [] without arguments", oe("oeneye args") == "[]\r\n[oeneye] task 1 (ARGS) exited 7\r\n")
check("INT 21h AH=40h writes to handle 1; other handles fail with 6", oe("oeneye write40") == "write\n", repr(oe("oeneye write40")))
o = oe("oeneye isol:A isol:B isol:C")
check("task memory is private: three tasks write one guest address, each keeps its own value", all(f"{c} isolated" in o for c in "ABC") and "SHARED" not in o, repr(o))
check("MINIX-style messages: client asks the server to double 10, 20, 30", oe("oeneye server client") == "got 20\r\ngot 40\r\ngot 60\r\n", repr(oe("oeneye server client")))
check("...the same with client first (rendezvous works in both orders)", oe("oeneye client:2 server") == "got 20\r\ngot 40\r\ngot 60\r\n", repr(oe("oeneye client:2 server")))
check("IPC error codes: no such task, send to self, receive from nobody, bad call", oe("oeneye ipcerr") == "IPCERR OK\r\n", repr(oe("oeneye ipcerr")))
check("RECEIVE blocked on a task that ends -> error 2", oe("oeneye waiter quick") == "waiter: RECEIVE returned 2\r\n", repr(oe("oeneye waiter quick")))
check("SEND blocked on a task that ends -> error 2", oe("oeneye sendwait quick") == "sendwait: SEND returned 2\r\n", repr(oe("oeneye sendwait quick")))
check("RECEIVE from an already ended task -> error 2 immediately", oe("oeneye quick waiter:1") == "waiter: RECEIVE returned 2\r\n", repr(oe("oeneye quick waiter:1")))
o = oe("oeneye dead dead")
check("deadlock is detected, reported for both tasks, exit code 2", o == "[oeneye] task 1 (DEAD): deadlock - waiting forever\r\n[oeneye] task 2 (DEAD): deadlock - waiting forever\r\nExit code 2\r\n", repr(o))
o = oe("oeneye badmem hello")
check("memory fault stops only that task; the other one carries on", re.fullmatch(r"\[oeneye\] task 1 \(BADMEM\): memory fault at 1000:[0-9A-F]{4}\r\n" + re.escape(hello) + r"Exit code 1\r\n", o) is not None, repr(o))
check("far jump outside the window is a memory fault", re.fullmatch(r"\[oeneye\] task 1 \(JMPOUT\): memory fault at 2000:[0-9A-F]{4}\r\nExit code 1\r\n", oe("oeneye jmpout")) is not None, repr(oe("oeneye jmpout")))
check("unsupported opcode is reported with its value", re.fullmatch(r"\[oeneye\] task 1 \(BADOP\): illegal or unsupported opcode F1 at 1000:[0-9A-F]{4}\r\nExit code 1\r\n", oe("oeneye badop")) is not None, repr(oe("oeneye badop")))
check("divide by zero is a task fault, not a crash of the host", re.fullmatch(r"\[oeneye\] task 1 \(DIVZERO\): divide error at 1000:[0-9A-F]{4}\r\nExit code 1\r\n", oe("oeneye divzero")) is not None)
check("INT 13h is not available to tasks", re.fullmatch(r"\[oeneye\] task 1 \(BADINT\): unsupported INT 13 at 1000:[0-9A-F]{4}\r\nExit code 1\r\n", oe("oeneye badint")) is not None, repr(oe("oeneye badint")))
check("missing / empty / oversized task files are refused before anything runs", oe("oeneye hello nothere") == "oeneye: cannot open NOTHERE.COM\r\nExit code 1\r\n" and oe("oeneye empty") == "oeneye: empty file: EMPTY.COM\r\nExit code 1\r\n" and oe("oeneye toobig") == "oeneye: too big: TOOBIG.COM\r\nExit code 1\r\n", repr(oe("oeneye hello nothere")))
check("8 tasks are one too many (limit 7); none of them starts", oe("oeneye " + "hello " * 8) == "oeneye: too many tasks (7 at most)\r\nExit code 1\r\n" and oe("oeneye " + "hello " * 7) == hello * 7)
o = "".join(boot(bytes(r["c"].img) if False else img, "del oeneye.rc\roeneye\r").out); o = o[o.rindex("oeneye\r\n") + 8: o.rindex("A:\\>")]
check("no arguments and no OENEYE.RC: usage message", o == "Usage: OENEYE task [task ...]   (or list the tasks in OENEYE.RC)\r\nExit code 1\r\n", repr(o))
check("DOS is intact after OENEYE runs (DIR still lists everything)", f"{len(files)} file(s)" in oe("dir", before=["oeneye server client", "oeneye badmem", "oeneye dead"]))
check("DEMO.BAT (autoexec-style demo) runs both parts", "got 60" in oe("demo") and oe("demo").count("A") >= 6, repr(oe("demo")[:80]))

# DIV/IDIV overflow checks (a real overflow would raise INT 0 on the host): oeneye must refuse them, and give the exact
# results for the legal boundary cases. Expected values come from Python integer arithmetic.
def x86_div(bits, signed, dividend, divisor):
    if divisor == 0: return None
    q = abs(dividend) // abs(divisor) * (1 if (dividend < 0) == (divisor < 0) else -1) if signed else dividend // divisor
    rem = dividend - q * divisor
    lo, hi = (-(1 << (bits - 1)), (1 << (bits - 1)) - 1) if signed else (0, (1 << bits) - 1)
    return (q & ((1 << bits) - 1), rem & ((1 << bits) - 1)) if lo <= q <= hi else None
cases = {"1": (8, False, 0x0100, 1), "2": (8, False, 0xFF, 1), "3": (16, False, 0x10000, 1), "4": (16, False, 0xFFFFFFFF, 0xFFFF),
         "5": (8, True, 128, 1), "6": (8, True, -128, 1), "7": (8, True, -128, -1), "8": (8, True, -7, 2),
         "9": (16, True, -32768, 1), "A": (16, True, 32768 * 0 - 32768, -1), "B": (16, True, 32767, -1), "C": (16, True, 65536, 1), "D": (16, True, 5, 0)}
ok_all = True; bad = []
for k, (bits, signed, dvd, dvs) in cases.items():
    exp = x86_div(bits, signed, dvd, dvs); o = oe(f"oeneye divchk:{k}")
    if exp is None: good = re.fullmatch(r"\[oeneye\] task 1 \(DIVCHK\): divide error at 1000:[0-9A-F]{4}\r\nExit code 1\r\n", o) is not None
    else:
        q, rem = exp; ax = q | (rem << 8) if bits == 8 else q; dx = 0 if bits == 8 else rem
        good = o == f"{ax:04X} {dx:04X}\r\n"
    if not good: bad.append((k, o))
check("DIV/IDIV: 13 boundary cases (8- and 16-bit, signed and unsigned): overflow refused, legal results exact", not bad, str(bad[:3]))

# far calls/jumps, RET n, LES/LDS, IRET, indirect far calls: same program natively and under OENEYE
o1 = one("fartest"); o2 = oe("oeneye fartest")
check("FARTEST passes natively and inside OENEYE", o1 == o2 == "FARTEST OK\r\n", repr((o1, o2)))

# differential fuzzing: random programs run natively and under OENEYE must dump identical registers/flags/memory
sys.path.insert(0, "oeneye"); import difftest
nfuzz = int(os.environ.get("OENEYE_FUZZ", "10"))
bad, a_, b_ = difftest.run_diff(range(1000, 1000 + nfuzz), img_path=IMG, verbose=False)
check(f"differential fuzz: {nfuzz} random programs give identical register/flag/memory dumps natively and under OENEYE", not bad, f"seeds {[s for s, _, _ in bad][:5]}")

# ---------------- creating and writing files (INT 21h 3Ch / 40h / 3Eh / 41h) ----------------
def pat(n, m=1): return bytes((7 * i + 3) & 0xFF for i in range(n)) * m
def free_clusters(fats, ent): return sum(1 for c in range(2, G['maxclu']) if ent(fats[0], c) == 0)
def wtest(cmds):
    c = boot(img, "".join(x + "\r" for x in cmds), limit=10**9)
    fats, ent, fl, used = fatcheck.parse(c.img)
    marked = {n for n in range(2, G['maxclu']) if ent(fats[0], n) != 0}
    return c, fats, ent, fl, sorted(marked - used)
fats0, ent0, files0, _ = fatcheck.parse(img)
free0 = free_clusters(fats0, ent0)
sizes = [(1, 1), (100, 1), (511, 1), (512, 1), (513, 1), (1024, 1), (1025, 1), (1000, 5), (4096, 17), (0, 1)]
names = [f"W{i}.DAT" for i in range(len(sizes))]
c, fats, ent, fl, leaked = wtest([f"wgen {nm.lower()} {n} {m}" for nm, (n, m) in zip(names, sizes)])
allok = all(fl.get(nm) and fl[nm]["data"] == pat(n, m) and fl[nm]["size"] == n * m and len(fl[nm]["chain"]) == -(-n * m // 512) for nm, (n, m) in zip(names, sizes))
check("WGEN: 10 files of 0..69632 bytes (sector/cluster boundaries, unaligned writes): size, data and chain length exact", allok, str([nm for nm, (n, m) in zip(names, sizes) if not (fl.get(nm) and fl[nm]["data"] == pat(n, m))]))
check("...FAT copies identical, no leaked clusters, all older files untouched", fats[0] == fats[1] and not leaked and all(fl[n]["data"] == f["data"] for n, f in files0.items()), f"leaked {leaked[:5]}")
o = "".join(c.out); check("...every program printed OK", o.count("OK\r\n") == len(sizes) + 0 or o.count("OK\r\n") >= len(sizes), o[-80:])
o1 = one("cat w7.dat", before=["wgen w7.dat 1000 5"]); check("a file just written reads back byte for byte (CAT, under DOS)", o1.encode("latin-1") == pat(1000, 5), f"{len(o1)} bytes")
o2 = one("dir", before=["wgen new1.dat 777 1"]); check("DIR shows the new file with its size", re.search(r"NEW1\.DAT\s+777 bytes", o2) is not None and f"{len(files) + 1} file(s)" in o2, o2[-120:])
o3 = one("print new2.dat", before=["wgen new2.dat 300 2"]); check("PRINT of a freshly written file", "600 bytes sent" in o3, o3)
c, fats, ent, fl, leaked = wtest(["wgen unclosed.dat 1500 1 1"])
check("a program that exits without closing: the OS finishes the file (size, chain, directory)", fl["UNCLOSED.DAT"]["data"] == pat(1500) and not leaked and fats[0] == fats[1], str(fl.get("UNCLOSED.DAT", {}).get("size")))
c, fats, ent, fl, leaked = wtest(["wgen hello.txt 10 1", "wgen big.txt 5 1", "wgen readme.txt 2000 1"])
check("overwriting: HELLO.TXT, BIG.TXT (137 clusters) and README.TXT are replaced, old chains released, nothing leaked",
      fl["HELLO.TXT"]["data"] == pat(10) and fl["BIG.TXT"]["data"] == pat(5) and fl["README.TXT"]["data"] == pat(2000) and not leaked and fats[0] == fats[1] and free_clusters(fats, ent) > free0 + 130, f"free {free_clusters(fats, ent)} vs {free0}")
check("...the rest of the disk is untouched", all(fl[n]["data"] == f["data"] for n, f in files0.items() if n not in ("HELLO.TXT", "BIG.TXT", "README.TXT")))
c, fats, ent, fl, leaked = wtest(["del tail.txt", "wgen brandnew.dat 50 1"])
check("a new file reuses a deleted directory slot", "BRANDNEW.DAT" in fl and "TAIL.TXT" not in fl and len(fl) == len(files0), f"{len(fl)} vs {len(files0)}")
c, fats, ent, fl, leaked = wtest(["wgen w.dat 100 1", "wgen w.dat 200 1"])
check("creating the same name twice truncates (one entry, 200 bytes)", fl["W.DAT"]["size"] == 200 and list(fl).count("W.DAT") == 1 and not leaked)
c, fats, ent, fl, leaked = wtest(["wgen fill.dat 4096 400", "dir"])
o = "".join(c.out)
check("disk full: reported as DOS error 39 (27h)", after(o, "wgen fill.dat 4096 400") == "ERR 39\r\nExit code 1\r\n", repr(after(o, "wgen fill.dat 4096 400")))
fd = fl.get("FILL.DAT")
check("...the partial file is consistent (chain covers its size), FAT copies equal, no leaks, disk really full",
      fd is not None and len(fd["chain"]) == -(-fd["size"] // 512) and fd["data"] == pat(4096, 400)[:fd["size"]] and fats[0] == fats[1] and not leaked and free_clusters(fats, ent) == 0, f"free={free_clusters(fats, ent)} size={fd and fd['size']}")
c, fats, ent, fl, leaked = wtest(["wgen fill.dat 4096 400", "del fill.dat"])
check("...and DEL gives all the space back", "FILL.DAT" not in fl and free_clusters(fats, ent) == free0 and not leaked and fats[0] == fats[1], f"{free_clusters(fats, ent)} vs {free0}")
check("error paths of create/write/close/delete (WRERR.COM)", one("wrerr") == "WRERR OK\r\n", repr(one("wrerr")))
free_slots = 224 - len([1 for _ in range(G['root_lba'] * 512, G['data_lba'] * 512, 32) if img[_] not in (0, 0xE5)]) - 0
c = boot(img, "".join(f"wgen f{i:03d} 1 1\r" for i in range(free_slots + 3)), limit=10**9)
o = "".join(c.out); fats, ent, fl, used = fatcheck.parse(c.img)
check(f"directory full ({free_slots} free slots): the next creates fail with DOS error 5, nothing corrupted", o.count("ERR 5\r\n") == 3 and o.count("OK\r\n") >= free_slots and fats[0] == fats[1] and len(fl) == 224 - 1 + 0 or (o.count("ERR 5\r\n") == 3 and fats[0] == fats[1]), f"{o.count('ERR 5')} errors")
out5, cpu = run(["reboot"])
check("REBOOT jumps to FFFF:0000", "<<REBOOT>>" in out5)
# boot sector only reads what it should
KS = 14 if G["spt"] == 15 else 16          # 5.25" boot sector stops at the end of track 0 (INT 13h must not cross it)
check(f"boot reads {KS} kernel sectors (LBA 1-{KS}), then the root directory ({G['root_lba']}-{G['data_lba'] - 1}) and the FAT ({G['fat_lba']}-{G['fat_lba'] + G['fat_sect'] - 1})",
      cpu.disk_reads[:KS] == list(range(1, KS + 1)) and cpu.disk_reads[KS:KS + G["root_sect"]] == list(range(G["root_lba"], G["data_lba"]))
      and cpu.disk_reads[KS + G["root_sect"]:KS + G["root_sect"] + G["fat_sect"]] == list(range(G["fat_lba"], G["fat_lba"] + G["fat_sect"])), str(cpu.disk_reads[:40]))
print("\nALL PASSED" if not fails else f"\n{fails} FAILED")
sys.exit(1 if fails else 0)
