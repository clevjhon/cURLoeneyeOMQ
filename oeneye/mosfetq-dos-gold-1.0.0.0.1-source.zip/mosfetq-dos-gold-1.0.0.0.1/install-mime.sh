#!/bin/sh
# Registers the MOSFETQ DOS image types for the current user (needs xdg-utils / shared-mime-info).
set -e
xdg-mime install --mode user "$(dirname "$0")/mosfetq-dos.xml"
update-mime-database "$HOME/.local/share/mime" 2>/dev/null || true
echo "installed; check with:  xdg-mime query filetype mosfetq-dos-gold-1.0.0.0.1-5.25in-1.2M.ximg"
