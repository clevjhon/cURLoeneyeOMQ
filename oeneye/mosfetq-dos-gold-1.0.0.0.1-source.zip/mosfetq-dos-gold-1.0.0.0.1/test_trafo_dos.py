"""TRAFO.COM (x87 assembly, run in the emulator under MOSFETQ DOS) against trafo/trafo.py."""
import sys, re, math, os
sys.path.insert(0, "."); sys.path.insert(0, "trafo")
import trafo, fatcheck
from emu import boot
IMG = os.environ.get("IMG", "mosfetq-dos.img")
img = open(IMG, "rb").read()
fails = 0
def check(name, cond, extra=""):
    global fails; print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  " + str(extra)[:400])); fails += (not cond)
ORDER = ["NP", "NS", "MUR", "LLK", "BSAT", "VIN", "FREQ", "RLOAD", "AE", "LE", "R1", "R2", "RC", "PHASE", "CYC", "SPC"]
def args_for(P):
    idx = max(ORDER.index(k) for k in P) if P else -1
    d = dict(trafo.DEFAULTS); d.update(P)
    return " ".join(str(d[k]) for k in ORDER[:idx + 1])
def run_cases(cases, flags=""):
    cmds = [(f"trafo {args_for(P)} {flags}").strip() for P in cases]
    c = boot(img, "".join(x + "\r" for x in cmds), limit=10**10)
    o = "".join(c.out); res, pos = [], 0
    for x in cmds:
        i = o.index(x + "\r\n", pos) + len(x) + 2; j = o.index("A:\\>", i); res.append(o[i:j]); pos = j
    return res, c
CASES = [("nominal 100 VA", {}), ("overdriven 300 V (just below the knee)", {"VIN": 300}), ("saturated 400 V", {"VIN": 400}),
         ("open circuit", {"RLOAD": 1000000}), ("heavy load", {"RLOAD": 100}), ("inrush: switched on at the voltage zero crossing", {"PHASE": 0}),
         ("tiny leakage, clamped step", {"LLK": 60, "R1": 200, "RLOAD": 100, "R2": 100}), ("400 Hz, 115 V, 250:60", {"FREQ": 400, "VIN": 115, "NP": 250, "NS": 60, "RLOAD": 3000, "AE": 600, "SPC": 400}),
         ("1:1 isolation 100 V", {"NP": 400, "NS": 400, "VIN": 100, "RLOAD": 20000, "LLK": 4000, "R1": 800, "R2": 800, "AE": 1500}),
         ("zero winding resistance (divide guards)", {"R1": 0, "R2": 0, "RLOAD": 2000}), ("2 cycles, 100 steps", {"CYC": 2, "SPC": 100}), ("designed 1080:117 turns, 24 V load", {"NP": 1080, "NS": 117, "AE": 800, "RLOAD": 5760})]
res, c = run_cases([P for _, P in CASES])
for (name, P), out in zip(CASES, res):
    line = out.split("\r\n")[0]; ref = trafo.report(trafo.simulate(P))
    check(f"TRAFO.COM = reference, character for character: {name}", line == ref, f"\n   asm: {line}\n   ref: {ref}")
o = res[0].split("\r\n")[1]; r0 = trafo.simulate({})
check(f"second line reports steps, time step and clamp ({o})", o == f"STEPS={r0['STEPS']} DT={r0['DT'] * 1e6:.2f}us CLAMP={'YES' if r0['CLAMP'] else 'NO'}", o)
check("unknown parameters are ignored and '?' prints the usage", "TRAFO [NP NS" in "".join(boot(img, "trafo ?\r", limit=10**9).out))

# ---- CSV and HPGL of the last cycle ----
P = {}; r = trafo.simulate(P, record=True); rec = r["samples"]; kdec = len(rec) // 200 + 1; picked = rec[::kdec][:200]
res, c = run_cases([P], flags="C H")
fats, ent, files, used = fatcheck.parse(c.img)
csv = files["TRAFO.CSV"]["data"].decode().split("\r\n")
exp = [f"{i},{round(s[1] * 10)},{round(s[2] * 1000)},{round(s[3] * 10)},{round(s[4] * 1000)}" for i, s in enumerate(picked)]
check(f"CSV: header + {len(picked)} decimated samples of the last cycle (1 in {kdec}), scaled to dV / mA, equal to the reference", csv[0] == "n,vs_dV,i1_mA,v2_dV,i2_mA" and csv[1:len(exp) + 1] == exp and csv[-1] == "", (csv[:3], exp[:2]))
check("CSV: file system consistent afterwards", fats[0] == fats[1])
plot = bytes(c.printer).decode()
pts = re.findall(r"P([UD])(\d+),(\d+);", plot); n = len(picked)
def yexp(vals):
    m = max(1, max(abs(v) for v in vals)); return [round(3000 + v * 2850 / m) for v in vals]
vs = [round(s[1] * 10) for s in picked]; v2 = [round(s[3] * 10) for s in picked]
got1 = [int(y) for _, _, y in pts[:n]]; got2 = [int(y) for _, _, y in pts[n:2 * n]]; xs = [int(x) for _, x, _ in pts[:n]]
check(f"HPGL to PRN: IN; SP1; ... SP2; ... PU;SP0; with {2 * n} points; both traces equal the reference samples", plot.startswith("IN;SP1;PU") and "SP2;PU" in plot and plot.endswith("PU;SP0;") and got1 == yexp(vs) and got2 == yexp(v2), (plot[:60], got1[:4], yexp(vs)[:4]))
check("HPGL: x runs 0..10000 evenly; first point is a pen-up move, the rest pen-down", xs[0] == 0 and xs[-1] == 10000 and pts[0][0] == "U" and all(p[0] == "D" for p in pts[1:n]))
print("\nALL PASSED" if not fails else f"\n{fails} FAILED"); sys.exit(1 if fails else 0)
