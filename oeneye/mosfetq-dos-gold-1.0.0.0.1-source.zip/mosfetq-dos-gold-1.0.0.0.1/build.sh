#!/bin/sh
# Needs GNU binutils (as, ld) and Python 3.
# Produces mosfetq-dos.img (3.5" 1.44 MB) and mosfetq-dos-1200.ximg (5.25" 1.2 MB): same OS, same files.
set -e
as --32 -o mosfetq-dos.o mosfetq-dos.s
ld -m elf_i386 -Ttext=0x7C00 --oformat binary -o mosfetq-dos.bin mosfetq-dos.o
as --32 --defsym G1200=1 -o mosfetq-dos-1200.o mosfetq-dos.s
ld -m elf_i386 -Ttext=0x7C00 --oformat binary -o mosfetq-dos-1200.bin mosfetq-dos-1200.o
# oeneye: the 8086 emulator / multitasker (flat binary at offset 0, wrapped into OENEYE.EXE by mkprogs.py)
python3 oeneye/mkoptab.py
cat oeneye/00_head.s oeneye/10_mem.s oeneye/20_ops.s oeneye/30_sys.s oeneye/80_optab.s oeneye/90_data.s > oeneye/oeneye.s
as --32 -o oeneye/oeneye.o oeneye/oeneye.s
ld -m elf_i386 -Ttext=0 --oformat binary -o oeneye/oeneye.bin oeneye/oeneye.o
# sample .COM programs (flat binaries loaded at offset 0x100)
for f in progs/*.s; do
    n=$(basename "$f" .s)
    as --32 -o "progs/$n.o" "$f"
    ld -m elf_i386 -Ttext=0x100 --oformat binary -o "progs/$(echo $n | tr a-z A-Z).COM" "progs/$n.o"
done
python3 mkprogs.py
python3 mkimage.py mosfetq-dos.bin mosfetq-dos.img
python3 mkimage.py mosfetq-dos-1200.bin mosfetq-dos-1200.ximg
