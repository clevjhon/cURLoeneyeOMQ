#!/usr/bin/env python3
"""Minimal 16-bit x86 interpreter + stub BIOS, just enough to boot mosfetq-dos.img."""
import sys, struct

class Done(Exception): pass
class Reboot(Exception): pass

M16 = 0xFFFF
class CPU:
    def __init__(self, img, keys):
        self.mem = bytearray(1 << 20)
        self.img = bytearray(img); self.keys = list(keys); self.out = []
        self.r = [0] * 8            # AX CX DX BX SP BP SI DI
        self.s = [0] * 4            # ES CS SS DS
        self.ip = 0x7C00
        self.f = dict(C=0, Z=0, S=0, O=0, P=0, D=0, I=1, T=0, A=0)
        self.mem[0x7C00:0x7E00] = img[:512]
        self.r[2] = 0x0000          # DL = boot drive 0
        self.r[4] = 0x7000
        self.steps = 0; self.ov = None
        self.fst = []; self.fsw = 0; self.fcw = 0x037F; self.disk_reads = []; self.disk_writes = []; self.dac = {}; self.printer = bytearray(); self.printer_fail = False
    # ---- registers ----
    def get8(self, n):
        v = self.r[n & 3]; return (v >> 8) & 0xFF if n & 4 else v & 0xFF
    def set8(self, n, v):
        i = n & 3; v &= 0xFF
        if n & 4: self.r[i] = (self.r[i] & 0x00FF) | (v << 8)
        else:     self.r[i] = (self.r[i] & 0xFF00) | v
    # ---- memory ----
    def lin(self, seg, off): return ((self.s[seg] << 4) + (off & M16)) & 0xFFFFF
    def rd8(self, seg, off): return self.mem[self.lin(seg, off)]
    def rd16(self, seg, off): return self.rd8(seg, off) | (self.rd8(seg, off + 1) << 8)
    def wr8(self, seg, off, v): self.mem[self.lin(seg, off)] = v & 0xFF
    def wr16(self, seg, off, v): self.wr8(seg, off, v); self.wr8(seg, off + 1, v >> 8)
    def dseg(self): return 3 if self.ov is None else self.ov
    def fetch8(self):
        v = self.mem[self.lin(1, self.ip)]; self.ip = (self.ip + 1) & M16; return v
    def fetch16(self): lo = self.fetch8(); return lo | (self.fetch8() << 8)
    def fetchs8(self): v = self.fetch8(); return v - 256 if v & 0x80 else v
    def push(self, v): self.r[4] = (self.r[4] - 2) & M16; self.wr16(2, self.r[4], v)
    def pop(self): v = self.rd16(2, self.r[4]); self.r[4] = (self.r[4] + 2) & M16; return v
    # ---- modrm ----
    def modrm(self):
        b = self.fetch8(); mod, reg, rm = b >> 6, (b >> 3) & 7, b & 7
        if mod == 3: return reg, ("r", rm)
        r = self.r
        base = [r[3]+r[6], r[3]+r[7], r[5]+r[6], r[5]+r[7], r[6], r[7], r[5], r[3]][rm]
        seg = 2 if rm in (2, 3) or (rm == 6 and mod) else 3
        if mod == 0 and rm == 6: base = self.fetch16(); seg = 3
        elif mod == 1: base += self.fetchs8()
        elif mod == 2: base += self.fetch16()
        if self.ov is not None: seg = self.ov
        return reg, ("m", seg, base & M16)
    def rdop(self, op, size):
        if op[0] == "r": return self.get8(op[1]) if size == 1 else self.r[op[1]]
        return self.rd8(op[1], op[2]) if size == 1 else self.rd16(op[1], op[2])
    def wrop(self, op, size, v):
        if op[0] == "r":
            if size == 1: self.set8(op[1], v)
            else: self.r[op[1]] = v & M16
        elif size == 1: self.wr8(op[1], op[2], v)
        else: self.wr16(op[1], op[2], v)
    def packf(self):
        f = self.f
        return 0x0002 | f['C'] | (f['P'] << 2) | (f['A'] << 4) | (f['Z'] << 6) | (f['S'] << 7) | (f['T'] << 8) | (f['I'] << 9) | (f['D'] << 10) | (f['O'] << 11)
    def unpackf(self, v):
        f = self.f
        f['C'] = v & 1; f['P'] = (v >> 2) & 1; f['A'] = (v >> 4) & 1; f['Z'] = (v >> 6) & 1; f['S'] = (v >> 7) & 1
        f['T'] = (v >> 8) & 1; f['I'] = (v >> 9) & 1; f['D'] = (v >> 10) & 1; f['O'] = (v >> 11) & 1
    def soft_int(self, n):
        self.push(self.packf()); self.push(self.s[1]); self.push(self.ip)
        off = self.mem[n * 4] | (self.mem[n * 4 + 1] << 8); seg = self.mem[n * 4 + 2] | (self.mem[n * 4 + 3] << 8)
        assert (seg, off) != (0, 0), f"INT {n:#x} not hooked"
        self.s[1] = seg; self.ip = off; self.f['T'] = 0; self.f['I'] = 0
    # ---- flags / ALU ----
    def szp(self, res, size):
        m = 0xFF if size == 1 else M16; sb = 0x80 if size == 1 else 0x8000
        res &= m; self.f['Z'] = int(res == 0); self.f['S'] = int(bool(res & sb))
        self.f['P'] = int(bin(res & 0xFF).count("1") % 2 == 0); return res
    def alu(self, op, a, b, size):
        m = 0xFF if size == 1 else M16; sb = 0x80 if size == 1 else 0x8000
        c = self.f['C']
        if op in (0, 2):   # add, adc
            t = a + b + (c if op == 2 else 0)
            self.f['C'] = int(t > m); self.f['O'] = int(bool(~(a ^ b) & (a ^ t) & sb)); self.f['A'] = int(bool((a ^ b ^ t) & 0x10)); return self.szp(t, size)
        if op in (3, 5, 7):  # sbb, sub, cmp
            t = a - b - (c if op == 3 else 0)
            self.f['C'] = int(t < 0); self.f['O'] = int(bool((a ^ b) & (a ^ t) & sb)); self.f['A'] = int(bool((a ^ b ^ t) & 0x10)); r = self.szp(t, size)
            return a if op == 7 else r
        t = {1: a | b, 4: a & b, 6: a ^ b}[op]
        self.f['C'] = 0; self.f['O'] = 0; self.f['A'] = 0; return self.szp(t, size)
    def cond(self, c):
        f = self.f
        t = [f['O'], f['C'], f['Z'], f['C'] | f['Z'], f['S'], f['P'], f['S'] ^ f['O'], (f['S'] ^ f['O']) | f['Z']][c >> 1]
        return bool(t) != bool(c & 1)
    def shift(self, kind, v, n, size):
        m = 0xFF if size == 1 else M16; bits = 8 * size; msb = 1 << (bits - 1); n &= 31; f = self.f
        if n == 0: return v
        if kind in (0, 1):                       # rol, ror
            k = n % bits
            if kind == 0: v = ((v << k) | (v >> (bits - k))) & m if k else v; f['C'] = v & 1; f['O'] = int(bool(v & msb)) ^ f['C']
            else:         v = ((v >> k) | (v << (bits - k))) & m if k else v; f['C'] = int(bool(v & msb)); f['O'] = f['C'] ^ int(bool(v & (msb >> 1)))
            return v
        if kind in (2, 3):                       # rcl, rcr: rotate through carry, one bit at a time
            for _ in range(n):
                if kind == 2: c = int(bool(v & msb)); v = ((v << 1) | f['C']) & m; f['C'] = c
                else:         c = v & 1; v = (v >> 1) | (msb if f['C'] else 0); f['C'] = c
            f['O'] = (int(bool(v & msb)) ^ f['C']) if kind == 2 else (int(bool(v & msb)) ^ int(bool(v & (msb >> 1))))
            return v
        if kind == 5:   # shr
            o = int(bool(v & msb)); f['C'] = (v >> (n - 1)) & 1; v >>= n; f['O'] = o
        elif kind in (4, 6): # shl / sal
            f['C'] = (v >> (bits - n)) & 1 if n <= bits else 0; v = (v << n) & m; f['O'] = int(bool(v & msb)) ^ f['C']
        else:           # sar
            sv = v - (m + 1) if v & msb else v
            f['C'] = (sv >> (n - 1)) & 1; v = (sv >> n) & m; f['O'] = 0
        return self.szp(v, size)

    # ---- x87 FPU (subset used by TRAFO.COM; Python floats stand in for 80-bit extended) ----
    def x87(self, op):
        import math
        reg, rm = self.modrm(); st = self.fst; mem = rm[0] == "m"
        def push(v):
            assert len(st) < 8, "x87 stack overflow"; st.append(v)
        def pop():
            assert st, "x87 stack underflow"; return st.pop()
        def rdn(n): return bytes(self.rd8(rm[1], rm[2] + i) for i in range(n))
        def wrn(b):
            for i, x in enumerate(b): self.wr8(rm[1], rm[2] + i, x)
        def arith(k, a, b):                                  # k = reg field of D8/DC: ADD MUL COM COMP SUB SUBR DIV DIVR
            if k == 0: return a + b
            if k == 1: return a * b
            if k == 4: return a - b
            if k == 5: return b - a
            if k == 6: return a / b
            return b / a
        def compare(a, b):
            self.fsw &= ~0x4500
            if a != a or b != b: self.fsw |= 0x4500
            elif a < b: self.fsw |= 0x0100
            elif a == b: self.fsw |= 0x4000
        def toint(v, n):
            r = round(v); lim = 1 << (8 * n - 1)
            assert -lim <= r < lim, "x87 integer overflow"; return r.to_bytes(n, "little", signed=True)
        i = rm[1] if not mem else 0
        if op in (0xD8, 0xDC):
            if mem:
                v = struct.unpack("<f" if op == 0xD8 else "<d", rdn(4 if op == 0xD8 else 8))[0]
                if reg in (2, 3): compare(st[-1], v); reg == 3 and pop()
                else: st[-1] = arith(reg, st[-1], v)
            elif op == 0xD8:
                b = st[-1 - i]
                if reg in (2, 3): compare(st[-1], b); reg == 3 and pop()
                else: st[-1] = arith(reg, st[-1], b)
            else:                                            # DC: ST(i) = ST(i) op ST(0); SUB/SUBR and DIV/DIVR are swapped in the encoding
                k = {4: 5, 5: 4, 6: 7, 7: 6}.get(reg, reg); st[-1 - i] = arith(k, st[-1 - i], st[-1])
        elif op == 0xDE:
            assert not mem, "x87 FIxxx m16 not implemented"
            if reg == 3 and i == 1: compare(st[-1], st[-2]); pop(); pop()
            else:
                k = {4: 5, 5: 4, 6: 7, 7: 6}.get(reg, reg); st[-1 - i] = arith(k, st[-1 - i], st[-1]); pop()
        elif op == 0xD9:
            if mem:
                if reg == 0: push(struct.unpack("<f", rdn(4))[0])
                elif reg in (2, 3): wrn(struct.pack("<f", st[-1])); reg == 3 and pop()
                elif reg == 5: rdn(2)
                elif reg == 7: wrn(struct.pack("<H", self.fcw))
                else: raise NotImplementedError(f"D9 /{reg} m")
            elif reg == 0: push(st[-1 - i])
            elif reg == 1: st[-1], st[-1 - i] = st[-1 - i], st[-1]
            elif reg == 2 and i == 0: pass
            elif reg == 4 and i == 0: st[-1] = -st[-1]
            elif reg == 4 and i == 1: st[-1] = abs(st[-1])
            elif reg == 5 and i == 0: push(1.0)
            elif reg == 5 and i == 3: push(math.pi)
            elif reg == 5 and i == 6: push(0.0)
            elif reg == 7 and i == 2: st[-1] = math.sqrt(st[-1])
            elif reg == 7 and i == 6: st[-1] = math.sin(st[-1])
            elif reg == 7 and i == 7: st[-1] = math.cos(st[-1])
            elif reg == 7 and i == 4: st[-1] = float(round(st[-1]))
            else: raise NotImplementedError(f"D9 {0xC0 | reg << 3 | i:02X}")
        elif op == 0xDB:
            if mem:
                if reg == 0: push(float(int.from_bytes(rdn(4), "little", signed=True)))
                elif reg in (2, 3): wrn(toint(st[-1], 4)); reg == 3 and pop()
                else: raise NotImplementedError(f"DB /{reg} m")
            elif reg == 4 and i == 3: st.clear(); self.fsw = 0
            elif reg == 4 and i == 2: self.fsw &= 0x7F00
            else: raise NotImplementedError(f"DB {0xC0 | reg << 3 | i:02X}")
        elif op == 0xDD:
            if mem:
                if reg == 0: push(struct.unpack("<d", rdn(8))[0])
                elif reg in (2, 3): wrn(struct.pack("<d", st[-1])); reg == 3 and pop()
                elif reg == 7: wrn(struct.pack("<H", self.fsw))
                else: raise NotImplementedError(f"DD /{reg} m")
            elif reg == 2: st[-1 - i] = st[-1]
            elif reg == 3: st[-1 - i] = st[-1]; pop()
            elif reg == 0: pass
            else: raise NotImplementedError(f"DD {0xC0 | reg << 3 | i:02X}")
        elif op == 0xDF:
            if mem:
                if reg == 0: push(float(int.from_bytes(rdn(2), "little", signed=True)))
                elif reg in (2, 3): wrn(toint(st[-1], 2)); reg == 3 and pop()
                elif reg == 5: push(float(int.from_bytes(rdn(8), "little", signed=True)))
                elif reg == 7: wrn(toint(st[-1], 8)); pop()
                else: raise NotImplementedError(f"DF /{reg} m")
            elif reg == 4 and i == 0: self.r[0] = (self.r[0] & 0x0000) | (self.fsw & 0xFFFF)
            else: raise NotImplementedError(f"DF {0xC0 | reg << 3 | i:02X}")
        else: raise NotImplementedError(f"x87 {op:#x}")
    # ---- BIOS ----
    def bios(self, n):
        r = self.r; ah = (r[0] >> 8) & 0xFF; al = r[0] & 0xFF
        if n == 0x10:
            if ah == 0x0E: self.out.append(chr(al))
            elif ah == 0x10 and al == 0x10: self.dac[r[3]] = ((r[2] >> 8) & 0xFF, (r[1] >> 8) & 0xFF, r[1] & 0xFF)          # BX=reg DH=R CH=G CL=B
            elif ah == 0x10 and al == 0x12:                                                                                   # BX=first CX=count ES:DX=table
                for i in range(r[1]): self.dac[r[3] + i] = tuple(self.mem[self.lin(0, r[2] + 3 * i + k)] for k in range(3))
            elif ah == 0x00: self.out.append("\f"); self.mode = al
            else: raise NotImplementedError(f"int 10h ah={ah:#x}")
        elif n == 0x13:
            if ah == 0: self.f['C'] = 0; r[0] &= 0x00FF; return
            assert ah in (2, 3), f"int 13h ah={ah:#x}"
            cyl = ((r[1] >> 8) & 0xFF) | (((r[1] & 0xC0)) << 2); sec = r[1] & 0x3F; head = (r[2] >> 8) & 0xFF
            assert (r[2] & 0xFF) == 0, "wrong drive"
            spt = 15 if len(self.img) == 1228800 else 18
            assert 1 <= sec <= spt and head < 2 and cyl < 80, f"bad CHS {cyl}/{head}/{sec}"
            lba = (cyl * 2 + head) * spt + sec - 1
            if ah == 3:
                for i in range(al):
                    a = self.lin(0, r[3] + i * 512)
                    self.img[(lba + i) * 512:(lba + i + 1) * 512] = self.mem[a:a + 512]
                    self.disk_writes.append(lba + i)
                self.f['C'] = 0; r[0] = al; return
            for i in range(al):
                d = self.img[(lba + i) * 512:(lba + i + 1) * 512]
                self.mem[self.lin(0, r[3] + i * 512): self.lin(0, r[3] + i * 512) + 512] = d
                self.disk_reads.append(lba + i)
            self.f['C'] = 0; r[0] = al
        elif n == 0x16:
            if ah == 1:
                self.f['Z'] = int(not self.keys)
                if self.keys: r[0] = self.keys[0] if isinstance(self.keys[0], int) else ord(self.keys[0])   # ints = raw AX (e.g. 0x4800 = up arrow)
                return
            if not self.keys: raise Done()
            k = self.keys.pop(0); r[0] = k if isinstance(k, int) else ord(k)
        elif n == 0x17:                       # BIOS printer services (LPT1)
            if self.printer_fail: r[0] = (r[0] & 0x00FF) | 0x0100; return        # AH=01: time-out
            if ah == 0: self.printer.append(al)
            elif ah not in (1, 2): raise NotImplementedError(f"int 17h ah={ah:#x}")
            r[0] = (r[0] & 0x00FF) | 0x9000                                    # AH=90h: selected, not busy
        elif n == 0x12: r[0] = 639
        elif n == 0x1A:
            if ah == 2: r[1] = 0x1234; r[2] = 0x5600      # 12:34:56
            elif ah == 4: r[1] = 0x2026; r[2] = 0x0919     # 2026-09-19
            self.f['C'] = 0
        else: raise NotImplementedError(f"int {n:#x}")
    # ---- run ----
    def run(self, limit=20_000_000):
        r = self.r
        while self.steps < limit:
            self.steps += 1
            ip0 = self.ip
            t0 = self.f['T']
            op = self.fetch8(); rep = None; self.ov = None
            while op in (0x26, 0x2E, 0x36, 0x3E, 0xF0, 0xF2, 0xF3):
                if op in (0xF2, 0xF3): rep = op
                elif op != 0xF0: self.ov = (op >> 3) & 3
                op = self.fetch8()
            if op < 0x40 and (op & 7) < 6:
                k = op >> 3; t = op & 7
                if t in (0, 1, 2, 3):
                    size = 1 if t % 2 == 0 else 2; reg, rm = self.modrm()
                    if t < 2: res = self.alu(k, self.rdop(rm, size), self.rdop(("r", reg), size), size); (k != 7) and self.wrop(rm, size, res)
                    else:     res = self.alu(k, self.rdop(("r", reg), size), self.rdop(rm, size), size); (k != 7) and self.wrop(("r", reg), size, res)
                elif t == 4: res = self.alu(k, r[0] & 0xFF, self.fetch8(), 1); (k != 7) and self.set8(0, res)
                else:        res = self.alu(k, r[0], self.fetch16(), 2); (k != 7) and r.__setitem__(0, res)
            elif 0x40 <= op < 0x50:
                i = op & 7; c = self.f['C']
                r[i] = self.alu(0 if op < 0x48 else 5, r[i], 1, 2); self.f['C'] = c
            elif 0x50 <= op < 0x58: self.push(r[op & 7])
            elif 0x58 <= op < 0x60: r[op & 7] = self.pop()
            elif 0x70 <= op < 0x80:
                d = self.fetchs8()
                if self.cond(op & 15): self.ip = (self.ip + d) & M16
            elif op == 0x0F:
                op2 = self.fetch8(); assert 0x80 <= op2 < 0x90, f"0F {op2:#x} @ {ip0:#x}"
                d = self.fetch16(); d = d - 65536 if d & 0x8000 else d
                if self.cond(op2 & 15): self.ip = (self.ip + d) & M16
            elif op in (0x80, 0x81, 0x83):
                size = 1 if op == 0x80 else 2; reg, rm = self.modrm()
                imm = self.fetch8() if op != 0x81 else self.fetch16()
                if op == 0x83 and imm & 0x80: imm |= 0xFF00
                res = self.alu(reg, self.rdop(rm, size), imm & (0xFF if size == 1 else M16), size)
                if reg != 7: self.wrop(rm, size, res)
            elif op in (0x84, 0x85):
                size = 1 if op == 0x84 else 2; reg, rm = self.modrm()
                self.alu(4, self.rdop(rm, size), self.rdop(("r", reg), size), size)
            elif op in (0x86, 0x87):
                size = 1 if op == 0x86 else 2; reg, rm = self.modrm()
                a = self.rdop(rm, size); b = self.rdop(("r", reg), size); self.wrop(rm, size, b); self.wrop(("r", reg), size, a)
            elif op in (0x88, 0x89):
                size = 1 if op == 0x88 else 2; reg, rm = self.modrm(); self.wrop(rm, size, self.rdop(("r", reg), size))
            elif op in (0x8A, 0x8B):
                size = 1 if op == 0x8A else 2; reg, rm = self.modrm(); self.wrop(("r", reg), size, self.rdop(rm, size))
            elif op == 0x8C: reg, rm = self.modrm(); self.wrop(rm, 2, self.s[reg])
            elif op == 0x8E: reg, rm = self.modrm(); self.s[reg] = self.rdop(rm, 2)
            elif op == 0x8D: reg, rm = self.modrm(); assert rm[0] == "m"; r[reg] = rm[2]
            elif op == 0x90: pass
            elif 0x91 <= op <= 0x97: i = op & 7; r[0], r[i] = r[i], r[0]
            elif op == 0xA0: self.set8(0, self.rd8(self.dseg(), self.fetch16()))
            elif op == 0xA1: r[0] = self.rd16(self.dseg(), self.fetch16())
            elif op == 0xA2: self.wr8(self.dseg(), self.fetch16(), r[0])
            elif op == 0xA3: self.wr16(self.dseg(), self.fetch16(), r[0])
            elif op in (0xA8, 0xA9):
                if op == 0xA8: self.alu(4, r[0] & 0xFF, self.fetch8(), 1)
                else: self.alu(4, r[0], self.fetch16(), 2)
            elif op in (0xA4, 0xA5, 0xA6, 0xA7, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF):
                size = 1 if op in (0xA4, 0xA6, 0xAA, 0xAC, 0xAE) else 2; d = -size if self.f['D'] else size
                rd = self.rd8 if size == 1 else self.rd16; wr = self.wr8 if size == 1 else self.wr16
                acc = (lambda: r[0] & 0xFF) if size == 1 else (lambda: r[0])
                cond = op in (0xA6, 0xA7, 0xAE, 0xAF)
                while True:
                    if rep and r[1] == 0: break
                    if op in (0xA4, 0xA5): wr(0, r[7], rd(self.dseg(), r[6])); r[6] = (r[6] + d) & M16; r[7] = (r[7] + d) & M16
                    elif op in (0xAA, 0xAB): wr(0, r[7], acc()); r[7] = (r[7] + d) & M16
                    elif op in (0xAC, 0xAD):
                        v = rd(self.dseg(), r[6]); r[6] = (r[6] + d) & M16
                        if size == 1: self.set8(0, v)
                        else: r[0] = v
                    elif op in (0xA6, 0xA7): self.alu(7, rd(self.dseg(), r[6]), rd(0, r[7]), size); r[6] = (r[6] + d) & M16; r[7] = (r[7] + d) & M16
                    else: self.alu(7, acc(), rd(0, r[7]), size); r[7] = (r[7] + d) & M16
                    if not rep: break
                    r[1] = (r[1] - 1) & M16
                    if r[1] == 0: break
                    if cond and (self.f['Z'] != (1 if rep == 0xF3 else 0)): break
            elif 0xB0 <= op < 0xB8: self.set8(op & 7, self.fetch8())
            elif 0xB8 <= op < 0xC0: r[op & 7] = self.fetch16()
            elif op in (0xC0, 0xC1, 0xD0, 0xD1, 0xD2, 0xD3):
                size = 1 if op in (0xC0, 0xD0, 0xD2) else 2; reg, rm = self.modrm()
                n = self.fetch8() if op in (0xC0, 0xC1) else (1 if op in (0xD0, 0xD1) else r[1] & 0xFF)
                self.wrop(rm, size, self.shift(reg, self.rdop(rm, size), n, size))
            elif op == 0xC3: self.ip = self.pop()
            elif op in (0xC6, 0xC7):
                size = 1 if op == 0xC6 else 2; reg, rm = self.modrm()
                self.wrop(rm, size, self.fetch8() if size == 1 else self.fetch16())
            elif op == 0xCD:
                n = self.fetch8()
                if n in (0x10, 0x12, 0x13, 0x16, 0x17, 0x1A): self.bios(n)
                else: self.soft_int(n)
            elif op == 0xCF: self.ip = self.pop(); self.s[1] = self.pop(); self.unpackf(self.pop())
            elif op == 0x9C: self.push(self.packf())
            elif op == 0x9D: self.unpackf(self.pop())
            elif op in (0x06, 0x0E, 0x16, 0x1E): self.push(self.s[op >> 3])
            elif op in (0x07, 0x17, 0x1F): self.s[op >> 3] = self.pop()
            elif op == 0xE2:
                d = self.fetchs8(); r[1] = (r[1] - 1) & M16
                if r[1]: self.ip = (self.ip + d) & M16
            elif op == 0xE8: d = self.fetch16(); self.push(self.ip); self.ip = (self.ip + d) & M16
            elif op == 0xE9: d = self.fetch16(); self.ip = (self.ip + d) & M16
            elif op == 0x9A:
                off = self.fetch16(); seg = self.fetch16(); self.push(self.s[1]); self.push(self.ip); self.s[1] = seg; self.ip = off
            elif op == 0xCB: self.ip = self.pop(); self.s[1] = self.pop()
            elif op == 0xEA:
                off = self.fetch16(); seg = self.fetch16()
                if seg == 0xFFFF and off == 0: raise Reboot()
                self.s[1] = seg; self.ip = off
            elif op == 0xEB: d = self.fetchs8(); self.ip = (self.ip + d) & M16
            elif op == 0xF4: raise Done()
            elif op == 0xF8: self.f['C'] = 0
            elif op == 0xF9: self.f['C'] = 1
            elif op in (0xFA, 0xFB): self.f['I'] = int(op == 0xFB)
            elif op == 0xFC: self.f['D'] = 0
            elif op == 0xFD: self.f['D'] = 1
            elif op in (0xF6, 0xF7):
                size = 1 if op == 0xF6 else 2; reg, rm = self.modrm(); m = 0xFF if size == 1 else M16; bits = 8 * size
                sgn = lambda x: x - (m + 1) if x & (1 << (bits - 1)) else x
                if reg in (0, 1): self.alu(4, self.rdop(rm, size), self.fetch8() if size == 1 else self.fetch16(), size)
                elif reg == 2: self.wrop(rm, size, ~self.rdop(rm, size) & m)
                elif reg == 3:
                    v = self.rdop(rm, size); res = self.alu(5, 0, v, size); self.f['C'] = int(v != 0); self.wrop(rm, size, res)
                elif reg in (4, 5):
                    s = self.rdop(rm, size)
                    a_ = (r[0] & 0xFF) if size == 1 else r[0]
                    p = a_ * s if reg == 4 else sgn(a_) * sgn(s)
                    if size == 1: r[0] = p & M16
                    else: r[0] = p & M16; r[2] = (p >> 16) & M16
                    hi = (p >> bits) & m
                    ov = (hi != 0) if reg == 4 else (p != sgn(p & m))
                    self.f['C'] = self.f['O'] = int(ov)
                elif reg == 6:
                    d = self.rdop(rm, size); assert d, "divide by zero"
                    if size == 1:
                        n = r[0]; q, rem = divmod(n, d); assert q < 256, "divide overflow"; r[0] = (rem << 8) | q
                    else:
                        n = (r[2] << 16) | r[0]; q, rem = divmod(n, d); assert q <= M16, "divide overflow"; r[0], r[2] = q, rem
                else:
                    d = sgn(self.rdop(rm, size)); assert d, "divide by zero"
                    n = (r[0] - 0x10000 if r[0] & 0x8000 else r[0]) if size == 1 else ((r[2] << 16) | r[0]) - (1 << 32 if r[2] & 0x8000 else 0)
                    q = abs(n) // abs(d) * (1 if (n < 0) == (d < 0) else -1); rem = n - q * d
                    lim = 1 << (bits - 1); assert -lim <= q < lim, "divide overflow"
                    if size == 1: r[0] = ((rem & 0xFF) << 8) | (q & 0xFF)
                    else: r[0] = q & M16; r[2] = rem & M16
            elif op in (0xFE, 0xFF):
                size = 1 if op == 0xFE else 2; reg, rm = self.modrm()
                if reg in (0, 1):
                    c = self.f['C']; v = self.alu(0 if reg == 0 else 5, self.rdop(rm, size), 1, size); self.f['C'] = c; self.wrop(rm, size, v)
                elif reg == 2: t = self.rdop(rm, 2); self.push(self.ip); self.ip = t
                elif reg == 4: self.ip = self.rdop(rm, 2)
                elif reg in (3, 5):
                    assert rm[0] == "m"
                    off = self.rd16(rm[1], rm[2]); seg = self.rd16(rm[1], rm[2] + 2)
                    if reg == 3: self.push(self.s[1]); self.push(self.ip)
                    self.s[1] = seg; self.ip = off
                elif reg == 6: self.push(self.rdop(rm, 2))
                else: raise NotImplementedError(f"FF /{reg}")
            elif op == 0x98: r[0] = ((r[0] & 0xFF) | (0xFF00 if r[0] & 0x80 else 0)) & M16
            elif op == 0x99: r[2] = 0xFFFF if r[0] & 0x8000 else 0
            elif op == 0x9E:
                ah = (r[0] >> 8) & 0xFF; f = self.f
                f['C'] = ah & 1; f['P'] = (ah >> 2) & 1; f['A'] = (ah >> 4) & 1; f['Z'] = (ah >> 6) & 1; f['S'] = (ah >> 7) & 1
            elif op == 0x9F: r[0] = (r[0] & 0xFF) | ((self.packf() & 0xD7) << 8)
            elif op == 0x9B: pass
            elif 0xD8 <= op <= 0xDF: self.x87(op)
            elif op == 0xF5: self.f['C'] ^= 1
            elif op == 0xD7: self.set8(0, self.rd8(self.dseg(), r[3] + (r[0] & 0xFF)))
            elif op == 0xE0 or op == 0xE1:
                d = self.fetchs8(); r[1] = (r[1] - 1) & M16
                if r[1] and self.f['Z'] == (1 if op == 0xE1 else 0): self.ip = (self.ip + d) & M16
            elif op == 0xE3:
                d = self.fetchs8()
                if r[1] == 0: self.ip = (self.ip + d) & M16
            elif op == 0xC2: n = self.fetch16(); self.ip = self.pop(); r[4] = (r[4] + n) & M16
            elif op == 0xCA: n = self.fetch16(); self.ip = self.pop(); self.s[1] = self.pop(); r[4] = (r[4] + n) & M16
            elif op in (0xC4, 0xC5):
                reg, rm = self.modrm(); assert rm[0] == "m"
                r[reg] = self.rd16(rm[1], rm[2]); self.s[0 if op == 0xC4 else 3] = self.rd16(rm[1], rm[2] + 2)
            elif op == 0x8F: reg, rm = self.modrm(); self.wrop(rm, 2, self.pop())
            else:
                raise NotImplementedError(f"opcode {op:#04x} at {self.s[1]:04x}:{ip0:04x}")
            if t0 and self.f['T']: self.soft_int(1)          # single-step trap after the instruction
        raise RuntimeError("step limit")

def boot(img, keys, printer_fail=False, limit=20_000_000):
    cpu = CPU(img, keys); cpu.printer_fail = printer_fail
    try: cpu.run(limit)
    except Done: pass
    except Reboot: cpu.out.append("<<REBOOT>>")
    return cpu

if __name__ == "__main__":
    img = open("mosfetq-dos.img", "rb").read()
    keys = sys.argv[1].encode().decode("unicode_escape") if len(sys.argv) > 1 else ""
    c = boot(img, keys)
    print("".join(c.out).replace("\r", ""))
