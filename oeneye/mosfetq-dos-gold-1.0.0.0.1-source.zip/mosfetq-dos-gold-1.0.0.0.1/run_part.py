"""Run one section of test_dos.py. Usage: run_part.py N   (sections 1-8, see SECTIONS; 0 = list)
All function definitions, imports and cheap set-up of the other sections are still executed, so the section can use them;
only its own checks (and the boots they need) are run."""
import ast, sys, time, os
SRC = open("test_dos.py").read(); TREE = ast.parse(SRC); LINES = SRC.split("\n")
# section starts (first line of each "# ----" header) and names
heads = [(i + 1, l) for i, l in enumerate(LINES) if l.startswith("# ----------------")]
SECTIONS = [(9, "prelude: boot banner, DIR, TYPE, echo, MEM, backspace"), (1, ".COM loader / INT 21h"), (2, "INT 21h file services"), (3, "DEL / write path"), (4, "AUTOEXEC / BAT"), (5, ".EXE loader"), (6, "PRINT / PLOT"), (7, "OENEYE"), (8, "creating and writing files")]
starts = [h[0] for h in heads]
def section_of(line):
    k = 0                                                # 0 = the prelude (before the first header): always executed
    for j, s in enumerate(starts):
        if line >= s: k = j + 1
    return k
BOOTERS = {"boot", "run", "one", "oe", "cat", "printed", "wtest", "del_test", "run_diff", "paint"}
def has_booter(node):
    for n in ast.walk(node):
        if isinstance(n, ast.Call):
            f = n.func; name = f.id if isinstance(f, ast.Name) else getattr(f, "attr", "")
            if name in BOOTERS: return True
    return False
def main():
    want = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    if want == 0:
        for k, n in SECTIONS: print(k, n)
        return
    g = {"__name__": "__main__"}; t0 = time.time()
    # the section headers of test_dos.py are numbered 1.. in file order; the first "def"-only spans belong to their header
    for node in TREE.body:
        k = section_of(node.lineno)
        run = k == want or (k == 0 and want == 9)
        selected = run
        if not run:
            if isinstance(node, (ast.FunctionDef, ast.Import, ast.ImportFrom, ast.ClassDef)): run = True
            elif isinstance(node, ast.Assign) and not has_booter(node): run = True
            elif k == 0 and isinstance(node, ast.For) and not has_booter(node): run = True
        if run:
            code = compile(ast.Module([node], []), "test_dos.py", "exec")
            if selected: exec(code, g)
            else:
                try: exec(code, g)                       # set-up of another section: harmless if it depends on skipped output
                except Exception: pass
    print(f"[section {want} took {time.time() - t0:.0f}s]")
    n_fail = g.get("fails", 0); sys.exit(1 if n_fail else 0)
main()
