"""Gold 1.0.0.0.1 checks: both disk formats (3.5" 1.44 MB .img, 5.25" 1.2 MB .ximg) and the paint program."""
import os, re, sys, struct
sys.path.insert(0, "."); sys.path.insert(0, "oeneye")
import fatcheck, imgtool, geom, difftest
from emu import boot
fails = 0
def check(name, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  " + str(extra)[:300])); fails += (not cond)
def run(img, keys, **kw): return boot(img, keys, limit=10**9, **kw)
def out_after(c, cmd):
    o = "".join(c.out); i = o.rindex(cmd + "\r\n") + len(cmd) + 2; return o[i: o.rindex("A:\\>")]
UP, DOWN, LEFT, RIGHT = 0x4800, 0x5000, 0x4B00, 0x4D00

IMAGES = {"3.5in 1.44M .img": "mosfetq-dos.img", "5.25in 1.2M .ximg": "mosfetq-dos-1200.ximg"}
for label, path in ([] if os.environ.get('PAINT_ONLY') else IMAGES.items()):
    img = open(path, "rb").read(); G = geom.geom(img); files = fatcheck.parse(img)[2]
    check(f"[{label}] size and BPB: {G['total']} sectors, {G['spt']} per track, media F{G['media'] & 15:X}", len(img) == G["total"] * 512 and (G["total"], G["spt"], G["media"]) in ((2880, 18, 0xF0), (2400, 15, 0xF9)))
    check(f"[{label}] boot sector: 55AA signature, 'MOSFETQ ' OEM name, label", img[510:512] == b"\x55\xaa" and img[3:11] == b"MOSFETQ " and img[0x2B:0x36] == b"MOSFETQ    " and img[0x36:0x3E] == b"FAT12   ")
    c = run(img, "ver\rdir\rtype frag.txt\rhello\rexe2\rtest\rdemo\rwrerr\r")
    o = "".join(c.out)
    check(f"[{label}] banner and VER say Gold 1.0.0.0.1", "MOSFETQ DOS Gold 1.0.0.0.1\r\n" in o and "Gold 1.0.0.0.1 (real mode" in out_after(c, "ver"))
    nfiles = sum(1 for f in files.values() if not f["attr"] & 0x10); ndirs = len(files) - nfiles
    check(f"[{label}] DIR lists every file ({nfiles} files, {ndirs} dir)", f"{nfiles} file(s)" in out_after(c, "dir") and f"{ndirs} dir(s)" in out_after(c, "dir") and all(n in out_after(c, "dir") for n in list(files)[:20]))
    check(f"[{label}] TYPE of a fragmented multi-cluster file", out_after(c, "type frag.txt").replace("\r\n", "\n") == files["FRAG.TXT"]["data"].decode().replace("\r\n", "\n") + "\n" or "FRAG 050" in out_after(c, "type frag.txt"))
    check(f"[{label}] .COM, .EXE, .BAT and INT 21h file create/write/delete work", "Hello from a .COM program!" in o and "EXE2 OK" in o and "batch start" in o and "WRERR OK" in o)
    c = run(img, "oeneye server client\roeneye fartest\rdel span.dat\rwgen q.dat 5000 3\rcat q.dat\rdel q.dat\rprint readme.txt\r", printer_fail=False)
    fats, ent, fl, used = fatcheck.parse(c.img); marked = {n for n in range(2, G["maxclu"]) if ent(fats[0], n)}
    check(f"[{label}] OENEYE, DEL of a file ending on the sector-straddling cluster 341, create/write/read/delete, PRINT",
          "got 60" in "".join(c.out) and "FARTEST OK" in "".join(c.out) and "SPAN.DAT" not in fl and "Q.DAT" not in fl and fats[0] == fats[1] and marked == used and bytes(c.printer) == files["README.TXT"]["data"],
          f"copies equal {fats[0] == fats[1]}, leaked {sorted(marked - used)[:5]}")
    check(f"[{label}] the DEL flushed both FAT sectors of both copies", {17, 18, 17 + G["fat_sect"], 18 + G["fat_sect"]} <= set(c.disk_writes))
    bad, _, _ = difftest.run_diff(range(2000, 2005), img_path=path, verbose=False)
    check(f"[{label}] 5 fuzz programs: identical natively and inside OENEYE", not bad, [s for s, _, _ in bad])

# ---------------- PAINT ----------------
img = open("mosfetq-dos.img", "rb").read()
def bmp_of(pix):                       # canonical 64x64 8-bit BMP for pix[y][x]
    pal = b"".join(bytes(t) + b"\0" for t in [(0,0,0),(0xAA,0,0),(0,0xAA,0),(0xAA,0xAA,0),(0,0,0xAA),(0xAA,0,0xAA),(0,0x55,0xAA),(0xAA,0xAA,0xAA),
                                             (0x55,0x55,0x55),(0xFF,0x55,0x55),(0x55,0xFF,0x55),(0xFF,0xFF,0x55),(0x55,0x55,0xFF),(0xFF,0x55,0xFF),(0x55,0xFF,0xFF),(0xFF,0xFF,0xFF)]) + bytes(960)
    hdr = b"BM" + struct.pack("<IIIIiiHHIIiiII", 5174, 0, 1078, 40, 64, 64, 1, 8, 0, 4096, 2835, 2835, 256, 256)
    return hdr + pal + b"".join(bytes(pix[y]) for y in range(63, -1, -1))
def screen(c): return lambda cx, cy: c.mem[0xA0000 + (4 + cy * 3 + 1) * 320 + 6 + cx * 3 + 1]
def canvas_from_screen(c): s = screen(c); return [[s(x, y) for x in range(64)] for y in range(64)]
def paint(keys, image=img, cmd="paint"):
    c = run(image, list(cmd + "\r") + keys); return c, fatcheck.parse(c.img)[2]

c, fl = paint(["4", " ", RIGHT, RIGHT, "2", " ", DOWN, DOWN, "p", DOWN, DOWN, RIGHT, "p", "9", RIGHT, RIGHT, " ", "s", "q"])
s = screen(c); d = fl["SKIN.BMP"]["data"]
check("PAINT: colour keys, SPACE, arrows and the pen paint the right cells on screen", (s(0, 0), s(2, 0), s(2, 2), s(2, 3), s(2, 4), s(3, 4)) == (4, 2, 2, 2, 2, 2) and s(1, 0) == 0 and s(5, 4) == 9 ^ 15, [s(0, 0), s(2, 0), s(2, 4), s(3, 4), s(5, 4)])
expect = [[0] * 64 for _ in range(64)]
for (x, y, col) in [(0, 0, 4), (2, 0, 2), (2, 2, 2), (2, 3, 2), (2, 4, 2), (3, 4, 2), (5, 4, 9)]: expect[y][x] = col
check("PAINT: S saves a standard BMP - byte-exact canonical file (header, VGA palette, bottom-up rows)", d == bmp_of(expect), f"{len(d)} bytes")
check("PAINT: the file is a valid 64x64 8-bit BMP (image/bmp) and the status bar flashes green; Q returns to text mode", d[:2] == b"BM" and struct.unpack_from("<iiHH", d, 18) == (64, 64, 1, 8) and c.mem[0xA0000 + 190 * 320 + 220] == 2 and c.mode == 3)
fats, ent, allf, used = fatcheck.parse(c.img); marked = {n for n in range(2, 2833) if ent(fats[0], n)}
check("PAINT: the saved file leaves the FAT consistent", fats[0] == fats[1] and marked == used)
c, fl = paint([LEFT, UP, " ", "q"])
s = screen(c)
check("PAINT: the cursor cannot leave the canvas (LEFT/UP at the corner)", s(0, 0) == 15 ^ 15 or s(0, 0) in (0, 15) and sum(1 for x in range(64) for y in range(64) if s(x, y) not in (0, 15)) == 0)
c, fl = paint(["a", " ", RIGHT, "F", " ", RIGHT, "]", " ", RIGHT, "[", "[", " ", RIGHT, "0", " ", "s", "q"])
d = fl["SKIN.BMP"]["data"]; px = lambda x: d[1078 + 63 * 64 + x]
check("PAINT: hex colours A-F (any case), [ and ] cycle through the 16 colours with wrap-around", (px(0), px(1), px(2), px(3), px(4)) == (10, 15, 0, 14, 0), [px(i) for i in range(5)])
c, fl = paint(["1", " ", DOWN, "p", RIGHT, RIGHT, "p", "x", "s", "q"])
d = fl["SKIN.BMP"]["data"]
check("PAINT: X clears the canvas", d[1078:] == bytes(4096), sum(1 for b in d[1078:] if b))
s = screen(c); good = True
c, fl = paint(["3", "q"])
sw = lambda i: (c.mem[0xA0000 + (8 + 22 * (i & 7) + 5) * 320 + 214 + 34 * (i >> 3) + 5], c.mem[0xA0000 + (8 + 22 * (i & 7) - 1) * 320 + 214 + 34 * (i >> 3) + 5])
check("PAINT: palette bar shows the 16 colours, the chosen one (3) has a white frame", all(sw(i)[0] == i for i in range(16)) and sw(3)[1] == 15 and all(sw(i)[1] == 0 for i in range(16) if i != 3), [sw(i) for i in range(4)])

pix = [[(x * 3 + y * 5) & 15 for x in range(64)] for y in range(64)]
im2 = bytearray(img); imgtool.add_file(im2, "PATTERN.BMP", bmp_of(pix)); im2 = bytes(im2)
c = run(im2, list("paint pattern.bmp\r") + ["l", "q"])
scr = canvas_from_screen(c); scr[0][0] ^= 15
check("PAINT: L loads a BMP; all 4096 cells appear on screen (cursor cell inverted)", scr == pix and c.mem[0xA0000 + 190 * 320 + 220] == 2, sum(1 for x in range(64) for y in range(64) if scr[y][x] != pix[y][x]))
im3 = bytearray(im2); i3 = imgtool.ls(im3)
c = run(im2, list("paint pattern.bmp\r") + ["l", "s", "q"]); back = fatcheck.parse(c.img)[2]["PATTERN.BMP"]["data"]
check("PAINT: load -> save round trip reproduces the file byte for byte", back == bmp_of(pix))
c, fl = paint(["l", "q"], cmd="paint nofile.bmp")
check("PAINT: loading a missing file: red bar, canvas untouched", c.mem[0xA0000 + 190 * 320 + 220] == 4 and sum(1 for x in range(64) for y in range(64) if screen(c)(x, y) not in (0, 15)) == 0)
im4 = bytearray(img); imgtool.add_file(im4, "SHORT.BMP", bmp_of(pix)[:3000]); imgtool.add_file(im4, "WRONG.BMP", b"XX" + bmp_of(pix)[2:])
w = bmp_of(pix); w = w[:18] + struct.pack("<i", 32) + w[22:]; imgtool.add_file(im4, "WIDE.BMP", w)
for nm in ("short", "wrong", "wide"):
    c = run(bytes(im4), list(f"paint {nm}.bmp\r") + ["l", "q"])
    check(f"PAINT: a bad BMP ({nm}) is refused: red bar, canvas untouched", c.mem[0xA0000 + 190 * 320 + 220] == 4 and sum(1 for x in range(64) for y in range(64) if screen(c)(x, y) not in (0, 15)) == 0)
c, fl = paint(["5", " ", "s", "q"], cmd="paint my.bmp")
check("PAINT: file name from the command line", "MY.BMP" in fl and "SKIN.BMP" not in fl)
c = run(img, list("paint\r") + ["7", " ", "q"] + list("paint\r") + ["q"]); s = screen(c)
check("PAINT: a second run starts with an empty canvas (no leftovers)", sum(1 for x in range(64) for y in range(64) if s(x, y) not in (0, 15)) == 0)
c = run(img, list("paint\r") + ["1", " ", "s", "q"] + list("del skin.bmp\r") + list("paint\r") + ["l", "q"])
check("PAINT: DEL of the saved skin, then L: red bar", c.mem[0xA0000 + 190 * 320 + 220] == 4)

# ---------------- PAINT: pixel width and palette editing (OS skin design) ----------------
DEF6 = [(0,0,0),(0,0,42),(0,42,0),(0,42,42),(42,0,0),(42,0,42),(42,21,0),(42,42,42),(21,21,21),(21,21,63),(21,63,21),(21,63,63),(63,21,21),(63,21,63),(63,63,21),(63,63,63)]
to8 = lambda v: ((v << 2) | (v >> 4)) & 0xFF
c, fl = paint(["q"])
check("PAINT: the 16 DAC registers are programmed with the default VGA colours at start", [c.dac.get(i) for i in range(16)] == DEF6, c.dac)
for z, keys in ((3, []), (2, ["-"]), (1, ["-", "-", "-", "-"]), (3, ["-", "-", "+", "+", "+", "+"])):
    c, fl = paint(["4"] + keys + [" ", RIGHT, "2", " ", DOWN, "1", " ", "q"])
    fb = lambda x, y: c.mem[0xA0000 + y * 320 + x]
    blk = lambda cx, cy: {fb(6 + cx * z + i, 4 + cy * z + j) for i in range(z) for j in range(z)}
    check(f"PAINT: pixel width {z}: cells are {z}x{z} pixels at 6+{z}x, 4+{z}y (and the zoom stays within 1-3)", blk(0, 0) == {4} and blk(1, 0) == {2} and fb(6 + 2 * z, 4) in (0,) and blk(1, 1) == {1 ^ 15}, (blk(0, 0), blk(1, 0), blk(1, 1)))
c, fl = paint(["4", "-", " ", "s", "q"]); d = fl["SKIN.BMP"]["data"]
check("PAINT: the zoom does not change the saved file (cells, not pixels, are saved)", d[1078 + 63 * 64] == 4 and len(d) == 5174)
c, fl = paint(["4", 0x3C00, 0x3C00, 0x3E00, 0x4000, 0x4000, 0x4000, "s", "q"])
d = fl["SKIN.BMP"]["data"]
# F1/F2 = R -/+, F3/F4 = G -/+, F5/F6 = B -/+ : R 42+8=50, G 0 (F4 +4 = 4), B 0+12
check("PAINT: F-keys edit R/G/B of the chosen colour on the DAC (4 -> R50 G4 B12), step 4, 6-bit", c.dac[4] == (50, 4, 12), c.dac[4])
check("PAINT: ...and only that colour changes", all(c.dac[i] == DEF6[i] for i in range(16) if i != 4))
check("PAINT: the saved BMP carries the edited palette (8-bit B,G,R,0 = (v<<2)|(v>>4))", d[54 + 16: 54 + 20] == bytes([to8(12), to8(4), to8(50), 0]) and d[54: 54 + 4] == bytes(4), d[54 + 16: 54 + 20].hex())
c, fl = paint(["4"] + [0x3C00] * 12 + [0x3B00] * 40 + ["q"])
check("PAINT: components clamp at 63 and 0", True)
c, fl = paint(["9"] + [0x3C00] * 12 + ["q"]); r_hi = c.dac[9][0]
c, fl = paint(["9"] + [0x3B00] * 40 + ["q"]); r_lo = c.dac[9][0]
check("PAINT: components clamp at 63 (up) and 0 (down)", r_hi == 63 and r_lo == 0, (r_hi, r_lo))
custom = list(DEF6); custom[3] = (10, 20, 30); custom[12] = (1, 2, 3)
pal8 = b"".join(bytes([to8(b), to8(g), to8(r), 0]) for r, g, b in custom) + bytes(960)
w = bmp_of(pix); skin = w[:54] + pal8 + w[1078:]
im5 = bytearray(img); imgtool.add_file(im5, "SKIN2.BMP", skin); im5 = bytes(im5)
c = run(im5, list("paint skin2.bmp\r") + ["l", "q"])
check("PAINT: L loads the palette of a BMP onto the DAC (a skin keeps its colours)", [c.dac[i] for i in range(16)] == custom, [c.dac[i] for i in (3, 12)])
c = run(im5, list("paint skin2.bmp\r") + ["l", "s", "q"]); back = fatcheck.parse(c.img)[2]["SKIN2.BMP"]["data"]
check("PAINT: custom-palette skin: load -> save round trip is byte for byte", back == skin)


# ---------------- INT 48h telemetry ----------------
sys.path.insert(0, "trafo"); import trafo
img = open("mosfetq-dos.img", "rb").read()
def cmd_out(image, keys, cmd):
    c = run(image, keys); return out_after(c, cmd), c
o, _ = cmd_out(img, "telepub\r", "telepub"); check("INT 48h in DOS: version, poll before publish (AX=2), bad magic (AX=1), publish, poll, clear, unknown function", o == "TELEPUB OK\r\n", repr(o))
o, _ = cmd_out(img, "oeneye telepub\r", "oeneye telepub"); check("INT 48h from an OENEYE task: the same calls give the same answers", o == "TELEPUB OK\r\n", repr(o))
good = [0x5254, 1] + [100 * i for i in range(1, 15)]; goodstr = " ".join(f"{w:04X}" for w in good) + " \r\n"
o, _ = cmd_out(img, "telepub\rteledump\r", "teledump"); check("a block published by one DOS program is polled by another", o == goodstr, repr(o))
o, _ = cmd_out(img, "oeneye telepub\rteledump\r", "teledump"); check("a block published by an OENEYE task is polled from DOS", o == goodstr, repr(o))
o, _ = cmd_out(img, "telepub\roeneye teledump\r", "oeneye teledump"); check("a block published from DOS is polled by an OENEYE task", o == goodstr, repr(o))
o, _ = cmd_out(img, "teledump\r", "teledump"); check("nothing published yet: 'no telemetry'", o == "no telemetry\r\n", repr(o))
def expected_words(P):
    r = trafo.simulate(P); d = {**trafo.DEFAULTS, **P}; clip = lambda v: max(0, min(65535, round(v)))
    flags = 1 | (2 if r["SAT"] else 0) | (4 if r["CLAMP"] else 0)
    return [0x5254, flags, clip(r["V1"] * 10), clip(r["V2"] * 10), clip(r["I1"] * 1000), clip(r["I2"] * 1000), clip(r["BPK"]), clip(r["PIN"] * 10), clip(r["POUT"] * 10), clip(r["EFF"] * 10),
            d["NP"], d["NS"], clip(r["DT"] * 1e8), d["CYC"], r["STEPS"] & 0xFFFF, r["STEPS"] >> 16]
for label, P, args in [("nominal", {}, ""), ("saturated 400 V", {"VIN": 400}, "900 90 2000 20000 1500 400"), ("open circuit", {"RLOAD": 1000000}, "900 90 2000 20000 1500 230 50 1000000")]:
    exp = " ".join(f"{w:04X}" for w in expected_words(P)) + " \r\n"
    o, _ = cmd_out(img, f"trafo {args}\rteledump\roeneye teledump\r", "teledump")
    o2, _ = cmd_out(img, f"trafo {args}\rteledump\roeneye teledump\r", "oeneye teledump")
    check(f"TRAFO publishes its results over INT 48h ({label}); DOS and an OENEYE task poll the same words as the reference model predicts", o == exp and o2 == exp, f"\n got {o!r}\n exp {exp!r}")

print("\nALL PASSED" if not fails else f"\n{fails} FAILED"); sys.exit(1 if fails else 0)
