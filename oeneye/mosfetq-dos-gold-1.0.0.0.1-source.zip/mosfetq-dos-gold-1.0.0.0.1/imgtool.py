#!/usr/bin/env python3
"""imgtool: add / list files in a MOSFETQ DOS FAT12 floppy image (8.3 names).
   python3 imgtool.py IMAGE add NAME.EXT file      python3 imgtool.py IMAGE ls"""
import struct, sys
from geom import geom

def _get(img, n):
    b = geom(img)['fat_lba'] * 512; o = b + n + n // 2; w = img[o] | img[o + 1] << 8
    return (w >> 4) if n & 1 else (w & 0xFFF)

def _set(img, n, v):
    for copy in range(2):
        G = geom(img); o = (G['fat_lba'] + copy * G['fat_sect']) * 512 + n + n // 2
        w = img[o] | img[o + 1] << 8
        w = ((w & 0xF000) | v) if n % 2 == 0 else ((w & 0x000F) | (v << 4))
        img[o], img[o + 1] = w & 0xFF, w >> 8

def name11(name):
    base, _, ext = name.upper().partition(".")
    assert len(base) <= 8 and len(ext) <= 3, "8.3 names only"
    return base.ljust(8).encode() + ext.ljust(3).encode()

def add_file(img, name, data):
    """img: bytearray (modified in place). Returns the first cluster."""
    G = geom(img); need = max(1, -(-len(data) // 512)); free = [n for n in range(2, G['maxclu']) if _get(img, n) == 0][:need]
    assert len(free) == need, "disk full"
    for i, c in enumerate(free):
        chunk = data[i * 512:(i + 1) * 512].ljust(512, b"\0")
        img[(G['data_lba'] + c - 2) * 512:(G['data_lba'] + c - 1) * 512] = chunk
        _set(img, c, free[i + 1] if i + 1 < need else 0xFFF)
    root = G['root_lba'] * 512
    for i in range(G['root_sect'] * 16):
        o = root + i * 32
        if img[o] in (0, 0xE5):
            img[o:o + 32] = name11(name) + bytes([0x20]) + bytes(10) + struct.pack("<HHHI", 0, 0x4C21, free[0], len(data))
            return free[0]
    raise RuntimeError("root directory full")

def ls(img):
    G = geom(img); root = G['root_lba'] * 512; out = []
    for i in range(G['root_sect'] * 16):
        e = img[root + i * 32: root + i * 32 + 32]
        if e[0] == 0: break
        if e[0] != 0xE5 and not e[11] & 8: out.append((bytes(e[:8]).decode().strip() + "." + bytes(e[8:11]).decode().strip(), struct.unpack_from("<I", e, 28)[0]))
    return out

if __name__ == "__main__":
    path, cmd = sys.argv[1], sys.argv[2]; img = bytearray(open(path, "rb").read())
    if cmd == "ls":
        for n, s in ls(img): print(f"{n:13s} {s:8d}")
    elif cmd == "add":
        add_file(img, sys.argv[3], open(sys.argv[4], "rb").read()); open(path, "wb").write(img); print("added", sys.argv[3])
