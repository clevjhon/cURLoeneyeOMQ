"""Disk geometry of a MOSFETQ DOS floppy image, read from its BPB (3.5" 1.44 MB or 5.25" 1.2 MB)."""
import struct
def geom(img):
    bps, spc, rsv, nfat, rootent, tot, media, fatsz, spt, heads = struct.unpack_from("<HBHBHHBHHH", img, 0x0B)
    root_lba = rsv + nfat * fatsz; root_sect = rootent * 32 // bps; data_lba = root_lba + root_sect
    return dict(bps=bps, fat_lba=rsv, nfat=nfat, fat_sect=fatsz, root_lba=root_lba, root_sect=root_sect, root_ent=rootent,
                data_lba=data_lba, total=tot, spt=spt, heads=heads, media=media, maxclu=tot - data_lba + 2)
