#!/usr/bin/env python3
"""oeneye trafo: single-phase transformer circuit simulator and design helper (reference engine).

Equivalent circuit (all referred to the primary):
    source -- R1 -- L1 --+--------+---------+-- L2' -- R2' -- RL'
                         |        |         |
                         Lm(sat)  Rc      (node e = d(lambda)/dt)
  L1 = L2' = LLK/2, R2' = R2 a^2, RL' = RL a^2, a = NP/NS.
  Magnetizing branch: flux linkage lambda, current i_m(lambda) piecewise linear with a hard knee at
  lambda_s = Bsat*NP*AE:   unsaturated  L = Lm0 = mu0*mur*NP^2*AE/LE,  saturated  L = Ls = Lm0/mur (air core).
  Rc = equivalent core-loss (eddy + hysteresis) resistance in parallel with the magnetizing branch.

Numerical scheme (identical to TRAFO.COM): backward Euler for all three states (i1, i2', lambda) at once. The
node equations are solved in closed form for the piecewise-linear core, so the fast L1/Rc pole and the tiny
saturated inductance cannot make it unstable. For accuracy the step is clamped:
    dt = min(T/spc, max(0.5 * min(L1/R1, L2'/(R2'+RL')), T/4000)).
"""
import math, sys, argparse
MU0 = 4e-7 * math.pi
SPC_MAX = 4000.0                                     # the accuracy clamp never asks for more steps per cycle than this

DEFAULTS = dict(NP=900, NS=90, MUR=2000, LLK=20000, BSAT=1500, VIN=230, FREQ=50, RLOAD=5300,
                AE=1000, LE=200, R1=5000, R2=50, RC=50000, CYC=4, SPC=200, PHASE=90)
# units: turns, -, -, uH (total, referred to the primary), mT, V rms, Hz, mOhm, mm^2, mm, mOhm, mOhm, Ohm, cycles, steps/cycle,
#        switch-on phase in degrees of the source voltage (90 = at the voltage peak: no flux offset; 0 = at the zero
#        crossing: worst-case inrush)

def simulate(P=None, record=False, **kw):
    p = dict(DEFAULTS); p.update(P or {}); p.update(kw)
    NP, NS = p["NP"], p["NS"]; a = NP / NS
    ae, le = p["AE"] * 1e-6, p["LE"] * 1e-3
    Lm0 = MU0 * p["MUR"] * NP * NP * ae / le
    Ls = Lm0 / p["MUR"]
    lams = p["BSAT"] * 1e-3 * NP * ae
    L1 = p["LLK"] * 1e-6 / 2.0; L2 = L1
    R1 = p["R1"] * 1e-3; RL = p["RLOAD"] * 1e-3
    Rl2 = p["R2"] * 1e-3 * a * a + RL * a * a
    Rc = float(p["RC"]); f = float(p["FREQ"]); T = 1.0 / f
    spc = int(p["SPC"]); cyc = int(p["CYC"])
    dt0 = T / spc
    xm = 0.5 * min(L1 / R1 if R1 > 0 else 1e9, L2 / Rl2 if Rl2 > 0 else 1e9)
    dt = min(dt0, max(xm, T / SPC_MAX))                          # timestep clamp (never below T/4000)
    dt_clamped = dt < dt0
    wdt = 2 * math.pi * f * dt
    Vp = p["VIN"] * math.sqrt(2.0)
    inv_dt = 1.0 / dt
    k1 = dt / L1; dn1 = 1.0 + dt * R1 / L1; B1 = k1 / dn1          # i1' = A1 - B1 e'
    k2 = dt / L2; dn2 = 1.0 + dt * Rl2 / L2; B2 = k2 / dn2         # i2' = A2 + B2 e'
    q1 = 1.0 + Rc * (B1 + B2 + dt / Lm0)                            # linear segment
    q2 = 1.0 + Rc * (B1 + B2 + dt / Ls)                             # saturated segment
    rcl0 = Rc / Lm0; rcls = Rc / Ls
    c3 = Rc * lams * (1.0 / Ls - 1.0 / Lm0)
    nsteps = int(round(cyc * T / dt))
    last = int(round(T / dt))                     # measure over the final cycle
    i1 = i2 = lam = 0.0; theta = math.radians(p["PHASE"])
    s_v1 = s_v2 = s_i1 = s_i2 = s_pin = s_pout = 0.0; lmax = 0.0; n_meas = 0
    rec = []; i1pk_all = 0.0
    for n in range(nsteps):
        theta += wdt
        vs = Vp * math.sin(theta)
        # backward Euler for all three states at once:  e' = d(lambda)/dt of the new step
        A1 = (i1 + k1 * vs) / dn1
        A2 = i2 / dn2
        num = Rc * (A1 - A2)
        e = (num - rcl0 * lam) / q1                                 # unsaturated?
        lam1 = lam + dt * e
        if abs(lam1) > lams:
            s = 1.0 if lam1 > 0 else -1.0
            e = (num - rcls * lam + s * c3) / q2                    # saturated branch
            lam2 = lam + dt * e
            if abs(lam2) < lams:                                    # ended up on the knee
                e = (s * lams - lam) * inv_dt
        i1 = A1 - B1 * e
        i2 = A2 + B2 * e
        lam = lam + dt * e
        i1pk_all = max(i1pk_all, abs(i1))
        if n >= nsteps - last:
            v2 = a * RL * i2; i2a = a * i2
            s_v1 += vs * vs; s_v2 += v2 * v2; s_i1 += i1 * i1; s_i2 += i2a * i2a
            s_pin += vs * i1; s_pout += v2 * i2a
            lmax = max(lmax, abs(lam)); n_meas += 1
            if record: rec.append((n, vs, i1, v2, i2a, lam, e))
    m = float(n_meas)
    r = dict(V1=math.sqrt(s_v1 / m), V2=math.sqrt(s_v2 / m), I1=math.sqrt(s_i1 / m), I2=math.sqrt(s_i2 / m),
             PIN=s_pin / m, POUT=s_pout / m, BPK=lmax / (NP * ae) * 1e3,          # mT
             SAT=int(lmax / (NP * ae) * 1e3 > p["BSAT"] * 0.999), DT=dt, CLAMP=int(dt_clamped), STEPS=nsteps, RATIO=a, I1PK_ALL=i1pk_all, Rl2=Rl2, R1=R1, Rc=Rc)
    r["EFF"] = 100.0 * r["POUT"] / r["PIN"] if r["PIN"] > 0 else 0.0
    if record: r["samples"] = rec
    return r

def design(vp, vs, va, f, ae_mm2, bmax_T=1.2, j_A_mm2=2.5, window_fill_mm2=None):
    """Turns and wire size from the transformer EMF equation  V = 4.44 f N B A (sine)."""
    ae = ae_mm2 * 1e-6
    np_ = math.ceil(vp / (4.44 * f * bmax_T * ae))
    ns = math.ceil(np_ * vs / vp * 1.03)                # +3 % for the load drop
    ip = va / vp; is_ = va / vs
    return dict(NP=np_, NS=ns, IP=ip, IS=is_, WIRE_P_MM2=ip / j_A_mm2, WIRE_S_MM2=is_ / j_A_mm2, BPK_T=vp * math.sqrt(2) / (2 * math.pi * f * np_ * ae))

def report(r):
    return (f"V1={r['V1']:.2f}V V2={r['V2']:.2f}V I1={r['I1']:.3f}A I2={r['I2']:.3f}A "
            f"P1={r['PIN']:.2f}W P2={r['POUT']:.2f}W EFF={r['EFF']:.1f}% BPK={r['BPK']:.0f}mT SAT={'YES' if r['SAT'] else 'NO'}")

def hpgl(samples, width=10000, height=6000):
    """Plot the recorded last cycle (source voltage and secondary voltage scaled) as an HPGL string."""
    vs = [s[1] for s in samples]; v2 = [s[3] for s in samples]; m = max(max(map(abs, vs)), 1e-9); n = len(samples)
    out = ["IN;SP1;"]
    for series, pen in ((vs, 1), (v2, 2)):
        out.append(f"SP{pen};")
        for i, v in enumerate(series):
            x = int(i * width / (n - 1)); y = int(height / 2 + v / m * height / 2 * 0.95)
            out.append(f"PU{x},{y};" if i == 0 else f"PD{x},{y};")
    out.append("PU;SP0;"); return "".join(out)

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sim", help="simulate; parameters as KEY=VALUE (see DEFAULTS)"); s.add_argument("kv", nargs="*"); s.add_argument("--csv"); s.add_argument("--hpgl")
    d = sub.add_parser("design", help="turns for a given transformer"); d.add_argument("--vp", type=float, required=True); d.add_argument("--vs", type=float, required=True)
    d.add_argument("--va", type=float, required=True); d.add_argument("--f", type=float, default=50); d.add_argument("--ae", type=float, required=True, help="core area mm^2"); d.add_argument("--bmax", type=float, default=1.2)
    a = ap.parse_args(argv)
    if a.cmd == "design":
        r = design(a.vp, a.vs, a.va, a.f, a.ae, a.bmax); print(" ".join(f"{k}={v:.3f}" if isinstance(v, float) else f"{k}={v}" for k, v in r.items())); return
    P = {k.upper(): float(v) if "." in v else int(v) for k, v in (x.split("=") for x in a.kv)}
    r = simulate(P, record=bool(a.csv or a.hpgl)); print(report(r))
    if a.csv:
        with open(a.csv, "w") as fh:
            fh.write("n,vs_V,i1_A,v2_V,i2_A,lambda_Wb,e_V\n"); [fh.write(",".join(f"{x:.6g}" for x in row) + "\n") for row in r["samples"]]
    if a.hpgl: open(a.hpgl, "w").write(hpgl(r["samples"]))

if __name__ == "__main__": main()
