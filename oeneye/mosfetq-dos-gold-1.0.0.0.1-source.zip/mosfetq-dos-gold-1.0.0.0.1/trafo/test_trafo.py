"""Validation of the reference engine against independent physics."""
import cmath, math, sys
sys.path.insert(0, "."); import trafo
fails = 0
def check(name, cond, extra=""):
    global fails; print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  " + str(extra))); fails += (not cond)
def rel(a, b): return abs(a - b) / abs(b)

# linear circuit (core never saturates): compare the time-domain result with the phasor solution
def phasor(P):
    p = dict(trafo.DEFAULTS); p.update(P); a = p["NP"] / p["NS"]; w = 2 * math.pi * p["FREQ"]
    Lm0 = trafo.MU0 * p["MUR"] * p["NP"] ** 2 * p["AE"] * 1e-6 / (p["LE"] * 1e-3)
    L1 = p["LLK"] * 1e-6 / 2; R1 = p["R1"] * 1e-3; Rl2 = (p["R2"] + p["RLOAD"]) * 1e-3 * a * a
    Z1 = R1 + 1j * w * L1; Z2 = Rl2 + 1j * w * L1
    Ym = 1 / p["RC"] + 1 / (1j * w * Lm0); Zp = 1 / (Ym + 1 / Z2)
    V1 = p["VIN"]; I1 = V1 / (Z1 + Zp); e = V1 - I1 * Z1; I2 = e / Z2
    V2 = abs(I2) * a * p["RLOAD"] * 1e-3; P1 = (V1 * I1.conjugate()).real; P2 = abs(I2) ** 2 * a * a * p["RLOAD"] * 1e-3
    return dict(I1=abs(I1), I2=abs(I2) * a, V2=V2, PIN=P1, POUT=P2)
for name, P in [("nominal 100 VA load", {"BSAT": 5000}), ("light load", {"BSAT": 5000, "RLOAD": 50000}), ("heavy load", {"BSAT": 5000, "RLOAD": 1000}),
                ("50 Hz, 1:1 isolation", {"BSAT": 5000, "NP": 400, "NS": 400, "VIN": 100, "RLOAD": 20000, "LLK": 4000, "R1": 800, "R2": 800, "AE": 1500}),
                ("400 Hz aircraft-style", {"BSAT": 5000, "FREQ": 400, "VIN": 115, "NP": 250, "NS": 60, "RLOAD": 3000, "AE": 600, "SPC": 400})]:
    r = trafo.simulate(P); ph = phasor(P)
    err = max(rel(r[k], ph[k]) for k in ("I1", "V2", "PIN", "POUT"))
    check(f"linear circuit vs phasor solution: {name} (worst error {err * 100:.2f} %)", err < 0.02, {k: (round(r[k], 4), round(ph[k], 4)) for k in ph})
r = trafo.simulate({"BSAT": 5000, "RLOAD": 1e6, "R1": 100, "LLK": 200})
check("no-load voltage ratio = NS/NP (within 0.5 %)", rel(r["V2"], r["V1"] / r["RATIO"]) < 0.005, (r["V2"], r["V1"] / r["RATIO"]))
r = trafo.simulate({}); emf = 230 * math.sqrt(2) / (2 * math.pi * 50 * 900 * 1e-3) * 1e3
check(f"peak flux density follows the EMF equation V = 4.44 f N B A ({r['BPK']:.0f} mT vs {emf:.0f} mT, drops account for the rest)", 0.97 < r["BPK"] / emf < 1.0 and not r["SAT"])
r = trafo.simulate({"RLOAD": 5300}, record=True); s = r["samples"]; n = len(s)
pin = sum(x[1] * x[2] for x in s) / n; pr1 = r["R1"] * sum(x[2] ** 2 for x in s) / n
pr2 = (r["Rl2"] - 5.3 * (900 / 90) ** 2) * sum((x[4] / (900 / 90)) ** 2 for x in s) / n
pcore = sum(x[6] ** 2 for x in s) / n / r["Rc"]; pout = r["POUT"]
check(f"energy balance over the last cycle: P_in {pin:.3f} W = out {pout:.3f} + R1 {pr1:.3f} + R2 {pr2:.3f} + core {pcore:.3f} (stored energy returns to its start)", rel(pin, pout + pr1 + pr2 + pcore) < 0.01, (pin, pout + pr1 + pr2 + pcore))
sat = trafo.simulate({"VIN": 400}); lin = trafo.simulate({"VIN": 400, "BSAT": 9000})
check(f"over-driven core saturates (Bpk {sat['BPK']:.0f} mT, flag {sat['SAT']}); a non-saturating core would need {lin['BPK']:.0f} mT", sat["SAT"] == 1 and lin["SAT"] == 0 and sat["BPK"] < lin["BPK"])
check(f"saturation makes the primary current peaky and much larger ({sat['I1']:.2f} A vs {lin['I1']:.2f} A rms at the same voltage)", sat["I1"] > 2.0 * lin["I1"], (sat["I1"], lin["I1"]))
check("saturation cuts the output: V2 drops below the linear value", sat["V2"] < lin["V2"] * 0.97, (sat["V2"], lin["V2"]))
a_ = trafo.simulate({"PHASE": 90}); b_ = trafo.simulate({"PHASE": 0})
check(f"inrush: switching on at the voltage zero crossing draws {b_['I1PK_ALL'] / a_['I1PK_ALL']:.1f}x the current peak of switching at the voltage peak", b_["I1PK_ALL"] > 3 * a_["I1PK_ALL"] and b_["SAT"] == 1, (b_["I1PK_ALL"], a_["I1PK_ALL"]))
r = trafo.simulate({"LLK": 60, "R1": 200, "RLOAD": 100, "R2": 100})
check(f"time-step clamp engages for small leakage inductance (dt = {r['DT'] * 1e6:.2f} us instead of {1e6 / 50 / 200:.0f} us, floored at T/4000) and the result stays finite and sane", r["CLAMP"] == 1 and math.isfinite(r["V2"]) and 0 < r["V2"] < 25 and r["EFF"] <= 100, r)
CV = {"R1": 60000, "LLK": 200000, "RLOAD": 100, "BSAT": 5000}; a1 = trafo.simulate({"SPC": 100, **CV}); a2 = trafo.simulate({"SPC": 800, **CV})
check(f"step-size convergence (large leakage so the clamp does not hide it): I1 {a1['I1']:.4f} vs {a2['I1']:.4f} A", a1["CLAMP"] == 0 and rel(a1["I1"], a2["I1"]) < 0.02 and rel(a1["V2"], a2["V2"]) < 0.02, (a1["CLAMP"], a1["I1"], a2["I1"]))
d = trafo.design(230, 24, 100, 50, 800, 1.2); r = trafo.simulate({"NP": d["NP"], "NS": d["NS"], "AE": 800, "RLOAD": int(24 ** 2 / 100 * 1000), "BSAT": 1500})
check(f"designer: {d['NP']}:{d['NS']} turns at 800 mm^2 gives {r['BPK']:.0f} mT in simulation (target 1200 mT), secondary {r['V2']:.1f} V for 24 V nominal", abs(r["BPK"] - 1200) < 50 and 22.5 < r["V2"] < 25 and not r["SAT"], (r["BPK"], r["V2"]))
print("\nALL PASSED" if not fails else f"\n{fails} FAILED"); sys.exit(1 if fails else 0)
