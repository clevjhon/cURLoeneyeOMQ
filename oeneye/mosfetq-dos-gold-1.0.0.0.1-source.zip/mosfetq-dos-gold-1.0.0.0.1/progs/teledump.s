# TELEDUMP.COM: polls INT 48h and prints the 16 words in hex (or "no telemetry").
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov ah, 2
    mov dx, offset blk
    int 0x48
    jc none
    mov si, offset blk
    mov cx, 16
lp:
    lodsw
    push cx
    push si
    call hex16
    pop si
    pop cx
    mov dl, ' '
    mov ah, 2
    int 0x21
    loop lp
    mov dl, 13
    mov ah, 2
    int 0x21
    mov dl, 10
    int 0x21
    int 0x20
none:
    mov dx, offset s_none
    mov ah, 9
    int 0x21
    int 0x20
hex16:
    mov cx, 4
hx:
    rol ax, 4
    push ax
    and al, 15
    add al, 48
    cmp al, 57
    jbe hd
    add al, 7
hd:
    mov dl, al
    mov ah, 2
    int 0x21
    pop ax
    loop hx
    ret
blk:    .space 32
s_none: .ascii "no telemetry\r\n$"
