# WAITER.COM [task, default 2]: RECEIVE from that task; when it ends the call returns error 2.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov bx, 2                    # the task to wait for: WAITER:1 waits for task 1 (default 2)
    cmp byte ptr [0x80], 0
    je nopid
    mov bl, [0x82]
    sub bl, '0'
nopid:
    mov si, offset msg
    mov ah, 2
    int 0x60
    add al, '0'
    mov [code], al
    mov dx, offset s
    mov ah, 9
    int 0x21
    int 0x20
msg:  .space 16
s:    .ascii "waiter: RECEIVE returned "
code: .ascii "?\r\n$"
