# BDF.COM file [P]  -  NASTRAN bulk data viewer / plotter
#   BDF MESH.BDF       prints a summary: cards counted, bounding box of the grid points
#   BDF MESH.BDF P     also plots the mesh (X-Y view) as HPGL to the plotter port (LPT1, handle 4)
# Reads GRID, CQUAD4, CTRIA3, CROD, CBAR, CBEAM in small-field format (8 columns per field) or free
# format (comma separated). Numbers may be 1.5, -2., 3.E+2, 1.5D0 or the NASTRAN shorthand 1.5-3
# (= 1.5E-3). Coordinates are kept as integers of 1/1000 unit (extra decimals are truncated).
# '$' comments, continuation lines, everything before BEGIN BULK / after ENDDATA is skipped;
# other cards are counted as OTHER. (CEND, BEGIN BULK and ENDDATA are recognised by their first letters.) Large-field cards (GRID*) are not read. At most 800 grid
# points and 800 elements (the rest is counted as DROPPED).
.intel_syntax noprefix
.code16
.global _start
.equ NAMEBUF, 0x0E00
.equ LINE,    0x0F00
.equ FLD,     0x1000            # 10 fields x 16 bytes
.equ FBUF,    0x1100            # 512-byte read buffer
.equ GID,     0x2000            # 800 x word
.equ GXYZ,    0x2800            # 800 x (x,y,z) 32-bit
.equ ELEM,    0x5000            # 800 x 10 bytes: type, pad, 4 node words
.equ OUT,     0x7000            # HPGL output buffer
.equ MAXG,    800
.equ MAXE,    800
.text
_start:
    mov si, 0x81
    call skipsp
    cmp byte ptr [si], 13
    je usage
    mov di, NAMEBUF
cpn:
    mov al, [si]
    cmp al, ' '
    je cpd
    cmp al, 13
    je cpd
    mov [di], al
    inc si
    inc di
    jmp cpn
cpd:
    mov byte ptr [di], 0
    call skipsp
    mov al, [si]
    and al, 0xDF
    cmp al, 'P'
    jne nop_
    mov byte ptr [plot], 1
nop_:
    mov dx, NAMEBUF
    mov ax, 0x3D00
    int 0x21
    jc cantopen
    mov [fh], ax
    mov byte ptr [inbulk], 1
lines:
    call getline
    jc eof
    call do_line
    cmp byte ptr [done], 0
    je lines
eof:
    mov bx, [fh]
    mov ah, 0x3E
    int 0x21
    call summary
    cmp byte ptr [plot], 0
    je exit0
    call plotmesh
    cmp byte ptr [perr], 0
    jne prnerr
exit0:
    mov ax, 0x4C00
    int 0x21
usage:
    mov dx, offset s_usage
    jmp fail
cantopen:
    mov dx, offset s_open
    jmp fail
prnerr:
    mov dx, offset s_prn
fail:
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21

# ---------------------------------------------------------------- input
getc:                           # AL = next byte, CF=1 at end of file
    mov bx, [bufpos]
    cmp bx, [buflen]
    jb gc_have
    push cx                     # getline keeps its character count in CX
    push dx
    mov bx, [fh]
    mov dx, FBUF
    mov cx, 512
    mov ah, 0x3F
    int 0x21
    pop dx
    pop cx
    jc gc_eof
    test ax, ax
    jz gc_eof
    mov [buflen], ax
    mov word ptr [bufpos], 0
    xor bx, bx
gc_have:
    mov al, [bx + FBUF]
    inc word ptr [bufpos]
    clc
    ret
gc_eof:
    stc
    ret

getline:                        # next line -> LINE (asciz, max 79 chars). CF=1 at end of file
    mov di, LINE
    xor cx, cx
    mov byte ptr [gl_any], 0
gl_lp:
    call getc
    jc gl_end
    mov byte ptr [gl_any], 1
    cmp al, 10
    je gl_eol
    cmp al, 13
    je gl_lp
    cmp cx, 79
    jae gl_lp
    mov [di], al
    inc di
    inc cx
    jmp gl_lp
gl_end:
    cmp byte ptr [gl_any], 0
    jne gl_eol
    stc
    ret
gl_eol:
    mov byte ptr [di], 0
    mov [llen], cx
    clc
    ret

# ---------------------------------------------------------------- cards
do_line:
    mov al, [LINE]
    test al, al
    jz dl_ret
    cmp al, '$'
    je dl_ret
    cmp al, ' '
    je dl_ret                   # blank first column: continuation / empty
    cmp al, '+'
    je dl_ret
    cmp al, '*'
    je dl_ret
    call split_fields
    mov si, FLD
    mov di, offset n_enddata
    call strpre
    jne dl_1
    mov byte ptr [done], 1
    ret
dl_1:
    mov si, FLD
    mov di, offset n_cend
    call strpre
    jne dl_2
    mov byte ptr [inbulk], 0
    ret
dl_2:
    mov si, FLD
    mov di, offset n_begin
    call strpre
    jne dl_3
    mov byte ptr [inbulk], 1
    ret
dl_3:
    cmp byte ptr [inbulk], 0
    je dl_ret
    mov si, FLD
    mov di, offset n_grid
    call streq
    je do_grid
    mov si, FLD
    mov di, offset n_quad
    call streq
    jne dl_4
    mov al, 1
    mov cx, 4
    jmp do_elem
dl_4:
    mov si, FLD
    mov di, offset n_tria
    call streq
    jne dl_5
    mov al, 2
    mov cx, 3
    jmp do_elem
dl_5:
    mov si, FLD
    mov di, offset n_rod
    call streq
    jne dl_6
    mov al, 3
    mov cx, 2
    jmp do_elem
dl_6:
    mov si, FLD
    mov di, offset n_bar
    call streq
    jne dl_7
    mov al, 4
    mov cx, 2
    jmp do_elem
dl_7:
    mov si, FLD
    mov di, offset n_beam
    call streq
    jne dl_8
    mov al, 5
    mov cx, 2
    jmp do_elem
dl_8:
    inc word ptr [cnt_other]
dl_ret:
    ret

strpre:                         # ZF=1 if the string at DI is a prefix of the string at SI
    push si
    push di
sp_lp:
    mov al, [di]
    test al, al
    jz sp_out                   # end of the prefix: match (ZF=1)
    cmp al, [si]
    jne sp_out
    inc si
    inc di
    jmp sp_lp
sp_out:
    pop di
    pop si
    ret

streq:                          # SI, DI asciz: ZF=1 if equal
    push si
    push di
se_lp:
    mov al, [si]
    cmp al, [di]
    jne se_out
    test al, al
    jz se_out
    inc si
    inc di
    jmp se_lp
se_out:
    pop di
    pop si
    ret

do_grid:
    mov bx, [ngrid]
    cmp bx, MAXG
    jae dg_drop
    mov si, FLD + 16
    call pint
    mov bx, [ngrid]
    shl bx, 1
    mov [bx + GID], ax
    mov si, FLD + 48            # X1, X2, X3 = fields 3, 4, 5
    call preal
    mov [t_x], ax
    mov [t_x + 2], dx
    mov si, FLD + 64
    call preal
    mov [t_y], ax
    mov [t_y + 2], dx
    mov si, FLD + 80
    call preal
    mov [t_z], ax
    mov [t_z + 2], dx
    mov bx, [ngrid]             # record offset = 12 * n
    mov ax, bx
    shl ax, 3
    shl bx, 2
    add bx, ax
    mov ax, [t_x]
    mov [bx + GXYZ], ax
    mov ax, [t_x + 2]
    mov [bx + GXYZ + 2], ax
    mov ax, [t_y]
    mov [bx + GXYZ + 4], ax
    mov ax, [t_y + 2]
    mov [bx + GXYZ + 6], ax
    mov ax, [t_z]
    mov [bx + GXYZ + 8], ax
    mov ax, [t_z + 2]
    mov [bx + GXYZ + 10], ax
    xor bx, bx                  # bounding box: axis 0..2 -> bb + 8*axis
dg_ax:
    mov si, bx
    shl si, 2
    mov ax, [si + t_x]
    mov dx, [si + t_x + 2]
    push bx
    shl bx, 3
    cmp word ptr [ngrid], 0
    jne dg_cmp
    mov [bx + bb], ax           # first point: min = max = value
    mov [bx + bb + 2], dx
    mov [bx + bb + 4], ax
    mov [bx + bb + 6], dx
    jmp dg_next
dg_cmp:
    cmp dx, [bx + bb + 2]       # value < min ?  (signed 32-bit)
    jl dg_min
    jg dg_maxchk
    cmp ax, [bx + bb]
    jae dg_maxchk
dg_min:
    mov [bx + bb], ax
    mov [bx + bb + 2], dx
    jmp dg_next
dg_maxchk:
    cmp dx, [bx + bb + 6]       # value > max ?
    jg dg_max
    jl dg_next
    cmp ax, [bx + bb + 4]
    jbe dg_next
dg_max:
    mov [bx + bb + 4], ax
    mov [bx + bb + 6], dx
dg_next:
    pop bx
    inc bx
    cmp bx, 3
    jb dg_ax
    inc word ptr [ngrid]
    inc word ptr [cnt_grid]
    ret
dg_drop:
    inc word ptr [dropped]
    ret

do_elem:                        # AL = type, CX = node count
    mov [e_type], al
    mov [e_n], cx
    mov bx, [nelem]
    cmp bx, MAXE
    jae de_drop
    mov ax, bx                  # record offset = 10 * n
    shl bx, 3
    shl ax, 1
    add bx, ax
    add bx, ELEM
    mov al, [e_type]
    mov [bx], al
    mov byte ptr [bx + 1], 0
    mov word ptr [bx + 2], 0
    mov word ptr [bx + 4], 0
    mov word ptr [bx + 6], 0
    mov word ptr [bx + 8], 0
    mov [e_rec], bx
    mov si, FLD + 48            # nodes are fields 3..
    mov cx, [e_n]
    mov di, 2
de_nd:
    push cx
    push di
    call pint
    pop di
    pop cx
    mov bx, [e_rec]
    mov [bx + di], ax
    add di, 2
    add si, 16
    loop de_nd
    mov bl, [e_type]
    xor bh, bh
    shl bx, 1
    inc word ptr [bx + cnt_el]
    inc word ptr [nelem]
    ret
de_drop:
    inc word ptr [dropped]
    ret

# ---------------------------------------------------------------- fields
split_fields:                   # LINE -> FLD[0..9], each trimmed asciz (name upper-cased)
    mov si, LINE
    mov cx, 9
sf_chk:
    mov al, [si]
    test al, al
    jz sf_fixed
    cmp al, ','
    je sf_free
    inc si
    loop sf_chk
sf_fixed:
    xor bx, bx                  # field k = columns 8k .. 8k+7
sf_fk:
    mov ax, bx
    shl ax, 3
    mov cx, [llen]
    sub cx, ax
    jbe sf_empty
    cmp cx, 8
    jbe sf_len
    mov cx, 8
sf_len:
    mov si, ax
    add si, LINE
    jmp sf_put
sf_empty:
    xor cx, cx
    mov si, LINE
sf_put:
    call put_field
    inc bx
    cmp bx, 10
    jb sf_fk
    jmp sf_up
sf_free:
    mov si, LINE
    xor bx, bx
sf_ft:
    mov dx, si                  # token start
    xor cx, cx
sf_fs:
    mov al, [si]
    test al, al
    jz sf_fe
    cmp al, ','
    je sf_fe
    inc si
    inc cx
    jmp sf_fs
sf_fe:
    push si
    mov si, dx
    call put_field
    pop si
    inc bx
    cmp bx, 10
    jae sf_up
    cmp byte ptr [si], 0
    je sf_rest
    inc si                      # skip the comma
    jmp sf_ft
sf_rest:
    cmp bx, 10                  # line ended: the remaining fields are empty
    jae sf_up
    xor cx, cx
    mov si, LINE
    call put_field
    inc bx
    jmp sf_rest
sf_up:
    mov si, FLD
sf_u:
    mov al, [si]
    test al, al
    jz sf_r
    cmp al, 'a'
    jb sf_n
    cmp al, 'z'
    ja sf_n
    sub al, 32
    mov [si], al
sf_n:
    inc si
    jmp sf_u
sf_r:
    ret

put_field:                      # SI = text, CX = length, BX = field number: trimmed copy to FLD + 16*BX
    push ax
    push cx
    push si
    push di
    mov di, bx
    shl di, 4
    add di, FLD
pf_ld:                          # leading blanks
    test cx, cx
    jz pf_end
    cmp byte ptr [si], ' '
    jne pf_tl
    inc si
    dec cx
    jmp pf_ld
pf_tl:                          # trailing blanks
    test cx, cx
    jz pf_end
    push si
    add si, cx
    cmp byte ptr [si - 1], ' '
    pop si
    jne pf_cp
    dec cx
    jmp pf_tl
pf_cp:
    cmp cx, 15
    jbe pf_c2
    mov cx, 15
pf_c2:
    rep movsb
pf_end:
    mov byte ptr [di], 0
    pop di
    pop si
    pop cx
    pop ax
    ret

# ---------------------------------------------------------------- numbers
pint:                           # SI -> digits: unsigned 16-bit in AX (saturates at 65535)
    push bx
    push cx
    push dx
    push si
    xor cx, cx
pi_lp:
    mov bl, [si]
    sub bl, '0'
    cmp bl, 9
    ja pi_done
    xor bh, bh
    mov ax, cx
    mov dx, 10
    mul dx
    test dx, dx
    jnz pi_sat
    add ax, bx
    jc pi_sat
    mov cx, ax
    inc si
    jmp pi_lp
pi_sat:
    mov cx, 0xFFFF
pi_done:
    mov ax, cx
    pop si
    pop dx
    pop cx
    pop bx
    ret

mul10:                          # DX:AX = DX:AX * 10 (unsigned, saturates at 7FFFFFFFh)
    push bx
    push cx
    mov cx, dx
    mov bx, 10
    mul bx
    push ax
    mov ax, cx
    mov cx, dx
    mul bx
    test dx, dx
    jnz m10_sat
    add ax, cx
    jc m10_sat
    test ah, 0x80
    jnz m10_sat
    mov dx, ax
    pop ax
    pop cx
    pop bx
    ret
m10_sat:
    pop ax
    mov dx, 0x7FFF
    mov ax, 0xFFFF
    pop cx
    pop bx
    ret

div10:                          # DX:AX = DX:AX / 10 (unsigned)
    push bx
    push cx
    mov bx, 10
    mov cx, ax
    mov ax, dx
    xor dx, dx
    div bx
    xchg ax, cx
    div bx
    mov dx, cx
    pop cx
    pop bx
    ret

preal:                          # SI -> field text. DX:AX = value * 1000 (signed 32-bit)
    push bx
    push cx
    push si
    xor ax, ax
    xor dx, dx
    mov byte ptr [pr_neg], 0
    mov byte ptr [pr_dot], 0
    mov byte ptr [pr_frac], 0
    mov byte ptr [pr_seen], 0
    mov word ptr [pr_exp], 0
    mov byte ptr [pr_esg], 0
    mov bl, [si]
    cmp bl, '-'
    jne pr_p
    mov byte ptr [pr_neg], 1
    inc si
    jmp pr_lp
pr_p:
    cmp bl, '+'
    jne pr_lp
    inc si
pr_lp:
    mov bl, [si]
    cmp bl, '0'
    jb pr_nd
    cmp bl, '9'
    ja pr_nd
    cmp byte ptr [pr_dot], 0
    je pr_add
    cmp byte ptr [pr_frac], 3
    jae pr_skip
    inc byte ptr [pr_frac]
pr_add:
    mov byte ptr [pr_seen], 1
    push bx
    call mul10
    pop bx
    sub bl, '0'
    xor bh, bh
    add ax, bx
    adc dx, 0
    test dh, 0x80
    jz pr_skip
    mov dx, 0x7FFF
    mov ax, 0xFFFF
pr_skip:
    inc si
    jmp pr_lp
pr_nd:
    cmp bl, '.'
    jne pr_e1
    cmp byte ptr [pr_dot], 0
    jne pr_done
    mov byte ptr [pr_dot], 1
    inc si
    jmp pr_lp
pr_e1:
    cmp bl, 'E'
    je pr_e
    cmp bl, 'e'
    je pr_e
    cmp bl, 'D'
    je pr_e
    cmp bl, 'd'
    je pr_e
    cmp bl, '+'
    je pr_es0
    cmp bl, '-'
    je pr_es0
    jmp pr_done
pr_es0:
    cmp byte ptr [pr_seen], 0   # a sign right after the mantissa starts the exponent (1.5-3)
    je pr_done
    jmp pr_es
pr_e:
    inc si
pr_es:
    mov bl, [si]
    cmp bl, '-'
    jne pr_es1
    mov byte ptr [pr_esg], 1
    inc si
    jmp pr_ed
pr_es1:
    cmp bl, '+'
    jne pr_ed
    inc si
pr_ed:
    mov bl, [si]
    sub bl, '0'
    cmp bl, 9
    ja pr_done
    mov bh, [pr_exp]            # exponent = exponent * 10 + digit, at most 99
    mov cl, bh
    shl bh, 2
    add bh, cl
    shl bh, 1
    add bh, bl
    cmp bh, 99
    jbe pr_ok
    mov bh, 99
pr_ok:
    mov [pr_exp], bh
    inc si
    jmp pr_ed
pr_done:
    cmp byte ptr [pr_frac], 3
    jae pr_ex
    call mul10
    inc byte ptr [pr_frac]
    jmp pr_done
pr_ex:
    xor cx, cx
    mov cl, [pr_exp]
    test cx, cx
    jz pr_sg
pr_xl:
    cmp byte ptr [pr_esg], 0
    jne pr_dv
    call mul10
    jmp pr_xn
pr_dv:
    call div10
pr_xn:
    loop pr_xl
pr_sg:
    cmp byte ptr [pr_neg], 0
    je pr_ret
    neg dx
    neg ax
    sbb dx, 0
pr_ret:
    pop si
    pop cx
    pop bx
    ret

# ---------------------------------------------------------------- output
pdec32:                         # DX:AX unsigned -> console
    push ax
    push bx
    push cx
    push dx
    push si
    mov bx, 10
    xor cx, cx
p32_lp:
    mov si, ax
    mov ax, dx
    xor dx, dx
    div bx
    xchg ax, si
    div bx
    push dx
    inc cx
    mov dx, si
    mov si, ax
    or si, dx
    jnz p32_lp
p32_out:
    pop dx
    add dl, '0'
    mov ah, 2
    int 0x21
    loop p32_out
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret

pdec16:                         # AX -> console
    push dx
    xor dx, dx
    call pdec32
    pop dx
    ret

pcoord:                         # DX:AX signed value*1000 -> "-12.345"
    push ax
    push bx
    push cx
    push dx
    test dh, 0x80
    jz pc_pos
    neg dx
    neg ax
    sbb dx, 0
    push ax
    push dx
    mov dl, '-'
    mov ah, 2
    int 0x21
    pop dx
    pop ax
pc_pos:
    mov bx, 1000
    mov cx, ax
    mov ax, dx
    xor dx, dx
    div bx
    xchg ax, cx
    div bx                      # DX = fraction, CX:AX = integer part
    mov si, dx
    mov dx, cx
    call pdec32
    mov dl, '.'
    mov ah, 2
    int 0x21
    mov ax, si                  # three digits
    xor dx, dx
    mov bx, 100
    div bx
    push dx
    add al, '0'
    mov dl, al
    mov ah, 2
    int 0x21
    pop ax
    mov bl, 10
    div bl
    push ax
    add al, '0'
    mov dl, al
    mov ah, 2
    int 0x21
    pop ax
    mov dl, ah
    add dl, '0'
    mov ah, 2
    int 0x21
    pop dx
    pop cx
    pop bx
    pop ax
    ret

crlf:
    mov dl, 13
    mov ah, 2
    int 0x21
    mov dl, 10
    mov ah, 2
    int 0x21
    ret

pstr:                           # DX -> '$'-terminated
    mov ah, 9
    int 0x21
    ret

summary:
    mov dx, offset s_bdf
    call pstr
    mov dx, NAMEBUF
    call pasz
    call crlf
    mov dx, offset s_g
    call pstr
    mov ax, [cnt_grid]
    call pdec16
    call crlf
    mov dx, offset s_q
    call pstr
    mov ax, [cnt_el + 2]
    call pdec16
    call crlf
    mov dx, offset s_t
    call pstr
    mov ax, [cnt_el + 4]
    call pdec16
    call crlf
    mov dx, offset s_r
    call pstr
    mov ax, [cnt_el + 6]
    call pdec16
    call crlf
    mov dx, offset s_b
    call pstr
    mov ax, [cnt_el + 8]
    call pdec16
    call crlf
    mov dx, offset s_e
    call pstr
    mov ax, [cnt_el + 10]
    call pdec16
    call crlf
    mov dx, offset s_o
    call pstr
    mov ax, [cnt_other]
    call pdec16
    call crlf
    cmp word ptr [dropped], 0
    je su_nd
    mov dx, offset s_d
    call pstr
    mov ax, [dropped]
    call pdec16
    call crlf
su_nd:
    cmp word ptr [ngrid], 0
    je su_ret
    xor bx, bx
su_ax:
    push bx
    mov dl, [bx + s_axes]
    mov ah, 2
    int 0x21
    mov dl, ' '
    int 0x21
    pop bx
    push bx
    shl bx, 3
    mov ax, [bx + bb]
    mov dx, [bx + bb + 2]
    call pcoord
    mov dx, offset s_dots
    call pstr
    pop bx
    push bx
    shl bx, 3
    mov ax, [bx + bb + 4]
    mov dx, [bx + bb + 6]
    call pcoord
    call crlf
    pop bx
    inc bx
    cmp bx, 3
    jb su_ax
su_ret:
    ret

pasz:                           # DX -> asciz on the console
    mov si, dx
pa_lp:
    lodsb
    test al, al
    jz pa_r
    mov dl, al
    mov ah, 2
    int 0x21
    jmp pa_lp
pa_r:
    ret

# ---------------------------------------------------------------- HPGL plot
outc:                           # AL -> plot buffer
    push bx
    mov bx, [outn]
    mov [bx + OUT], al
    inc bx
    mov [outn], bx
    cmp bx, 480
    jb oc_r
    call flush
oc_r:
    pop bx
    ret

flush:
    push ax
    push bx
    push cx
    push dx
    cmp word ptr [outn], 0
    je fl_r
    cmp byte ptr [perr], 0
    jne fl_clr
    mov bx, 4                   # PRN
    mov dx, OUT
    mov cx, [outn]
    mov ah, 0x40
    int 0x21
    jnc fl_clr
    mov byte ptr [perr], 1
fl_clr:
    mov word ptr [outn], 0
fl_r:
    pop dx
    pop cx
    pop bx
    pop ax
    ret

outs:                           # SI -> asciz -> plot buffer
    lodsb
    test al, al
    jz os_r
    call outc
    jmp outs
os_r:
    ret

outdec:                         # AX unsigned -> plot buffer
    push ax
    push bx
    push cx
    push dx
    xor cx, cx
    mov bx, 10
od_d:
    xor dx, dx
    div bx
    push dx
    inc cx
    test ax, ax
    jnz od_d
od_o:
    pop ax
    add al, '0'
    call outc
    loop od_o
    pop dx
    pop cx
    pop bx
    pop ax
    ret

node_xy:                        # AX = grid id -> [px], [py] in 0..10000. CF=1 if there is no such grid point
    push bx
    push cx
    push dx
    push si
    xor bx, bx
nx_s:
    cmp bx, [ngrid]
    jae nx_no
    mov si, bx
    shl si, 1
    cmp [si + GID], ax
    je nx_f
    inc bx
    jmp nx_s
nx_f:
    mov ax, bx
    shl ax, 3
    shl bx, 2
    add bx, ax                  # 12 * index
    mov si, bx
    mov ax, [si + GXYZ]         # x - minx, scaled
    mov dx, [si + GXYZ + 2]
    sub ax, [bb]
    sbb dx, [bb + 2]
    call scale
    mov [px], ax
    mov ax, [si + GXYZ + 4]
    mov dx, [si + GXYZ + 6]
    sub ax, [bb + 8]
    sbb dx, [bb + 10]
    call scale
    mov [py], ax
    clc
    jmp nx_r
nx_no:
    stc
nx_r:
    pop si
    pop dx
    pop cx
    pop bx
    ret

scale:                          # DX:AX = offset from the minimum -> 0..10000 (same scale for x and y)
    mov cl, [kshift]
    xor ch, ch
    jcxz sc_go
sc_sh:
    shr dx, 1
    rcr ax, 1
    loop sc_sh
sc_go:
    mov bx, 10000
    mul bx
    div word ptr [spanu]
    ret

plotmesh:
    cmp word ptr [ngrid], 0
    je pm_none
    mov ax, [bb + 4]            # span = max(maxx-minx, maxy-miny)
    mov dx, [bb + 6]
    sub ax, [bb]
    sbb dx, [bb + 2]
    mov cx, [bb + 12]
    mov bx, [bb + 14]
    sub cx, [bb + 8]
    sbb bx, [bb + 10]
    cmp bx, dx
    jb pm_sp
    ja pm_spy
    cmp cx, ax
    jbe pm_sp
pm_spy:
    mov ax, cx
    mov dx, bx
pm_sp:
    xor cx, cx                  # shift until the span fits in 16 bits
pm_k:
    test dx, dx
    jz pm_kd
    shr dx, 1
    rcr ax, 1
    inc cx
    jmp pm_k
pm_kd:
    mov [kshift], cl
    test ax, ax
    jnz pm_sn
    mov ax, 1
pm_sn:
    mov [spanu], ax
    mov si, offset h_in
    call outs
    xor bx, bx
    mov [ei], bx
pm_el:
    mov bx, [ei]
    cmp bx, [nelem]
    jae pm_end
    mov ax, bx
    shl bx, 3
    shl ax, 1
    add bx, ax
    add bx, ELEM
    mov [e_rec], bx
    call plot_elem
    inc word ptr [ei]
    jmp pm_el
pm_end:
    mov si, offset h_end
    call outs
    call flush
pm_none:
    mov dx, offset s_plot
    call pstr
    mov ax, [drawn]
    call pdec16
    mov dx, offset s_drawn
    call pstr
    mov ax, [skipped]
    call pdec16
    mov dx, offset s_skipped
    call pstr
    ret

plot_elem:                      # element at [e_rec]: PU first node; PD to the others (and back for 3+ nodes)
    mov bx, [e_rec]
    mov al, [bx]
    xor ah, ah
    mov si, ax
    mov al, [si + n_of_type]
    xor ah, ah
    mov [e_n], ax
    xor cx, cx                  # look up every node; any missing -> skip the element
pe_lk:
    cmp cx, [e_n]
    jae pe_ok
    mov bx, [e_rec]
    mov si, cx
    shl si, 1
    mov ax, [bx + si + 2]
    push cx
    call node_xy
    pop cx
    jc pe_skip
    mov si, cx
    shl si, 1
    mov ax, [px]
    mov [si + xs], ax
    mov ax, [py]
    mov [si + ys], ax
    inc cx
    jmp pe_lk
pe_skip:
    inc word ptr [skipped]
    ret
pe_ok:
    inc word ptr [drawn]
    mov si, offset h_pu
    call outs
    xor bx, bx
    call put_pt
    mov al, ';'
    call outc
    mov si, offset h_pd
    call outs
    mov bx, 1
pe_pd:
    cmp bx, [e_n]
    jae pe_close
    cmp bx, 1
    je pe_nc
    mov al, ','
    call outc
pe_nc:
    call put_pt
    inc bx
    jmp pe_pd
pe_close:
    cmp word ptr [e_n], 3
    jb pe_end
    mov al, ','
    call outc
    xor bx, bx
    call put_pt
pe_end:
    mov al, ';'
    call outc
    ret

put_pt:                         # BX = point 0..3 -> "x,y"
    push bx
    shl bx, 1
    mov ax, [bx + xs]
    call outdec
    mov al, ','
    call outc
    mov ax, [bx + ys]
    call outdec
    pop bx
    ret

skipsp:
    cmp byte ptr [si], ' '
    jne ss_r
    inc si
    jmp skipsp
ss_r:
    ret

# ---------------------------------------------------------------- data
n_grid:   .asciz "GRID"
n_quad:   .asciz "CQUAD4"
n_tria:   .asciz "CTRIA3"
n_rod:    .asciz "CROD"
n_bar:    .asciz "CBAR"
n_beam:   .asciz "CBEAM"
n_enddata: .asciz "ENDDATA"
n_cend:   .asciz "CEND"
n_begin:  .asciz "BEGIN"
n_of_type: .byte 0, 4, 3, 2, 2, 2
h_in:     .asciz "IN;SP1;"
h_end:    .asciz "PU;SP0;"
h_pu:     .asciz "PU"
h_pd:     .asciz "PD"
s_axes:   .ascii "XYZ"
s_bdf:    .ascii "BDF $"
s_g:      .ascii "GRID    $"
s_q:      .ascii "CQUAD4  $"
s_t:      .ascii "CTRIA3  $"
s_r:      .ascii "CROD    $"
s_b:      .ascii "CBAR    $"
s_e:      .ascii "CBEAM   $"
s_o:      .ascii "OTHER   $"
s_d:      .ascii "DROPPED $"
s_dots:   .ascii " .. $"
s_plot:   .ascii "PLOT $"
s_drawn:  .ascii " drawn, $"
s_skipped: .ascii " skipped\r\n$"
s_usage:  .ascii "Usage: BDF file [P]\r\n$"
s_open:   .ascii "BDF: cannot open the file\r\n$"
s_prn:    .ascii "BDF: printer error\r\n$"
plot:     .byte 0
inbulk:   .byte 1
done:     .byte 0
perr:     .byte 0
gl_any:   .byte 0
pr_neg:   .byte 0
pr_dot:   .byte 0
pr_frac:  .byte 0
pr_seen:  .byte 0
pr_esg:   .byte 0
pr_exp:   .word 0
e_type:   .byte 0
kshift:   .byte 0
fh:       .word 0
bufpos:   .word 0
buflen:   .word 0
llen:     .word 0
ngrid:    .word 0
nelem:    .word 0
dropped:  .word 0
cnt_grid: .word 0
cnt_other: .word 0
cnt_el:   .word 0, 0, 0, 0, 0, 0
e_n:      .word 0
e_rec:    .word 0
ei:       .word 0
outn:     .word 0
spanu:    .word 1
px:       .word 0
py:       .word 0
drawn:    .word 0
skipped:  .word 0
t_x:      .long 0
t_y:      .long 0
t_z:      .long 0
bb:       .space 24
xs:       .space 8
ys:       .space 8
