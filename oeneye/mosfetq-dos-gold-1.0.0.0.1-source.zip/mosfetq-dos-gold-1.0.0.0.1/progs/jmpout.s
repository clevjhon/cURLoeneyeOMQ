# JMPOUT.COM: far jump to a segment outside the task window.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    .byte 0xEA
    .word 0
    .word 0x2000
