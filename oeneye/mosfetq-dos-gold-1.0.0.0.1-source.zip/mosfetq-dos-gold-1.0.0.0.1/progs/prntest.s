# PRNTEST.COM: INT 21h AH=05 (print DL) and AH=40h to handle 4 (PRN);
# handle 3 (AUX) does not exist -> CF=1, AX=6.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov dl, 'O'
    mov ah, 5
    int 0x21
    mov dl, 'K'
    mov ah, 5
    int 0x21
    mov bx, 4
    mov dx, offset data
    mov cx, 5
    mov ah, 0x40
    int 0x21
    jc bad
    cmp ax, 5
    jne bad
    mov bx, 3
    mov dx, offset data
    mov cx, 5
    mov ah, 0x40
    int 0x21
    jnc bad
    cmp ax, 6
    jne bad
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
bad:
    mov dx, offset no
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
data: .ascii "-hpgl"
ok:   .ascii "PRNTEST OK\r\n$"
no:   .ascii "PRNTEST FAILED\r\n$"
