# BOX.COM: plots a square with a diagonal by sending HPGL to the plotter/printer
# port (handle 4 = PRN = LPT1). Point a plotter, or "qemu -parallel file:plot.hpg",
# at LPT1 and the file can be viewed with any HPGL viewer.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov bx, 4                       # PRN
    mov dx, offset hpgl
    mov cx, hpgl_end - hpgl
    mov ah, 0x40
    int 0x21
    jc fail
    mov ax, 0x4C00
    int 0x21
fail:
    mov dx, offset msg
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
hpgl:
    .ascii "IN;SP1;PA0,0;PD;PA1000,0,1000,1000,0,1000,0,0;PU;PA0,0;PD;PA1000,1000;PU;SP0;"
hpgl_end:
msg: .ascii "BOX: printer error\r\n$"
