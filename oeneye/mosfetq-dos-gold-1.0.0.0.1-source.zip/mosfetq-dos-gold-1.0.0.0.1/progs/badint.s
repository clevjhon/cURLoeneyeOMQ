# BADINT.COM: INT 13h is not available to tasks.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    int 0x13
    int 0x20
