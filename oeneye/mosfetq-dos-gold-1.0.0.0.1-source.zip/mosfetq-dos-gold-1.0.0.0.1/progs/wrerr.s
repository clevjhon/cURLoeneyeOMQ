# WRERR.COM: error handling of INT 21h create / write / close / delete.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov dx, offset f_docs           # A: creating a file named like a directory -> 5
    xor cx, cx
    mov ah, 0x3C
    int 0x21
    jnc bad
    cmp ax, 5
    jne bad
    mov dx, offset f_out            # B: create OUT1.TMP -> handle
    mov ah, 0x3C
    int 0x21
    jc bad
    mov [h], ax
    mov dx, offset f_out2           # C: only one file may be open for writing -> 4
    mov ah, 0x3C
    int 0x21
    jnc bad
    cmp ax, 4
    jne bad
    mov bx, [h]                     # D: a write handle cannot be read -> 5
    mov dx, offset buf
    mov cx, 4
    mov ah, 0x3F
    int 0x21
    jnc bad
    cmp ax, 5
    jne bad
    mov bx, [h]                     # E: ... or seeked -> 5
    xor cx, cx
    xor dx, dx
    mov ax, 0x4200
    int 0x21
    jnc bad
    cmp ax, 5
    jne bad
    mov dx, offset f_out            # F: the file being written cannot be deleted -> 5
    mov ah, 0x41
    int 0x21
    jnc bad
    cmp ax, 5
    jne bad
    mov bx, [h]                     # G: write 4 bytes, close
    mov dx, offset buf
    mov cx, 4
    mov ah, 0x40
    int 0x21
    jc bad
    cmp ax, 4
    jne bad
    mov bx, [h]
    mov ah, 0x3E
    int 0x21
    jc bad
    mov dx, offset f_out            # H: now it can be deleted
    mov ah, 0x41
    int 0x21
    jc bad
    mov dx, offset f_out            # I: deleting it again -> 2
    mov ah, 0x41
    int 0x21
    jnc bad
    cmp ax, 2
    jne bad
    mov dx, offset f_docs           # J: deleting a directory -> 5
    mov ah, 0x41
    int 0x21
    jnc bad
    cmp ax, 5
    jne bad
    mov dx, offset f_readme         # K: opening for reading still works, writing to that handle -> 5
    mov ax, 0x3D00
    int 0x21
    jc bad
    mov bx, ax
    mov dx, offset buf
    mov cx, 1
    mov ah, 0x40
    int 0x21
    jnc bad
    cmp ax, 5
    jne bad
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
bad:
    mov dx, offset no
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
h:        .word 0
buf:      .ascii "abcd"
f_docs:   .asciz "DOCS"
f_out:    .asciz "OUT1.TMP"
f_out2:   .asciz "OUT2.TMP"
f_readme: .asciz "README.TXT"
ok:       .ascii "WRERR OK\r\n$"
no:       .ascii "WRERR FAILED\r\n$"
