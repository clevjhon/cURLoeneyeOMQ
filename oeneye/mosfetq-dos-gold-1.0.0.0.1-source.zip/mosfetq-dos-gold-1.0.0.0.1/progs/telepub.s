# TELEPUB.COM: exercises INT 48h (telemetry): version, poll-before-publish, bad magic, publish, poll, clear, bad function.
# Run it on a freshly booted system (it expects "nothing published" at the start).
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov ah, 0                   # version
    int 0x48
    jc bad
    cmp ax, 0x0102
    jne bad
    cmp bx, 32
    jne bad
    mov ah, 2                   # nothing published yet -> CF=1, AX=2
    mov dx, offset inb
    int 0x48
    jnc bad
    cmp ax, 2
    jne bad
    mov ah, 1                   # wrong magic -> CF=1, AX=1
    mov dx, offset badblk
    int 0x48
    jnc bad
    cmp ax, 1
    jne bad
    mov ah, 1                   # publish a good block
    mov dx, offset goodblk
    int 0x48
    jc bad
    mov ah, 2                   # poll it back
    mov dx, offset inb
    int 0x48
    jc bad
    mov si, offset goodblk
    mov di, offset inb
    mov cx, 16
cmp_lp:
    lodsw
    cmp ax, [di]
    jne bad
    add di, 2
    loop cmp_lp
    mov ah, 3                   # clear
    int 0x48
    jc bad
    mov ah, 2
    mov dx, offset inb
    int 0x48
    jnc bad
    cmp ax, 2
    jne bad
    mov ah, 0x77                # unknown function
    int 0x48
    jnc bad
    cmp ax, 1
    jne bad
    mov ah, 1                   # leave a block for the next program
    mov dx, offset goodblk
    int 0x48
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
bad:
    mov dx, offset no
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
goodblk: .word 0x5254, 1, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400
badblk:  .word 0x1234, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
inb:     .space 32
ok:      .ascii "TELEPUB OK\r\n$"
no:      .ascii "TELEPUB FAILED\r\n$"
