# FARTEST.COM: far call/RETF, RET n, far JMP, LES/LDS, IRET, indirect far call/jump, push/pop segment registers.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    .byte 0x9A                  # 1: call far 1000:sub1
    .word sub1
    .word 0x1000
    cmp ax, 0x1234
    jne f1
    mov cx, sp                  # 2: RET 4 pops two extra words
    push ax
    push ax
    call sub2
    cmp cx, sp
    jne f2
    .byte 0xEA                  # 3: jmp far 1000:l3
    .word l3
    .word 0x1000
    jmp f3
l3:
    les di, [fp]                # 4: LES / LDS load offset + segment from memory
    mov ax, es
    cmp ax, 0x1000
    jne f4
    cmp di, offset data
    jne f4
    mov ax, 0
    mov ds, ax                  #    (DS=0 is outside the window: only load it after the checks)
    push cs
    pop ds
    lds si, [fp]
    mov ax, ds
    cmp ax, 0x1000
    jne f4
    cmp si, offset data
    jne f4
    pushf                       # 5: IRET pops IP, CS, FLAGS
    push cs
    mov ax, offset l5
    push ax
    iret
    jmp f5
l5:
    call dword ptr [fpsub]      # 6: indirect far call
    cmp ax, 0x1234
    jne f6
    jmp dword ptr [fpl7]        # 7: indirect far jump
    jmp f7
l7:
    push es                     # 8: segment register push/pop
    push ds
    pop es
    pop ds
    mov ax, ds
    mov bx, es
    cmp ax, bx
    jne f8
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
sub1:
    mov ax, 0x1234
    .byte 0xCB                  # retf
sub2:
    .byte 0xC2, 0x04, 0x00      # ret 4
f1: mov al, '1'
    jmp fail
f2: mov al, '2'
    jmp fail
f3: mov al, '3'
    jmp fail
f4: mov al, '4'
    jmp fail
f5: mov al, '5'
    jmp fail
f6: mov al, '6'
    jmp fail
f7: mov al, '7'
    jmp fail
f8: mov al, '8'
fail:
    mov [code], al
    mov dx, offset no
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
fp:     .word data
        .word 0x1000
fpsub:  .word sub1
        .word 0x1000
fpl7:   .word l7
        .word 0x1000
data:   .word 0x5555
ok:     .ascii "FARTEST OK\r\n$"
no:     .ascii "FARTEST FAILED at step "
code:   .ascii "?\r\n$"
