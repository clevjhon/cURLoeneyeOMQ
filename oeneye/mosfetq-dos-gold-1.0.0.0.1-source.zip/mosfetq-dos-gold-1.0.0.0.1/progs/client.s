# CLIENT.COM [server task, default 1]: asks SERVER to double 10, 20, 30 and prints the answers, then tells it to quit.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov byte ptr [server], 1        # server task: CLIENT:2 talks to task 2 (default 1)
    cmp byte ptr [0x80], 0
    je nosrv
    mov al, [0x82]
    sub al, '0'
    mov [server], al
nosrv:
    mov word ptr [n], 10
    mov cx, 3
next:
    push cx
    mov word ptr [msg + 2], 1
    mov ax, [n]
    mov [msg + 4], ax
    mov si, offset msg
    xor bx, bx
    mov bl, [server]
    mov ah, 1                   # SEND to the server
    int 0x60
    mov si, offset msg
    xor bx, bx
    mov bl, [server]
    mov ah, 2                   # RECEIVE the reply from the server
    int 0x60
    mov dx, offset s_got
    mov ah, 9
    int 0x21
    mov ax, [msg + 4]
    call printdec
    mov dl, 13
    mov ah, 2
    int 0x21
    mov dl, 10
    int 0x21
    add word ptr [n], 10
    pop cx
    loop next
    mov word ptr [msg + 2], 0x99
    mov si, offset msg
    xor bx, bx
    mov bl, [server]
    mov ah, 1                   # SEND quit
    int 0x60
    mov ax, 0x4C00
    int 0x21
printdec:                       # AX -> decimal on the console
    xor cx, cx
    mov bx, 10
pd1:
    xor dx, dx
    div bx
    push dx
    inc cx
    test ax, ax
    jnz pd1
pd2:
    pop dx
    add dl, '0'
    mov ah, 2
    int 0x21
    loop pd2
    ret
n:     .word 0
server: .byte 1
msg:   .space 16
s_got: .ascii "got $"
