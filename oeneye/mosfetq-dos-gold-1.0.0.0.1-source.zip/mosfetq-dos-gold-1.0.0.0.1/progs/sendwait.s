# SENDWAIT.COM: SEND to task 2 (which never receives); when task 2 ends the SEND returns error 2.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov si, offset msg
    mov bx, 2
    mov ah, 1
    int 0x60
    add al, '0'
    mov [code], al
    mov dx, offset s
    mov ah, 9
    int 0x21
    int 0x20
msg:  .space 16
s:    .ascii "sendwait: SEND returned "
code: .ascii "?\r\n$"
