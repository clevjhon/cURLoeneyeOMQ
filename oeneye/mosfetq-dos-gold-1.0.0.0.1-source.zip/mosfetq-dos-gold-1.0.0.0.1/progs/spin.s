# SPIN.COM <letter>: prints its letter 6 times with a busy delay in between and never yields:
# two copies under OENEYE interleave only because the scheduler pre-empts them.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov al, [0x82]              # first character of the command tail (" X")
    mov [letter], al
    mov cx, 6
again:
    push cx
    mov dl, [letter]
    mov ah, 2
    int 0x21
    mov cx, 60                  # busy delay
d:  loop d
    pop cx
    loop again
    mov dl, 13
    mov ah, 2
    int 0x21
    mov dl, 10
    int 0x21
    mov ax, 0x4C00
    int 0x21
letter: .byte 0
