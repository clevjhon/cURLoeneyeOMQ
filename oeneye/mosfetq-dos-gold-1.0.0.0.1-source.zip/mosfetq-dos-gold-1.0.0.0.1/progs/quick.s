# QUICK.COM: exits at once.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov ax, 0x4C00
    int 0x21
