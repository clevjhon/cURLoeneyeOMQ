# SERVER.COM: MINIX-style server. RECEIVE from anyone; type 1 = double payload word 2 and reply; type 99h = quit.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
next:
    mov si, offset msg
    mov bx, 0xFFFF              # from anyone
    mov ah, 2                   # RECEIVE
    int 0x60
    cmp word ptr [msg + 2], 0x99
    je quit
    mov ax, [msg + 4]
    add ax, ax                  # the "service": double the number
    mov [msg + 4], ax
    mov bx, [msg]               # word 0 = who sent it
    mov si, offset msg
    mov ah, 1                   # SEND the reply
    int 0x60
    jmp next
quit:
    mov ax, 0x4C00
    int 0x21
msg: .space 16
