# TRAFO.COM [NP NS MUR LLK BSAT VIN FREQ RLOAD AE LE R1 R2 RC PHASE CYC SPC] [C] [H]
#
# Single-phase transformer circuit simulator (needs an 8087+ FPU). Same model and numerical scheme as
# trafo/trafo.py (see the header comment there): saturating core, core-loss resistor, leakage inductance,
# winding resistance, resistive load; backward Euler for the three states solved in closed form; time step
# clamped for accuracy. All numbers are integers (missing ones take the defaults):
#   NP NS   turns                MUR  relative permeability    LLK  leakage inductance, uH (total, primary side)
#   BSAT    saturation flux, mT  VIN  source, V rms            FREQ Hz             RLOAD load, milliohm
#   AE      core area, mm^2      LE   core path length, mm     R1 R2 winding resistances, milliohm
#   RC      core-loss resistance, ohm    PHASE  switch-on angle of the source, degrees (90 = at the voltage peak)
#   CYC     cycles simulated (default 4)   SPC  steps per cycle before clamping (default 200)
# Flags: C = write TRAFO.CSV (last cycle), H = send an HPGL plot of the last cycle to PRN (LPT1).
# Result line and INT 48h telemetry (published for other programs / OENEYE tasks to poll).
.intel_syntax noprefix
.code16
.global _start
.equ SAMPLES, 0x5000            # 200 samples x 4 dwords (vs dV, i1 mA, v2 dV, i2 mA)
.equ OUTBUF,  0x6000            # text buffer for the CSV / HPGL output
.equ NSAMP,   200
.text
.macro ldq v
    fld qword ptr [\v]
.endm
.macro stq v
    fst qword ptr [\v]
.endm
.macro stpq v
    fstp qword ptr [\v]
.endm
_start:
    fninit
    cld
    mov si, 0x81
    xor bx, bx                  # BX = index of the next number
tok:
    call skipsp
    mov al, [si]
    cmp al, 13
    je parsed
    test al, al
    jz parsed
    cmp al, '?'
    je usage
    cmp al, '0'
    jb flagtok
    cmp al, '9'
    ja flagtok
    xor ax, ax                  # a decimal number -> DX:AX
    xor dx, dx
numlp:
    mov cl, [si]
    sub cl, '0'
    cmp cl, 9
    ja numdone
    push cx
    call mul10
    pop cx
    xor ch, ch
    add ax, cx
    adc dx, 0
    inc si
    jmp numlp
numdone:
    cmp bx, 16
    jae tok
    push bx
    shl bx, 2
    mov [bx + par], ax
    mov [bx + par + 2], dx
    pop bx
    inc bx
    jmp tok
flagtok:
    and al, 0xDF                # upper case
    cmp al, 'C'
    jne notc
    mov byte ptr [f_csv], 1
notc:
    cmp al, 'H'
    jne notH
    mov byte ptr [f_hpgl], 1
notH:
skipword:
    mov al, [si]
    cmp al, ' '
    je tok
    cmp al, 13
    je parsed
    test al, al
    jz parsed
    inc si
    jmp skipword
parsed:
    # ---- parameters as doubles ----
    mov cx, 16
    xor bx, bx
    xor si, si
cvt:
    fild dword ptr [bx + par]
    fstp qword ptr [si + pv]
    add bx, 4
    add si, 8
    loop cvt
    # ---- constants of the model (same operation order as trafo.py) ----
    ldq pv+0                    # a = NP/NS
    fdiv qword ptr [pv+8]
    stpq a
    ldq pv+64                   # ae = AE*1e-6
    fmul qword ptr [c1e6m]
    stpq ae
    ldq pv+72                   # lepath = LE*1e-3
    fmul qword ptr [c1e3m]
    stpq lepath
    ldq c_mu0                   # Lm0 = MU0*MUR*NP*NP*ae/lepath
    fmul qword ptr [pv+16]
    fmul qword ptr [pv+0]
    fmul qword ptr [pv+0]
    fmul qword ptr [ae]
    fdiv qword ptr [lepath]
    stpq Lm0
    ldq Lm0                     # Ls = Lm0/MUR
    fdiv qword ptr [pv+16]
    stpq Ls
    ldq pv+32                   # lams = BSAT*1e-3*NP*ae
    fmul qword ptr [c1e3m]
    fmul qword ptr [pv+0]
    fmul qword ptr [ae]
    stpq lams
    ldq pv+24                   # L1 = LLK*1e-6/2
    fmul qword ptr [c1e6m]
    fdiv qword ptr [c2]
    stpq L1
    ldq pv+80                   # R1 = R1*1e-3
    fmul qword ptr [c1e3m]
    stpq R1f
    ldq pv+56                   # RL = RLOAD*1e-3
    fmul qword ptr [c1e3m]
    stpq RL
    ldq pv+88                   # Rl2 = R2*1e-3*a*a + RL*a*a
    fmul qword ptr [c1e3m]
    fmul qword ptr [a]
    fmul qword ptr [a]
    ldq RL
    fmul qword ptr [a]
    fmul qword ptr [a]
    faddp st(1), st
    stpq Rl2
    ldq RL                      # aRL = a*RL
    fmul qword ptr [a]
    stpq aRL
    fld1                        # T = 1/f
    fdiv qword ptr [pv+48]
    stpq T
    ldq T                       # dt0 = T/SPC
    fdiv qword ptr [pv+120]
    stpq dt0
    ldq c1e9                    # x1 = L1/R1 (1e9 if R1 = 0)
    cmp word ptr [par+40], 0
    jne x1a
    cmp word ptr [par+42], 0
    je x1b
x1a:
    fstp st(0)
    ldq L1
    fdiv qword ptr [R1f]
x1b:
    stpq x1
    ldq c1e9                    # x2 = L2/Rl2 (1e9 if the secondary loop has no resistance)
    mov ax, [par+44]
    or ax, [par+46]
    or ax, [par+28]
    or ax, [par+30]
    jz x2b
    fstp st(0)
    ldq L1
    fdiv qword ptr [Rl2]
x2b:
    stpq x2
    ldq x1                      # min(x1, x2)
    fcomp qword ptr [x2]
    fnstsw ax
    sahf
    jbe x1small
    ldq x2
    jmp gotmin
x1small:
    ldq x1
gotmin:
    fmul qword ptr [c05]
    stpq xm
    ldq T                       # never below T/4000 steps per cycle
    fdiv qword ptr [c4000]
    stpq dtmin
    ldq xm
    fcomp qword ptr [dtmin]
    fnstsw ax
    sahf
    jae xmok
    ldq dtmin
    stpq xm
xmok:
    ldq dt0                     # dt = min(dt0, 0.5*min(...))
    fcomp qword ptr [xm]
    fnstsw ax
    sahf
    jbe usedt0
    ldq xm
    stpq dt
    mov byte ptr [clamped], 1
    jmp dtok
usedt0:
    ldq dt0
    stpq dt
dtok:
    ldq c2pi                    # wdt = 2*pi*f*dt
    fmul qword ptr [pv+48]
    fmul qword ptr [dt]
    stpq wdt
    ldq pv+40                   # Vp = VIN*sqrt(2)
    fmul qword ptr [csqrt2]
    stpq Vp
    fld1
    fdiv qword ptr [dt]
    stpq inv_dt
    ldq dt                      # kk1 = dt/L1 ; dn1 = 1 + dt*R1/L1 ; B1 = kk1/dn1
    fdiv qword ptr [L1]
    stpq kk1
    ldq dt
    fmul qword ptr [R1f]
    fdiv qword ptr [L1]
    fld1
    faddp st(1), st
    stpq dn1
    ldq kk1
    fdiv qword ptr [dn1]
    stpq B1
    ldq kk1                      # kk2 = dt/L2 ; dn2 = 1 + dt*Rl2/L2 ; B2 = kk2/dn2   (L2 = L1)
    stpq kk2
    ldq dt
    fmul qword ptr [Rl2]
    fdiv qword ptr [L1]
    fld1
    faddp st(1), st
    stpq dn2
    ldq kk2
    fdiv qword ptr [dn2]
    stpq B2
    ldq B1                      # q1 = 1 + Rc*((B1+B2) + dt/Lm0)
    fadd qword ptr [B2]
    ldq dt
    fdiv qword ptr [Lm0]
    faddp st(1), st
    fmul qword ptr [pv+96]
    fld1
    faddp st(1), st
    stpq q1
    ldq B1                      # q2 = 1 + Rc*((B1+B2) + dt/Ls)
    fadd qword ptr [B2]
    ldq dt
    fdiv qword ptr [Ls]
    faddp st(1), st
    fmul qword ptr [pv+96]
    fld1
    faddp st(1), st
    stpq q2
    ldq pv+96                   # rcl0 = Rc/Lm0 ; rcls = Rc/Ls
    fdiv qword ptr [Lm0]
    stpq rcl0
    ldq pv+96
    fdiv qword ptr [Ls]
    stpq rcls
    ldq pv+96                   # c3 = Rc*lams*(1/Ls - 1/Lm0)
    fmul qword ptr [lams]
    fld1
    fdiv qword ptr [Ls]
    fld1
    fdiv qword ptr [Lm0]
    fchs
    faddp st(1), st
    fmulp st(1), st
    stpq c3
    ldq pv+112                  # nsteps = round(CYC*T/dt)
    fmul qword ptr [T]
    fdiv qword ptr [dt]
    fistp dword ptr [nsteps]
    ldq T                       # last = round(T/dt)
    fdiv qword ptr [dt]
    fistp dword ptr [last]
    ldq pv+104                  # theta = radians(PHASE)
    fmul qword ptr [cdeg]
    stpq theta
    mov ax, [nsteps]
    mov dx, [nsteps + 2]
    mov [rem], ax
    mov [rem + 2], dx
    # decimation of the recorded last cycle: keep every kdec-th step so that at most NSAMP are stored
    mov ax, [last]
    mov dx, [last + 2]
    mov bx, NSAMP
    div bx                      # (last < 65536*200 assumed) AX = last / 200
    inc ax
    mov [kdec], ax
    mov word ptr [kcnt], 0

# ================================================================ time stepping
step:
    ldq theta
    fadd qword ptr [wdt]
    stq theta
    fsin
    fmul qword ptr [Vp]
    stpq vs
    ldq kk1                      # A1 = (i1 + kk1*vs)/dn1
    fmul qword ptr [vs]
    fadd qword ptr [i1]
    fdiv qword ptr [dn1]
    stpq A1
    ldq i2                      # A2 = i2/dn2
    fdiv qword ptr [dn2]
    stpq A2
    ldq A1                      # num = Rc*(A1 - A2)
    fsub qword ptr [A2]
    fmul qword ptr [pv+96]
    stpq num
    ldq rcl0                    # e = (num - rcl0*lam)/q1
    fmul qword ptr [lam]
    fchs
    fadd qword ptr [num]
    fdiv qword ptr [q1]
    stpq e
    ldq dt                      # lam1 = lam + dt*e
    fmul qword ptr [e]
    fadd qword ptr [lam]
    stq lam1
    fabs
    fcomp qword ptr [lams]
    fnstsw ax
    sahf
    jbe unsat
    fld1                        # saturated: s = +1 / -1 by the sign of lam1
    test byte ptr [lam1 + 7], 0x80
    jz spos
    fchs
spos:
    stpq s
    ldq rcls                    # e = (num - rcls*lam + s*c3)/q2
    fmul qword ptr [lam]
    fchs
    fadd qword ptr [num]
    ldq s
    fmul qword ptr [c3]
    faddp st(1), st
    fdiv qword ptr [q2]
    stpq e
    ldq dt                      # lam2 = lam + dt*e ; on the knee if |lam2| < lams
    fmul qword ptr [e]
    fadd qword ptr [lam]
    fabs
    fcomp qword ptr [lams]
    fnstsw ax
    sahf
    jae unsat
    ldq s                       # e = (s*lams - lam)*inv_dt
    fmul qword ptr [lams]
    fsub qword ptr [lam]
    fmul qword ptr [inv_dt]
    stpq e
unsat:
    ldq B1                      # i1 = A1 - B1*e
    fmul qword ptr [e]
    fchs
    fadd qword ptr [A1]
    stpq i1
    ldq B2                      # i2 = A2 + B2*e
    fmul qword ptr [e]
    fadd qword ptr [A2]
    stpq i2
    ldq dt                      # lam += dt*e
    fmul qword ptr [e]
    fadd qword ptr [lam]
    stpq lam
    ldq i1                      # peak |i1| over the whole run (inrush)
    fabs
    fcomp qword ptr [i1pk]
    fnstsw ax
    sahf
    jbe nopk
    ldq i1
    fabs
    stpq i1pk
nopk:
    mov dx, [rem + 2]           # measure the last cycle: remaining steps <= last
    mov ax, [rem]
    cmp dx, [last + 2]
    ja nomeas
    jb domeas
    cmp ax, [last]
    ja nomeas
domeas:
    call measure
nomeas:
    sub word ptr [rem], 1
    sbb word ptr [rem + 2], 0
    mov ax, [rem]
    or ax, [rem + 2]
    jnz step
    jmp results

measure:
    ldq aRL                     # v2 = a*RL*i2 ; i2a = a*i2
    fmul qword ptr [i2]
    stpq v2
    ldq a
    fmul qword ptr [i2]
    stpq i2a
    ldq vs
    fmul qword ptr [vs]
    fadd qword ptr [s_v1]
    stpq s_v1
    ldq v2
    fmul qword ptr [v2]
    fadd qword ptr [s_v2]
    stpq s_v2
    ldq i1
    fmul qword ptr [i1]
    fadd qword ptr [s_i1]
    stpq s_i1
    ldq i2a
    fmul qword ptr [i2a]
    fadd qword ptr [s_i2]
    stpq s_i2
    ldq vs
    fmul qword ptr [i1]
    fadd qword ptr [s_pin]
    stpq s_pin
    ldq v2
    fmul qword ptr [i2a]
    fadd qword ptr [s_pout]
    stpq s_pout
    ldq lam
    fabs
    fcomp qword ptr [lmax]
    fnstsw ax
    sahf
    jbe nolm
    ldq lam
    fabs
    stpq lmax
nolm:
    add word ptr [nmeas], 1
    adc word ptr [nmeas + 2], 0
    cmp word ptr [nsamp], NSAMP # record every kdec-th step of the last cycle
    jae ms_ret
    mov ax, [kcnt]
    test ax, ax
    jnz ms_skip
    mov bx, [nsamp]
    shl bx, 4
    add bx, SAMPLES
    ldq vs
    fmul qword ptr [c10]
    fistp dword ptr [bx]
    ldq i1
    fmul qword ptr [c1000]
    fistp dword ptr [bx + 4]
    ldq v2
    fmul qword ptr [c10]
    fistp dword ptr [bx + 8]
    ldq i2a
    fmul qword ptr [c1000]
    fistp dword ptr [bx + 12]
    inc word ptr [nsamp]
    mov word ptr [kcnt], 0
ms_skip:
    inc word ptr [kcnt]
    mov ax, [kcnt]
    cmp ax, [kdec]
    jb ms_ret
    mov word ptr [kcnt], 0
ms_ret:
    ret

# ================================================================ results
results:
    fild dword ptr [nmeas]      # m
    stpq mf
    ldq s_v1                    # V1 = sqrt(s_v1/m) ... 
    fdiv qword ptr [mf]
    fsqrt
    stpq r_v1
    ldq s_v2
    fdiv qword ptr [mf]
    fsqrt
    stpq r_v2
    ldq s_i1
    fdiv qword ptr [mf]
    fsqrt
    stpq r_i1
    ldq s_i2
    fdiv qword ptr [mf]
    fsqrt
    stpq r_i2
    ldq s_pin
    fdiv qword ptr [mf]
    stpq r_pin
    ldq s_pout
    fdiv qword ptr [mf]
    stpq r_pout
    ldq pv+0                    # BPK = lmax/(NP*ae)*1e3  [mT]
    fmul qword ptr [ae]
    stpq tmpd
    ldq lmax
    fdiv qword ptr [tmpd]
    fmul qword ptr [c1e3]
    stpq r_bpk
    ldq pv+32                   # SAT = BPK > BSAT*0.999
    fmul qword ptr [c0999]
    fcomp qword ptr [r_bpk]
    fnstsw ax
    sahf
    jae nosat
    mov byte ptr [sat], 1
nosat:
    fldz                        # EFF = 100*POUT/PIN if PIN > 0
    stpq r_eff
    ldq r_pin
    fcomp qword ptr [c0]
    fnstsw ax
    sahf
    jbe noeff
    ldq c100
    fmul qword ptr [r_pout]
    fdiv qword ptr [r_pin]
    stpq r_eff
noeff:
    mov si, offset m_v1
    call pstr
    ldq r_v1
    mov cx, 2
    call pfix
    mov si, offset m_v2
    call pstr
    ldq r_v2
    mov cx, 2
    call pfix
    mov si, offset m_i1
    call pstr
    ldq r_i1
    mov cx, 3
    call pfix
    mov si, offset m_i2
    call pstr
    ldq r_i2
    mov cx, 3
    call pfix
    mov si, offset m_p1
    call pstr
    ldq r_pin
    mov cx, 2
    call pfix
    mov si, offset m_p2
    call pstr
    ldq r_pout
    mov cx, 2
    call pfix
    mov si, offset m_eff
    call pstr
    ldq r_eff
    mov cx, 1
    call pfix
    mov si, offset m_bpk
    call pstr
    ldq r_bpk
    mov cx, 0
    call pfix
    mov si, offset m_sat
    call pstr
    mov si, offset m_no
    cmp byte ptr [sat], 0
    je satp
    mov si, offset m_yes
satp:
    call pstr
    mov si, offset m_steps      # second line: steps, time step, clamp
    call pstr
    mov ax, [nsteps]
    mov dx, [nsteps + 2]
    call pdec32
    mov si, offset m_dt
    call pstr
    ldq dt
    fmul qword ptr [c1e6]
    mov cx, 2
    call pfix
    mov si, offset m_clamp
    call pstr
    mov si, offset m_no
    cmp byte ptr [clamped], 0
    je clp
    mov si, offset m_yes
clp:
    call pstr
    mov si, offset m_crlf
    call pstr
    call telemetry
    cmp byte ptr [f_csv], 0
    je nocsv
    call write_csv
nocsv:
    cmp byte ptr [f_hpgl], 0
    je nohpgl
    call write_hpgl
nohpgl:
    mov ax, 0x4C00
    int 0x21

usage:
    mov dx, offset m_usage
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21

# ---- INT 48h telemetry: publish 16 words for other programs to poll ----
telemetry:
    xor ax, ax
    mov es, ax
    mov ax, es:[0x48 * 4]
    or ax, es:[0x48 * 4 + 2]
    push ds
    pop es
    test ax, ax
    jz tl_ret                   # nobody provides INT 48h
    mov di, offset tele
    mov ax, 0x5254              # 'TR'
    stosw
    xor ax, ax
    cmp byte ptr [sat], 0
    je tl_a
    or ax, 2
tl_a:
    cmp byte ptr [clamped], 0
    je tl_b
    or ax, 4
tl_b:
    or ax, 1                    # valid
    stosw
    ldq r_v1
    fmul qword ptr [c10]
    call tstore
    ldq r_v2
    fmul qword ptr [c10]
    call tstore
    ldq r_i1
    fmul qword ptr [c1000]
    call tstore
    ldq r_i2
    fmul qword ptr [c1000]
    call tstore
    ldq r_bpk
    call tstore
    ldq r_pin
    fmul qword ptr [c10]
    call tstore
    ldq r_pout
    fmul qword ptr [c10]
    call tstore
    ldq r_eff
    fmul qword ptr [c10]
    call tstore
    mov ax, [par + 0]
    stosw
    mov ax, [par + 4]
    stosw
    ldq dt
    fmul qword ptr [c1e8]
    call tstore
    mov ax, [par + 56]
    stosw
    mov ax, [nsteps]
    stosw
    mov ax, [nsteps + 2]
    stosw
    mov dx, offset tele
    mov ax, 0x0100              # AH=1 publish DS:DX
    int 0x48
tl_ret:
    ret
tstore:                         # ST0 -> saturating unsigned word at ES:DI (pops)
    fistp dword ptr [tmp32]
    mov ax, [tmp32]
    cmp word ptr [tmp32 + 2], 0
    je ts_ok
    mov ax, 0xFFFF
    test word ptr [tmp32 + 2], 0x8000
    jz ts_ok
    xor ax, ax
ts_ok:
    stosw
    ret

# ---- CSV / HPGL output of the recorded last cycle ----
write_csv:
    mov di, OUTBUF
    mov si, offset m_csvhdr
    call cpystr
    xor bx, bx
csv_lp:
    cmp bx, [nsamp]
    jae csv_done
    push bx
    mov ax, bx
    xor dx, dx
    call fmt_u32
    mov cx, 4
    mov si, bx
    shl si, 4
    add si, SAMPLES
csv_f:
    mov al, ','
    stosb
    push cx
    mov ax, [si]
    mov dx, [si + 2]
    call fmt_s32
    pop cx
    add si, 4
    loop csv_f
    mov al, 13
    stosb
    mov al, 10
    stosb
    pop bx
    inc bx
    jmp csv_lp
csv_done:
    mov [outlen], di
    sub word ptr [outlen], OUTBUF
    mov dx, offset s_csvname
    xor cx, cx
    mov ah, 0x3C
    int 0x21
    jc csv_err
    mov bx, ax
    mov dx, OUTBUF
    mov cx, [outlen]
    mov ah, 0x40
    int 0x21
    mov ah, 0x3E
    int 0x21
    ret
csv_err:
    mov dx, offset m_csverr
    mov ah, 9
    int 0x21
    ret

write_hpgl:
    mov ax, [nsamp]
    dec ax
    mov [tmp32], ax
    fild word ptr [tmp32]
    stpq n1d
    mov di, OUTBUF
    mov si, offset m_hpgl0
    call cpystr
    mov word ptr [pen], 0
hp_series:
    mov si, offset m_sp
    call cpystr
    mov ax, [pen]
    add al, '1'
    stosb
    mov al, ';'
    stosb
    xor cx, cx                  # find max |value| of this series for the scale
    mov word ptr [vmax], 1
    xor bx, bx
hp_max:
    cmp bx, [nsamp]
    jae hp_go
    mov si, bx
    shl si, 4
    add si, SAMPLES
    mov ax, [pen]
    shl ax, 3
    add si, ax
    mov ax, [si]                # low word of the dword is enough for |v| < 32768
    test ax, ax
    jns hp_pos
    neg ax
hp_pos:
    cmp ax, [vmax]
    jbe hp_nm
    mov [vmax], ax
hp_nm:
    inc bx
    jmp hp_max
hp_go:
    mov ax, [vmax]
    mov [tmp32], ax
    fild word ptr [tmp32]
    stpq vmaxd
    xor bx, bx
hp_pt:
    cmp bx, [nsamp]
    jae hp_next
    mov ax, 'U' * 256 + 'P'
    test bx, bx
    jz hp_pu
    mov ax, 'D' * 256 + 'P'
hp_pu:
    stosw
    mov [tmp32], bx             # x = i*10000/(n-1)
    fild word ptr [tmp32]
    fmul qword ptr [c10000]
    fdiv qword ptr [n1d]
    fistp dword ptr [tmp32]
    mov ax, [tmp32]
    xor dx, dx
    call fmt_u32
    mov al, ','
    stosb
    mov si, bx                  # y = 3000 + v*2850/vmax
    shl si, 4
    add si, SAMPLES
    mov ax, [pen]
    shl ax, 3
    add si, ax
    fild word ptr [si]
    fmul qword ptr [c2850]
    fdiv qword ptr [vmaxd]
    fadd qword ptr [c3000]
    fistp dword ptr [tmp32]
    mov ax, [tmp32]
    xor dx, dx
    call fmt_u32
    mov al, ';'
    stosb
    inc bx
    jmp hp_pt
hp_next:
    inc word ptr [pen]
    cmp word ptr [pen], 2
    jb hp_series
    mov si, offset m_hpgl1
    call cpystr
    sub di, OUTBUF
    mov cx, di
    mov bx, 4                   # PRN
    mov dx, OUTBUF
    mov ah, 0x40
    int 0x21
    ret

# ---- helpers ----
skipsp:
    cmp byte ptr [si], ' '
    jne ssr
    inc si
    jmp skipsp
ssr:
    ret
mul10:                          # DX:AX *= 10
    push bx
    push si
    push dx
    mov bx, 10
    mul bx
    mov si, dx
    mov cx, ax
    pop ax
    mul bx
    add ax, si
    mov dx, ax
    mov ax, cx
    pop si
    pop bx
    ret
pstr:                           # SI = asciz -> console
    lodsb
    test al, al
    jz ps_r
    mov dl, al
    mov ah, 2
    int 0x21
    jmp pstr
ps_r:
    ret
cpystr:                         # SI asciz -> ES:DI
    lodsb
    test al, al
    jz cs_r
    stosb
    jmp cpystr
cs_r:
    ret
pdec32:                         # DX:AX -> console
    push di
    mov di, OUTBUF + 0x3000
    push di
    call fmt_u32
    mov byte ptr [di], 0
    pop si
    call pstr
    pop di
    ret
fmt_u32:                        # DX:AX -> decimal digits at ES:DI (advances DI)
    push bx
    push cx
    push si
    mov bx, 10
    xor cx, cx
fu1:
    mov si, ax                  # divide DX:AX by 10 in two steps
    mov ax, dx
    xor dx, dx
    div bx
    xchg ax, si
    div bx
    push dx
    inc cx
    mov dx, si
    mov si, ax
    or si, dx
    jnz fu1
fu2:
    pop ax
    add al, '0'
    stosb
    loop fu2
    pop si
    pop cx
    pop bx
    ret
fmt_s32:                        # signed DX:AX
    test dx, 0x8000
    jz fu_pos
    push ax
    mov al, '-'
    stosb
    pop ax
    neg dx
    neg ax
    sbb dx, 0
fu_pos:
    jmp fmt_u32
pfix:                           # ST0 (>= 0), CX decimals (0-3) -> "123.45"
    push cx
    mov bx, 1
    mov si, cx
pf1:
    test si, si
    jz pf2
    mov ax, bx
    mov dx, 10
    mul dx
    mov bx, ax
    dec si
    jmp pf1
pf2:
    mov [pfp], bx               # 10^decimals
    mov [tmp32], bx
    fild word ptr [tmp32]
    fmulp st(1), st
    fistp dword ptr [tmp32]     # value * 10^d, rounded
    mov ax, [tmp32]
    mov dx, [tmp32 + 2]
    call div32                  # DX:AX = integer part, CX = fraction
    mov [frac], cx
    call pdec32
    pop cx
    test cx, cx
    jz pf_end
    push cx
    mov dl, '.'
    mov ah, 2
    int 0x21
    pop cx
    mov bx, [pfp]
pfd:                            # the fraction digit by digit, zero padded to CX digits
    push cx
    mov ax, bx
    xor dx, dx
    mov di, 10
    div di
    mov bx, ax                  # p = p/10
    mov ax, [frac]
    xor dx, dx
    div bx                      # AX = digit, DX = rest
    mov [frac], dx
    add al, '0'
    mov dl, al
    push bx
    mov ah, 2
    int 0x21
    pop bx
    pop cx
    loop pfd
pf_end:
    ret
div32:                          # DX:AX / BX -> DX:AX, remainder CX
    push si
    mov si, ax
    mov ax, dx
    xor dx, dx
    div bx
    xchg ax, si
    div bx
    mov cx, dx
    mov dx, si
    pop si
    ret

# ================================================================ data
par:    .long 900, 90, 2000, 20000, 1500, 230, 50, 5300, 1000, 200, 5000, 50, 50000, 90, 4, 200
c_mu0:  .double 1.2566370614359173e-06
c1e6m:  .double 1e-6
c1e3m:  .double 1e-3
c1e3:   .double 1e3
c1e6:   .double 1e6
c1e8:   .double 1e8
c1e9:   .double 1e9
c2:     .double 2.0
c05:    .double 0.5
c10:    .double 10.0
c100:   .double 100.0
c1000:  .double 1000.0
c10000: .double 10000.0
c2850:  .double 2850.0
c3000:  .double 3000.0
c4000:  .double 4000.0
c0:     .double 0.0
c0999:  .double 0.999
c2pi:   .double 6.283185307179586
csqrt2: .double 1.4142135623730951
cdeg:   .double 0.017453292519943295
m_v1:   .asciz "V1="
m_v2:   .asciz "V V2="
m_i1:   .asciz "V I1="
m_i2:   .asciz "A I2="
m_p1:   .asciz "A P1="
m_p2:   .asciz "W P2="
m_eff:  .asciz "W EFF="
m_bpk:  .asciz "% BPK="
m_sat:  .asciz "mT SAT="
m_yes:  .asciz "YES"
m_no:   .asciz "NO"
m_steps: .asciz "\r\nSTEPS="
m_dt:   .asciz " DT="
m_clamp: .asciz "us CLAMP="
m_crlf: .asciz "\r\n"
m_usage: .ascii "TRAFO [NP NS MUR LLK BSAT VIN FREQ RLOAD AE LE R1 R2 RC PHASE CYC SPC] [C] [H]\r\n"
        .ascii "  turns, -, uH, mT, V rms, Hz, mOhm, mm2, mm, mOhm, mOhm, Ohm, deg  (C = TRAFO.CSV, H = HPGL to PRN)\r\n$"
m_csvhdr: .asciz "n,vs_dV,i1_mA,v2_dV,i2_mA\r\n"
m_csverr: .ascii "TRAFO: cannot write TRAFO.CSV\r\n$"
m_hpgl0: .asciz "IN;"
m_hpgl1: .asciz "PU;SP0;"
m_sp:   .asciz "SP"
s_csvname: .asciz "TRAFO.CSV"
f_csv:  .byte 0
f_hpgl: .byte 0
sat:    .byte 0
clamped: .byte 0
.balign 8
pv:     .space 128
a: .double 0
ae: .double 0
lepath: .double 0
Lm0: .double 0
Ls: .double 0
lams: .double 0
L1: .double 0
R1f: .double 0
RL: .double 0
Rl2: .double 0
aRL: .double 0
T: .double 0
dt0: .double 0
x1: .double 0
x2: .double 0
xm: .double 0
dt: .double 0
wdt: .double 0
Vp: .double 0
inv_dt: .double 0
kk1: .double 0
dn1: .double 0
B1: .double 0
kk2: .double 0
dn2: .double 0
B2: .double 0
q1: .double 0
q2: .double 0
rcl0: .double 0
rcls: .double 0
c3: .double 0
theta: .double 0
vs: .double 0
A1: .double 0
A2: .double 0
num: .double 0
e: .double 0
lam1: .double 0
s: .double 0
i1: .double 0
i2: .double 0
lam: .double 0
i1pk: .double 0
v2: .double 0
i2a: .double 0
s_v1: .double 0
s_v2: .double 0
s_i1: .double 0
s_i2: .double 0
s_pin: .double 0
s_pout: .double 0
lmax: .double 0
mf: .double 0
r_v1: .double 0
r_v2: .double 0
r_i1: .double 0
r_i2: .double 0
r_pin: .double 0
r_pout: .double 0
r_bpk: .double 0
r_eff: .double 0
tmpd: .double 0
dtmin: .double 0
n1d: .double 0
vmaxd: .double 0
nsteps: .long 0
last:   .long 0
rem:    .long 0
nmeas:  .long 0
tmp32:  .long 0
kdec:   .word 0
kcnt:   .word 0
nsamp:  .word 0
outlen: .word 0
pen:    .word 0
vmax:   .word 0
pfp:    .word 0
frac:   .word 0
tele:   .space 32
