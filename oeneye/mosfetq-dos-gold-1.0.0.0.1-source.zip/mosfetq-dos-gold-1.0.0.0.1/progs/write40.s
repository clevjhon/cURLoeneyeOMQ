# WRITE40.COM: INT 21h AH=40h to handle 1 (console) works, handle 5 fails with 6.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov bx, 1
    mov dx, offset s
    mov cx, 6
    mov ah, 0x40
    int 0x21
    jc bad
    cmp ax, 6
    jne bad
    mov bx, 5
    mov ah, 0x40
    int 0x21
    jnc bad
    cmp ax, 6
    jne bad
    int 0x20
bad:
    mov ax, 0x4C01
    int 0x21
s: .ascii "write\n"
