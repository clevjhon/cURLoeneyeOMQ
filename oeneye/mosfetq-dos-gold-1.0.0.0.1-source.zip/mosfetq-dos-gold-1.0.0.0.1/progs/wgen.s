# WGEN.COM NAME N M [X]: creates NAME and writes N bytes M times (byte i of each block = (7*i+3) mod 256),
# then closes it - unless X is non-zero (then the program just ends: the OS must finish the file).
# Prints "OK", or "ERR <DOS error code>".
.intel_syntax noprefix
.code16
.global _start
.equ NAME, 0x0F00
.equ BUF,  0x2000
.text
_start:
    mov si, 0x81
    call skipsp
    mov di, NAME
cpn:
    mov al, [si]
    cmp al, ' '
    je cpd
    cmp al, 13
    je cpd
    mov [di], al
    inc si
    inc di
    jmp cpn
cpd:
    mov byte ptr [di], 0
    call getnum
    mov [n], ax
    call getnum
    mov [m], ax
    call getnum
    mov [noclose], ax
    mov cx, [n]                 # the pattern
    mov di, BUF
    mov al, 3
fill:
    test cx, cx
    jz filled
    mov [di], al
    add al, 7
    inc di
    dec cx
    jmp fill
filled:
    mov dx, NAME
    xor cx, cx
    mov ah, 0x3C                # create
    int 0x21
    jc err
    mov [h], ax
wl:
    cmp word ptr [m], 0
    je wdone
    mov bx, [h]
    mov cx, [n]
    mov dx, BUF
    mov ah, 0x40                # write
    int 0x21
    jc err
    cmp ax, [n]
    jne err
    dec word ptr [m]
    jmp wl
wdone:
    cmp word ptr [noclose], 0
    jne fin
    mov bx, [h]
    mov ah, 0x3E                # close
    int 0x21
    jc err
fin:
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
err:
    push ax
    mov dx, offset s_err
    mov ah, 9
    int 0x21
    pop ax
    call printdec
    mov dl, 13
    mov ah, 2
    int 0x21
    mov dl, 10
    int 0x21
    mov ax, 0x4C01
    int 0x21
skipsp:
    cmp byte ptr [si], ' '
    jne ss_r
    inc si
    jmp skipsp
ss_r:
    ret
getnum:                         # decimal at SI -> AX (0 if there is none); skips leading spaces
    call skipsp
    xor ax, ax
    mov bx, 10
gn:
    mov cl, [si]
    sub cl, '0'
    cmp cl, 9
    ja gn_done
    mul bx
    xor ch, ch
    add ax, cx
    inc si
    jmp gn
gn_done:
    ret
printdec:
    xor cx, cx
    mov bx, 10
pd1:
    xor dx, dx
    div bx
    push dx
    inc cx
    test ax, ax
    jnz pd1
pd2:
    pop dx
    add dl, '0'
    mov ah, 2
    int 0x21
    loop pd2
    ret
n:       .word 0
m:       .word 0
noclose: .word 0
h:       .word 0
ok:      .ascii "OK\r\n$"
s_err:   .ascii "ERR $"
