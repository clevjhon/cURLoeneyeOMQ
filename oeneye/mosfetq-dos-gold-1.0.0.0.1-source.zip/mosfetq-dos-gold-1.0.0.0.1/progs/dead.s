# DEAD.COM: waits for a message nobody will send (deadlock).
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov si, offset msg
    mov bx, 0xFFFF
    mov ah, 2
    int 0x60
    int 0x20
msg: .space 16
