# IPCERR.COM: error codes of the message calls.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov si, offset msg
    mov bx, 9                   # no task 9
    mov ah, 1
    int 0x60
    cmp ax, 1
    jne bad
    mov ah, 3                   # GETPID
    int 0x60
    mov bx, ax                  # send to myself
    mov si, offset msg
    mov ah, 1
    int 0x60
    cmp ax, 3
    jne bad
    mov si, offset msg
    mov bx, 9                   # receive from a task that does not exist
    mov ah, 2
    int 0x60
    cmp ax, 1
    jne bad
    mov ah, 0x77                # unknown call
    int 0x60
    cmp ax, 0xFFFF
    jne bad
    mov ah, 4                   # YIELD
    int 0x60
    cmp ax, 0
    jne bad
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
bad:
    mov dx, offset no
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
msg: .space 16
ok:  .ascii "IPCERR OK\r\n$"
no:  .ascii "IPCERR FAILED\r\n$"
