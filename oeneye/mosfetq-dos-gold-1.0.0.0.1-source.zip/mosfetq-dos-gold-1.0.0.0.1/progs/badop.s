# BADOP.COM: an opcode oeneye does not implement (F1).
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    nop
    .byte 0xF1
    int 0x20
