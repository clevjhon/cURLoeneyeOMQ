# DIVZERO.COM: divide error.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    xor bx, bx
    mov ax, 5
    div bx
    int 0x20
