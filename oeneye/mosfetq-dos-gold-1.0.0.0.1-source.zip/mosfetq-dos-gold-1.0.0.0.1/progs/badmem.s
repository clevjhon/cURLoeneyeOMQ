# BADMEM.COM: touches memory outside its 64 KB window.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov ax, 0x2000
    mov ds, ax
    mov al, [0]
    int 0x20
