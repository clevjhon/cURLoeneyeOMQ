# PAINT.COM [file.bmp]  -  oeneyePaint: a pixel editor / skin designer (VGA 320x200, 16 colours)
#
# 64 x 64 pixel canvas shown at 3x zoom. Saved as a standard 8-bit BMP (image/bmp), 5174 bytes.
#   arrows  move the cursor         SPACE  paint the cell        P  pen down/up (paint while moving)
#   0-9, A-F  choose a colour       [ ]  previous / next colour  X  clear the canvas
#   +  -   pixel width (zoom 1x-3x)       F1/F2 F3/F4 F5/F6   red / green / blue of the chosen colour  -/+
#   S  save    L  load  (file name from the command line, default SKIN.BMP)     Q  quit
# The 16-colour palette is edited on the VGA DAC and stored in the BMP palette: a skin keeps its colours.
# A bar at the bottom right flashes green after a successful save/load and red after a failure.
.intel_syntax noprefix
.code16
.global _start
.equ CANVAS, 0x2000             # 64*64 bytes, one colour (0-15) per cell
.equ WORK,   0x3000             # scratch: palette block for saving / the file for loading (5200 bytes)
.equ FNAME,  0x0F00
.equ OX, 6                      # canvas origin on screen
.equ OY, 4
.text
_start:
    mov si, 0x81                # file name from the command line (first word), else SKIN.BMP
    call skipsp
    cmp byte ptr [si], 13
    je defname
    mov di, FNAME
cpn:
    mov al, [si]
    cmp al, ' '
    je cpd
    cmp al, 13
    je cpd
    call upc
    mov [di], al
    inc si
    inc di
    jmp cpn
cpd:
    mov byte ptr [di], 0
    jmp havename
defname:
    mov si, offset s_skin
    mov di, FNAME
dn:
    lodsb
    stosb
    test al, al
    jnz dn
havename:
    mov di, CANVAS              # clean canvas (the memory holds whatever ran here before)
    mov cx, 4096
    xor al, al
    rep stosb
    mov word ptr [cx_], 0
    mov word ptr [cy_], 0
    mov byte ptr [color], 15
    mov byte ptr [pen], 0
    mov byte ptr [zoom], 3
    mov si, offset dac0         # default VGA colours, editable
    mov di, offset dac
    mov cx, 48
    rep movsb
    mov ax, 0x0013              # 320 x 200, 256 colours
    int 0x10
    call set_all_dac
    call redraw_all
main:
    xor ah, ah
    int 0x16
    test al, al
    jz extended
    cmp al, 'q'
    je quit
    cmp al, 'Q'
    je quit
    cmp al, ' '
    je paint_key
    cmp al, 'p'
    je pen_key
    cmp al, 'P'
    je pen_key
    cmp al, 'x'
    je clear_key
    cmp al, 'X'
    je clear_key
    cmp al, 's'
    je save_key
    cmp al, 'S'
    je save_key
    cmp al, 'l'
    je load_key
    cmp al, 'L'
    je load_key
    cmp al, '+'
    je zoom_up
    cmp al, '='
    je zoom_up
    cmp al, '-'
    je zoom_dn
    cmp al, '['
    je prev_col
    cmp al, ']'
    je next_col
    cmp al, '0'
    jb main
    cmp al, '9'
    jbe digit
    or al, 0x20                 # A-F / a-f
    cmp al, 'a'
    jb main
    cmp al, 'f'
    ja main
    sub al, 'a' - 10
    jmp setcol
digit:
    sub al, '0'
setcol:
    mov [color], al
    call draw_palette
    jmp main
zoom_up:
    cmp byte ptr [zoom], 3
    jae main
    inc byte ptr [zoom]
    call redraw_all
    jmp main
zoom_dn:
    cmp byte ptr [zoom], 1
    jbe main
    dec byte ptr [zoom]
    call redraw_all
    jmp main
prev_col:
    mov al, [color]
    dec al
    and al, 15
    jmp setcol
next_col:
    mov al, [color]
    inc al
    and al, 15
    jmp setcol
paint_key:
    call paint_here
    jmp main
pen_key:
    xor byte ptr [pen], 1
    cmp byte ptr [pen], 0
    je main
    call paint_here
    jmp main
clear_key:
    mov di, CANVAS
    mov cx, 4096
    xor al, al
    rep stosb
    call redraw_all
    jmp main
save_key:
    call save_file
    jmp main
load_key:
    call load_file
    jmp main
extended:                       # AH = scan code
    cmp ah, 0x3B
    jb ext_arrows
    cmp ah, 0x40
    ja ext_arrows
    mov al, ah                  # F1..F6: component (R,G,B) and direction
    sub al, 0x3B
    call adjust_dac
    jmp main
ext_arrows:
    cmp ah, 0x48
    je up
    cmp ah, 0x50
    je down
    cmp ah, 0x4B
    je left
    cmp ah, 0x4D
    je right
    jmp main
up:
    mov dx, [cy_]
    test dx, dx
    jz main
    call move_begin
    dec word ptr [cy_]
    jmp move_end
down:
    cmp word ptr [cy_], 63
    jae main
    call move_begin
    inc word ptr [cy_]
    jmp move_end
left:
    cmp word ptr [cx_], 0
    je main
    call move_begin
    dec word ptr [cx_]
    jmp move_end
right:
    cmp word ptr [cx_], 63
    jae main
    call move_begin
    inc word ptr [cx_]
move_end:
    cmp byte ptr [pen], 0
    je mv_draw
    call set_cell               # pen down: the new cell takes the colour
mv_draw:
    mov ax, [cx_]
    mov bx, [cy_]
    call draw_cell
    jmp main
quit:
    mov ax, 0x0003              # back to text mode
    int 0x10
    mov ax, 0x4C00
    int 0x21

move_begin:                     # redraw the cell the cursor leaves without the cursor mark
    mov word ptr [nocur], 1
    mov ax, [cx_]
    mov bx, [cy_]
    call draw_cell
    mov word ptr [nocur], 0
    ret
paint_here:
    call set_cell
    mov ax, [cx_]
    mov bx, [cy_]
    call draw_cell
    ret
set_cell:                       # canvas[cy][cx] = colour
    mov bx, [cy_]
    shl bx, 6
    add bx, [cx_]
    mov al, [color]
    mov [bx + CANVAS], al
    ret

# ---- drawing ----
redraw_all:
    xor ax, ax
    mov es, ax
    mov cx, 0xA000
    mov es, cx
    xor di, di
    mov cx, 32000
    xor ax, ax
    rep stosw                   # clear the screen
    xor bx, bx                  # every cell
ra_y:
    xor ax, ax
ra_x:
    push ax
    push bx
    call draw_cell
    pop bx
    pop ax
    inc ax
    cmp ax, 64
    jb ra_x
    inc bx
    cmp bx, 64
    jb ra_y
    call draw_palette
    push ds
    pop es
    ret

draw_cell:                      # AX = x, BX = y (0-63): [zoom] x [zoom] pixels; the cursor cell is shown inverted
    push ax
    push bx
    push cx
    push dx
    push si
    mov si, bx
    shl si, 6
    add si, ax
    mov dl, [si + CANVAS]
    cmp word ptr [nocur], 0
    jne dc_nocur
    cmp ax, [cx_]
    jne dc_nocur
    cmp bx, [cy_]
    jne dc_nocur
    xor dl, 15
dc_nocur:
    mov [dc_col], dl
    mov cl, [zoom]
    xor ch, ch
    mul cx                      # AX = x * zoom  (DX is clobbered: the colour is in dc_col)
    add ax, OX
    mov [dc_x], ax
    mov ax, bx
    mul cx
    add ax, OY
    mov bx, ax
    mov ax, [dc_x]
    mov si, cx                  # height = zoom, width (CX) = zoom
    mov dl, [dc_col]
    call fill_rect
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret

fill_rect:                      # AX = x, BX = y, CX = width, SI = height, DL = colour (uses ES = A000)
    push ax
    push bx
    push cx
    push di
    push si
    push bp
    mov bp, 0xA000
    mov es, bp
    mov bp, cx                  # width
    mov di, bx
    shl di, 6                   # y * 320 = y*256 + y*64
    shl bx, 8
    add di, bx
    add di, ax
fr_row:
    mov cx, bp
    mov al, dl
    push di
    rep stosb
    pop di
    add di, 320
    dec si
    jnz fr_row
    pop bp
    pop si
    pop di
    pop cx
    pop bx
    pop ax
    push ds                     # ES back to the data segment (file and canvas code use it)
    pop es
    ret

draw_palette:                   # 16 swatches in two columns; the chosen colour has a white frame
    mov word ptr [pi_], 0
dp_lp:
    mov ax, [pi_]
    and ax, 7
    mov dx, ax
    shl ax, 4
    mov cx, dx
    shl cx, 2
    add ax, cx
    shl dx, 1
    add ax, dx                  # row * 22
    add ax, 8
    mov [sy], ax
    mov ax, 214
    test word ptr [pi_], 8
    jz dp_c0
    add ax, 34
dp_c0:
    mov [sx], ax
    mov dl, 0                   # frame colour
    mov ax, [pi_]
    cmp al, [color]
    jne dp_fr
    mov dl, 15
dp_fr:
    mov ax, [sx]
    dec ax
    mov bx, [sy]
    dec bx
    mov cx, 20
    mov si, 20
    call fill_rect
    mov ax, [sx]
    mov bx, [sy]
    mov cx, 18
    mov si, 18
    mov dl, [pi_]               # the swatch: colour = its index
    call fill_rect
    inc word ptr [pi_]
    cmp word ptr [pi_], 16
    jb dp_lp
    ret

# ---- palette (VGA DAC, 6 bits per component) ----
set_all_dac:                    # program the 16 colours from dac[]
    mov ax, 0x1012
    xor bx, bx
    mov cx, 16
    mov dx, offset dac
    int 0x10
    ret

set_dac:                        # program the chosen colour
    xor bx, bx
    mov bl, [color]
    mov si, bx
    shl si, 1
    add si, bx
    add si, offset dac          # SI -> R,G,B
    mov dh, [si]
    mov ch, [si + 1]
    mov cl, [si + 2]
    mov ax, 0x1010
    int 0x10
    ret

adjust_dac:                     # AL = 0..5: (R,G,B) * 2 + (0 = less, 1 = more), step 4 of 63
    push ax
    xor ah, ah
    mov bx, ax
    shr bx, 1                   # component
    xor cx, cx
    mov cl, [color]
    mov si, cx
    shl si, 1
    add si, cx
    add si, bx
    add si, offset dac
    pop ax
    test al, 1
    jnz ad_more
    mov al, [si]
    sub al, 4
    jns ad_store
    xor al, al
    jmp ad_store
ad_more:
    mov al, [si]
    add al, 4
    cmp al, 63
    jbe ad_store
    mov al, 63
ad_store:
    mov [si], al
    call set_dac
    ret

# ---- files ----
flash:                          # AL = colour of the status bar
    mov dl, al
    mov ax, 214
    mov bx, 188
    mov cx, 70
    mov si, 6
    call fill_rect
    ret

save_file:
    mov dx, FNAME
    xor cx, cx
    mov ah, 0x3C
    int 0x21
    jc sf_err
    mov [fh], ax
    mov bx, ax
    mov dx, offset bmphdr       # 54-byte header
    mov cx, 54
    mov ah, 0x40
    int 0x21
    jc sf_err
    mov di, WORK                # 256-entry palette: 16 VGA colours, the rest black
    mov cx, 512
    xor ax, ax
    rep stosw
    mov si, offset dac          # 6-bit RGB -> 8-bit B,G,R,0
    mov di, WORK
    mov cx, 16
sv_pal:
    mov al, [si + 2]
    call to8
    stosb
    mov al, [si + 1]
    call to8
    stosb
    mov al, [si]
    call to8
    stosb
    xor al, al
    stosb
    add si, 3
    loop sv_pal
    mov bx, [fh]
    mov dx, WORK
    mov cx, 1024
    mov ah, 0x40
    int 0x21
    jc sf_err
    mov word ptr [row], 63      # BMP stores the bottom row first
sf_row:
    mov bx, [fh]
    mov dx, [row]
    shl dx, 6
    add dx, CANVAS
    mov cx, 64
    mov ah, 0x40
    int 0x21
    jc sf_err
    dec word ptr [row]
    jns sf_row
    mov bx, [fh]
    mov ah, 0x3E
    int 0x21
    jc sf_err
    mov al, 2                   # green
    call flash
    ret
sf_err:
    mov al, 4                   # red
    call flash
    ret

load_file:
    mov dx, FNAME
    mov ax, 0x3D00
    int 0x21
    jc lf_err
    mov [fh], ax
    mov bx, ax
    mov dx, WORK
    mov cx, 5200
    mov ah, 0x3F
    int 0x21
    jc lf_err
    cmp ax, 5174                # exactly one 64x64 8-bit BMP
    jne lf_err
    mov bx, [fh]
    mov ah, 0x3E
    int 0x21
    cmp word ptr [WORK], 0x4D42 # 'BM'
    jne lf_err
    cmp word ptr [WORK + 10], 1078
    jne lf_err
    cmp word ptr [WORK + 18], 64
    jne lf_err
    cmp word ptr [WORK + 22], 64
    jne lf_err
    cmp word ptr [WORK + 28], 8
    jne lf_err
    xor bx, bx                  # row r of the file = canvas row 63-r
lf_row:
    mov si, bx
    shl si, 6
    add si, WORK + 1078
    mov di, 63
    sub di, bx
    shl di, 6
    add di, CANVAS
    mov cx, 64
lf_px:
    lodsb
    and al, 15
    stosb
    loop lf_px
    inc bx
    cmp bx, 64
    jb lf_row
    mov si, WORK + 54           # the palette: B,G,R,0 (8 bits) -> R,G,B (6 bits)
    mov di, offset dac
    mov cx, 16
lf_pal:
    mov al, [si + 2]
    shr al, 2
    mov [di], al
    mov al, [si + 1]
    shr al, 2
    mov [di + 1], al
    mov al, [si]
    shr al, 2
    mov [di + 2], al
    add si, 4
    add di, 3
    loop lf_pal
    call set_all_dac
    call redraw_all
    mov al, 2
    call flash
    ret
lf_err:
    mov al, 4
    call flash
    ret

to8:                            # AL = 6-bit value -> 8-bit ((v<<2)|(v>>4))
    mov ah, al
    shl al, 2
    shr ah, 4
    or al, ah
    ret

skipsp:
    cmp byte ptr [si], ' '
    jne ss_r
    inc si
    jmp skipsp
ss_r:
    ret
upc:
    cmp al, 'a'
    jb up_r
    cmp al, 'z'
    ja up_r
    sub al, 32
up_r:
    ret

cx_:    .word 0
cy_:    .word 0
color:  .byte 15
pen:    .byte 0
nocur:  .word 0
fh:     .word 0
row:    .word 0
pi_:    .word 0
zoom:   .byte 3
dc_col: .byte 0
dc_x:   .word 0
dac:    .space 48
sx:     .word 0
sy:     .word 0
s_skin: .asciz "SKIN.BMP"
bmphdr:                         # BITMAPFILEHEADER + BITMAPINFOHEADER
    .ascii "BM"
    .long 5174
    .long 0
    .long 1078
    .long 40
    .long 64
    .long 64
    .word 1
    .word 8
    .long 0
    .long 4096
    .long 2835
    .long 2835
    .long 256
    .long 256
dac0:                           # the standard 16 VGA colours as R,G,B (6 bits)
    .byte 0,0,0,   0,0,42,   0,42,0,   0,42,42,   42,0,0,   42,0,42,   42,21,0,   42,42,42
    .byte 21,21,21, 21,21,63, 21,63,21, 21,63,63, 63,21,21, 63,21,63, 63,63,21, 63,63,63
