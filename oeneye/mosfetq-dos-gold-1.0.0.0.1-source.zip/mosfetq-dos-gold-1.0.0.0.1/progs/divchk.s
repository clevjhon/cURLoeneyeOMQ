# DIVCHK.COM <case>: one DIV/IDIV case per run (case = 1-9, A-D). Prints AX and DX, or oeneye stops it with 'divide error'.
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov al, [0x82]
    sub al, '0'
    cmp al, 9
    jbe have
    sub al, 7                   # 'A' -> 10
have:
    cmp al, 1
    je c1
    cmp al, 2
    je c2
    cmp al, 3
    je c3
    cmp al, 4
    je c4
    cmp al, 5
    je c5
    cmp al, 6
    je c6
    cmp al, 7
    je c7
    cmp al, 8
    je c8
    cmp al, 9
    je c9
    cmp al, 10
    je c10
    cmp al, 11
    je c11
    cmp al, 12
    je c12
    cmp al, 13
    je c13
    jmp done
c1:                             # DIV8 quotient 256: overflow
    mov ax, 0x0100
    mov bl, 1
    div bl
    jmp show
c2:                             # DIV8 quotient 255: ok
    mov ax, 0x00FF
    mov bl, 1
    div bl
    jmp show
c3:                             # DIV16 quotient 65536: overflow
    mov dx, 1
    xor ax, ax
    mov bx, 1
    div bx
    jmp show
c4:                             # DIV16 0xFFFFFFFF / 0xFFFF = 0x10001: overflow
    mov dx, 0xFFFF
    mov ax, 0xFFFF
    mov bx, 0xFFFF
    div bx
    jmp show
c5:                             # IDIV8 +128 / 1 = 128: overflow
    mov ax, 0x0080
    mov bl, 1
    idiv bl
    jmp show
c6:                             # IDIV8 -128 / 1 = -128: ok
    mov ax, 0xFF80
    mov bl, 1
    idiv bl
    jmp show
c7:                             # IDIV8 -128 / -1 = +128: overflow
    mov ax, 0xFF80
    mov bl, 0xFF
    idiv bl
    jmp show
c8:                             # IDIV8 -7 / 2 = -3 rem -1
    mov ax, 0xFFF9
    mov bl, 2
    idiv bl
    jmp show
c9:                             # IDIV16 -32768 / 1 = -32768: ok
    mov dx, 0xFFFF
    mov ax, 0x8000
    mov bx, 1
    idiv bx
    jmp show
c10:                            # IDIV16 -32768 / -1 = +32768: overflow
    mov dx, 0xFFFF
    mov ax, 0x8000
    mov bx, 0xFFFF
    idiv bx
    jmp show
c11:                            # IDIV16 32767 / -1 = -32767: ok
    xor dx, dx
    mov ax, 0x7FFF
    mov bx, 0xFFFF
    idiv bx
    jmp show
c12:                            # IDIV16 65536 / 1: overflow
    mov dx, 1
    xor ax, ax
    mov bx, 1
    idiv bx
    jmp show
c13:                            # IDIV16 by zero
    xor dx, dx
    mov ax, 5
    xor bx, bx
    idiv bx
show:
    push dx
    call hex16
    mov dl, ' '
    mov ah, 2
    int 0x21
    pop ax
    call hex16
    mov dl, 13
    mov ah, 2
    int 0x21
    mov dl, 10
    int 0x21
done:
    mov ax, 0x4C00
    int 0x21
hex16:                          # AX -> 4 hex digits
    mov cx, 4
hx:
    rol ax, 4
    push ax
    and al, 15
    add al, 48
    cmp al, 57
    jbe hd
    add al, 7
hd:
    mov dl, al
    mov ah, 2
    int 0x21
    pop ax
    loop hx
    ret
