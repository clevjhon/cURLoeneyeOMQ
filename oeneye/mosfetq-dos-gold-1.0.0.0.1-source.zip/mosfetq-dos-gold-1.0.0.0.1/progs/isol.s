# ISOL.COM <letter>: writes its letter into its own memory, idles, checks nobody else changed it (task windows are private).
.intel_syntax noprefix
.code16
.global _start
.text
_start:
    mov al, [0x82]
    mov [0x300], al             # a location every copy of this program uses
    mov cx, 400
idle:
    loop idle                   # lets the other tasks run (and write THEIR letter at 1000:0300)
    mov al, [0x82]
    cmp al, [0x300]
    jne bad
    mov dl, al
    mov ah, 2
    int 0x21
    mov dx, offset ok
    mov ah, 9
    int 0x21
    int 0x20
bad:
    mov dx, offset no
    mov ah, 9
    int 0x21
    mov ax, 0x4C01
    int 0x21
ok: .ascii " isolated\r\n$"
no: .ascii "SHARED MEMORY!\r\n$"
