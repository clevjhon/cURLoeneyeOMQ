# ================================================================ INT 20h / INT 21h for guests
do_int20:
    xor al, al
    call vm_exit
    ret

do_int21:
    mov al, [g_ax + 1]              # AH
    cmp al, 0x02
    je d21_02
    cmp al, 0x09
    je d21_09
    cmp al, 0x30
    je d21_30
    cmp al, 0x40
    je d21_40
    cmp al, 0x4C
    je d21_4c
    or word ptr [g_fl], 1           # anything else: CF=1, AX=1 (invalid function)
    mov word ptr [g_ax], 1
    ret
d21_02:
    mov al, [g_dx]
    call pc
    ret
d21_09:
    mov ax, [g_dx]
    mov [tmp16], ax
d09_lp:
    mov bx, [tmp16]
    mov dx, [g_ds]
    call rdb
    cmp al, '$'
    je h_ret
    call pc
    inc word ptr [tmp16]
    jmp d09_lp
d21_30:
    mov word ptr [g_ax], 3
    ret
d21_40:                             # write to handle 1 or 2 (console)
    mov ax, [g_bx]
    cmp ax, 1
    je d40_ok
    cmp ax, 2
    je d40_ok
    or word ptr [g_fl], 1
    mov word ptr [g_ax], 6          # invalid handle
    ret
d40_ok:
    mov ax, [g_dx]
    mov [tmp16], ax
    mov cx, [g_cx]
d40_lp:
    test cx, cx
    jz d40_done
    mov bx, [tmp16]
    mov dx, [g_ds]
    call rdb
    call pc
    inc word ptr [tmp16]
    dec cx
    jmp d40_lp
d40_done:
    mov ax, [g_cx]
    mov [g_ax], ax
    and word ptr [g_fl], 0xFFFE
    ret
d21_4c:
    mov al, [g_ax]
    call vm_exit
    ret

# ================================================================ INT 60h: MINIX-style messages
do_int60:
    mov al, [g_ax + 1]
    cmp al, 1
    je sys_send
    cmp al, 2
    je sys_recv
    cmp al, 3
    je sys_getpid
    cmp al, 4
    je sys_yield
    mov word ptr [g_ax], 0xFFFF     # unknown call
    ret

sys_getpid:
    mov ax, [g_pid]
    mov [g_ax], ax
    ret
sys_yield:
    mov word ptr [g_ax], 0
    mov byte ptr [vm_event], 1
    ret

vm_lookup:                          # BX = task number -> SI = its VCB. CF=1 if there is no such task
    test bx, bx
    jz vl_bad
    cmp bx, [nvm]
    ja vl_bad
    push bx
    dec bx
    shl bx, 1
    mov si, [bx + vptr]
    pop bx
    clc
    ret
vl_bad:
    stc
    ret

read_msg:                           # guest DS:SI (16 bytes) -> my VCB's V_MSG. A bad pointer stops the caller.
    push bx
    push cx
    push dx
    push si
    mov si, [cur_vcb]
    add si, V_MSG
    mov bx, [g_si]
    mov dx, [g_ds]
    mov cx, 8
rdm_lp:
    call rdw
    mov [si], ax
    add si, 2
    add bx, 2
    loop rdm_lp
    pop si
    pop dx
    pop cx
    pop bx
    ret

probe_buf:                          # make sure guest DS:SI .. +15 is writable memory
    push ax
    push bx
    push cx
    push dx
    mov bx, [g_si]
    mov dx, [g_ds]
    mov cx, 8
pb_lp:
    call rdw
    add bx, 2
    loop pb_lp
    pop dx
    pop cx
    pop bx
    pop ax
    ret

write_msg:                          # SI = sender VCB: its V_MSG -> guest DS:SI of the current task
    push ax
    push bx
    push cx
    push dx
    push si
    add si, V_MSG
    mov bx, [g_si]
    mov dx, [g_ds]
    mov cx, 8
wm_lp:
    mov ax, [si]
    call wrw
    add si, 2
    add bx, 2
    loop wm_lp
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret

# deliver_msg: SI = receiver VCB (blocked in RECEIVE), DI = sender VCB. Copies the sender's
# message into the receiver's buffer (in the receiver's window) and makes it runnable.
deliver_msg:
    push ax
    push bx
    push cx
    push dx
    push si
    push di
    mov ax, [g_host]
    push ax
    mov ax, [si + V_HOST]
    mov [g_host], ax
    push si
    mov dx, [si + V_MSGSEG]
    mov bx, [si + V_MSGOFF]
    call xlat                       # ES:BX = receiver's buffer
    mov si, di
    add si, V_MSG
    mov di, bx
    mov cx, 8
    rep movsw
    pop si
    mov word ptr [si + V_STATE], ST_READY
    mov word ptr [si + V_R], 0      # its RECEIVE returns AX = 0
    push cs
    pop es
    pop ax
    mov [g_host], ax
    pop di
    pop si
    pop dx
    pop cx
    pop bx
    pop ax
    ret

sys_send:                           # BX = destination task, DS:SI = message
    mov bx, [g_bx]
    call vm_lookup
    jc ss_nopid
    cmp si, [cur_vcb]
    je ss_self
    cmp word ptr [si + V_STATE], ST_DEAD
    je ss_dead
    push si
    call read_msg
    pop si
    mov di, [cur_vcb]
    mov ax, [g_pid]
    mov [di + V_MSG], ax            # word 0 of a message = sender
    cmp word ptr [si + V_STATE], ST_RECV
    jne ss_block
    mov ax, [si + V_FILT]
    cmp ax, 0xFFFF
    je ss_deliver
    cmp ax, [g_pid]
    jne ss_block
ss_deliver:
    call deliver_msg
    mov word ptr [g_ax], 0
    ret
ss_block:                           # rendezvous: wait until the receiver asks for it
    mov ax, [si + V_PID]
    mov [di + V_DEST], ax
    mov word ptr [di + V_STATE], ST_SEND
    mov word ptr [g_ax], 0
    mov byte ptr [vm_event], 1
    ret
ss_nopid:
    mov word ptr [g_ax], 1
    ret
ss_self:
    mov word ptr [g_ax], 3
    ret
ss_dead:
    mov word ptr [g_ax], 2
    ret

sys_recv:                           # BX = source task (FFFFh = any), DS:SI = buffer
    call probe_buf
    mov ax, [g_bx]
    mov [rv_filt], ax
    xor di, di
rv_scan:
    cmp di, [nvm]
    jae rv_none
    mov si, di
    shl si, 1
    mov si, [si + vptr]
    cmp word ptr [si + V_STATE], ST_SEND
    jne rv_next
    mov ax, [si + V_DEST]
    cmp ax, [g_pid]
    jne rv_next
    mov ax, [rv_filt]
    cmp ax, 0xFFFF
    je rv_take
    cmp ax, [si + V_PID]
    jne rv_next
rv_take:
    call write_msg
    mov word ptr [si + V_STATE], ST_READY
    mov word ptr [si + V_R], 0      # the sender's SEND returns AX = 0
    mov word ptr [g_ax], 0
    ret
rv_next:
    inc di
    jmp rv_scan
rv_none:
    mov bx, [rv_filt]
    cmp bx, 0xFFFF
    je rv_block
    call vm_lookup
    jc rv_nopid
    cmp word ptr [si + V_STATE], ST_DEAD
    je rv_dead
rv_block:
    mov si, [cur_vcb]
    mov ax, [rv_filt]
    mov [si + V_FILT], ax
    mov ax, [g_ds]
    mov [si + V_MSGSEG], ax
    mov ax, [g_si]
    mov [si + V_MSGOFF], ax
    mov word ptr [si + V_STATE], ST_RECV
    mov word ptr [g_ax], 0
    mov byte ptr [vm_event], 1
    ret
rv_nopid:
    mov word ptr [g_ax], 1
    ret
rv_dead:
    mov word ptr [g_ax], 2
    ret

# ================================================================ INT 48h for guests (telemetry block)
# The block lives in the DOS kernel; oeneye copies it between the guest's memory and its own buffer.
do_int48:
    mov al, [g_ax + 1]
    cmp al, 0
    je t48g_ver
    cmp al, 1
    je t48g_pub
    cmp al, 2
    je t48g_get
    cmp al, 3
    je t48g_clr
    or word ptr [g_fl], 1
    mov word ptr [g_ax], 1
    ret
t48g_ver:
    mov word ptr [g_ax], 0x0102
    mov word ptr [g_bx], 32
    and word ptr [g_fl], 0xFFFE
    ret
t48g_pub:                           # guest DS:DX -> tele_l -> DOS
    mov bx, [g_dx]
    mov dx, [g_ds]
    mov di, offset tele_l
    mov cx, 16
t48p_lp:
    call rdw
    mov [di], ax
    add di, 2
    add bx, 2
    loop t48p_lp
    mov dx, offset tele_l
    mov ax, 0x0100
    int 0x48
    jmp t48g_done
t48g_get:                           # DOS -> tele_l -> guest DS:DX
    mov dx, offset tele_l
    mov ax, 0x0200
    int 0x48
    jc t48g_done
    mov bx, [g_dx]
    mov dx, [g_ds]
    mov si, offset tele_l
    mov cx, 16
t48q_lp:
    mov ax, [si]
    call wrw
    add si, 2
    add bx, 2
    loop t48q_lp
    xor ax, ax
    clc
    jmp t48g_done
t48g_clr:
    mov ax, 0x0300
    int 0x48
t48g_done:                          # AX and CF from the DOS call -> guest
    mov [g_ax], ax
    jc t48g_err
    and word ptr [g_fl], 0xFFFE
    ret
t48g_err:
    or word ptr [g_fl], 1
    ret
