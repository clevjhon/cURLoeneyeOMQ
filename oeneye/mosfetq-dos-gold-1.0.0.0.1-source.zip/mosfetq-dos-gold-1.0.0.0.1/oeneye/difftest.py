#!/usr/bin/env python3
"""Run random programs natively and under OENEYE; report every difference. Usage: difftest.py [first_seed] [count]"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fuzz, imgtool
from emu import boot

def outputs(out, cmds):
    res, pos = [], 0
    for c in cmds:
        i = out.index(c + "\r\n", pos) + len(c) + 2; j = out.index("A:\\>", i); res.append(out[i:j]); pos = j
    return res

def run_diff(seeds, img_path="mosfetq-dos.img", ninsn=45, verbose=True):
    img = bytearray(open(img_path, "rb").read()); names = []
    for s in seeds:
        n = f"FUZ{s:03d}"; imgtool.add_file(img, n + ".COM", fuzz.assemble(fuzz.program(s, ninsn))); names.append(n.lower())
    img = bytes(img); t = time.time()
    nat = boot(img, "".join(f"{n}\r" for n in names), limit=10**9)
    t1 = time.time()
    emu = boot(img, "".join(f"oeneye {n}\r" for n in names), limit=10**10)
    t2 = time.time()
    a = outputs("".join(nat.out), names); b = outputs("".join(emu.out), [f"oeneye {n}" for n in names])
    bad = []
    for s, x, y in zip(seeds, a, b):
        if x != y or "[oeneye]" in y or x.count("\n") != 3: bad.append((s, x, y))
    if verbose: print(f"{len(seeds)} programs: native {t1 - t:.1f}s, under oeneye {t2 - t1:.1f}s, {emu.steps / 1e6:.1f}M host instructions; {len(bad)} differ")
    return bad, a, b

if __name__ == "__main__":
    first = int(sys.argv[1]) if len(sys.argv) > 1 else 1; count = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    bad, a, b = run_diff(range(first, first + count))
    for s, x, y in bad[:5]:
        print(f"--- seed {s} DIFFERS"); xs, ys = x.split("\r\n"), y.split("\r\n")
        for i, (p, q) in enumerate(zip(xs, ys)):
            if p != q: print(f"  dump {i}: native  {p}\n  dump {i}: oeneye  {q}"); break
        else: print("  native:", repr(x[:200]), "\n  oeneye:", repr(y[:200]))
    print("first program's output (native):"); print(a[0])
