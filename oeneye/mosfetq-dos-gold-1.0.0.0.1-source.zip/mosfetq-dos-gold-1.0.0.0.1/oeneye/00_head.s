# oeneye.exe - an 8086 emulator with a MINIX-style multitasking kernel, for MOSFETQ DOS.
#
# Each task ("guest") is a DOS .COM program running on its own virtual 8086 with a private
# 64 KB window. The scheduler time-slices the guests by instruction count (QUANTUM), so tasks
# are pre-empted without any timer interrupt or protected mode. Tasks talk to each other with
# MINIX-style rendezvous messages (INT 60h). Guests see exactly what a .COM program sees under
# MOSFETQ DOS: CS=DS=ES=SS=1000h, PSP at 1000:0000, code at 1000:0100.
#
#   OENEYE task1 task2 ...      start the named .COM programs as tasks 1, 2, ...  (NAME:ARGS gives a task arguments)
#   OENEYE                      no names: read the task list from OENEYE.RC (one "NAME args" per line)
#
# ALU work is done natively: the guest's operands and flags are loaded into the real CPU,
# the real instruction runs, and the resulting flags are merged back (exact by construction).
#
# Guest interface   INT 21h  02 putc, 09 print $-string, 30 version, 40 write (handles 1,2), 4C exit
#                   INT 20h  exit
#                   INT 60h  AH=1 SEND  BX=dest task,   DS:SI = 16-byte message
#                            AH=2 RECEIVE BX=source (FFFFh=any), DS:SI = buffer
#                            AH=3 GETPID -> AX      AH=4 YIELD
#                            result in AX: 0 ok, 1 no such task, 2 task ended, 3 send to self
#
# Not emulated (the task is stopped with a message): BCD adjust, AAM/AAD, I/O ports, INT 3, INTO,
# 186+ opcodes except shifts by immediate (C0/C1), 386 opcodes except near Jcc (0F 8x), guest interrupt vectors.

.intel_syntax noprefix
.code16
.global _start
.text

.equ MAXVM,    7
.equ VSZ,      80
.equ V_STATE,  0
.equ V_R,      2                # AX CX DX BX SP BP SI DI
.equ V_S,      18               # ES CS SS DS
.equ V_IP,     26
.equ V_FL,     28
.equ V_HOST,   30
.equ V_PID,    32
.equ V_FILT,   34
.equ V_MSGSEG, 36
.equ V_MSGOFF, 38
.equ V_DEST,   40
.equ V_EXIT,   42
.equ V_NAME,   44
.equ V_MSG,    56
.equ ST_FREE,  0
.equ ST_READY, 1
.equ ST_RECV,  2
.equ ST_SEND,  3
.equ ST_DEAD,  4
.equ QUANTUM,  100
.equ FLMASK,   0x08D5           # OF SF ZF AF PF CF

_start:
    jmp main

# ================================================================ startup
main:
    mov ax, es                      # DOS: ES = PSP
    mov bx, cs
    mov ds, bx
    mov es, bx
    mov [psp_seg], ax
    cld
    mov word ptr [next_vcb], offset vcbs
    call get_tail
    call load_guests
    cmp byte ptr [abort], 0
    jne m_exit
    cmp word ptr [nvm], 0
    je m_usage
    call scheduler
m_exit:
    mov al, [exit_code]
    mov ah, 0x4C
    int 0x21
m_usage:
    mov si, offset s_usage
    call ps
    mov byte ptr [exit_code], 1
    jmp m_exit

get_tail:                           # command tail from the PSP -> tail (asciz)
    push ds
    mov ax, [psp_seg]
    mov ds, ax
    mov si, 0x81
    mov di, offset tail
    xor cx, cx
    mov cl, [0x80]
    cmp cl, 120
    jbe gt_ok
    mov cl, 120
gt_ok:
    rep movsb
    xor al, al
    stosb
    pop ds
    ret

# load_guests: every word of the command line is a task name; without any, use OENEYE.RC
load_guests:
    mov si, offset tail
lg_skip:
    mov al, [si]
    cmp al, ' '
    jne lg_chk
    inc si
    jmp lg_skip
lg_chk:
    cmp al, 13
    je lg_end
    test al, al
    jz lg_end
    mov [tokp], si
    mov word ptr [argp], offset s_noargs
lg_scan:
    mov al, [si]
    test al, al
    jz lg_tokend
    cmp al, ' '
    je lg_tokend
    cmp al, 13
    je lg_tokend
    cmp al, ':'                     # NAME:ARGS - the arguments of a task (no spaces)
    jne lg_nc
    mov byte ptr [si], 0
    inc si
    mov [argp], si
    jmp lg_scan
lg_nc:
    inc si
    jmp lg_scan
lg_tokend:
    mov dl, al
    mov byte ptr [si], 0
    push dx
    push si
    mov si, [tokp]
    mov di, [argp]
    call add_guest
    pop si
    pop dx
    jc lg_ret
    test dl, dl
    jz lg_end
    inc si
    jmp lg_skip
lg_end:
    cmp word ptr [nvm], 0
    jne lg_ret
    call load_rc                    # autoexec-like: no names given, read OENEYE.RC
lg_ret:
    ret

load_rc:
    mov dx, offset s_rcname
    mov ax, 0x3D00
    int 0x21
    jc lr_ret
    mov bx, ax
    mov dx, offset rcbuf
    mov cx, 1000
    mov ah, 0x3F
    int 0x21
    jnc lr_read
    xor ax, ax
lr_read:
    mov [rclen], ax
    mov ah, 0x3E
    int 0x21
    mov bx, [rclen]
    mov byte ptr [bx + rcbuf], 0
    mov si, offset rcbuf
lr_line:
    mov al, [si]
    test al, al
    jz lr_ret
    cmp al, ' '
    je lr_ws
    cmp al, 13
    je lr_ws
    cmp al, 10
    je lr_ws
    cmp al, 9
    je lr_ws
    cmp al, ';'
    je lr_cmt
    mov [tokp], si                  # task name
lr_nm:
    mov al, [si]
    test al, al
    jz lr_nmend
    cmp al, ' '
    je lr_nmend
    cmp al, 13
    je lr_nmend
    cmp al, 10
    je lr_nmend
    inc si
    jmp lr_nm
lr_nmend:
    mov dl, al
    mov byte ptr [si], 0
    mov di, offset s_noargs
    cmp dl, ' '
    jne lr_go
    inc si
lr_sp:
    cmp byte ptr [si], ' '
    jne lr_ar
    inc si
    jmp lr_sp
lr_ar:
    mov di, si                      # arguments run to the end of the line
lr_ae:
    mov al, [si]
    test al, al
    jz lr_go2
    cmp al, 13
    je lr_go2
    cmp al, 10
    je lr_go2
    inc si
    jmp lr_ae
lr_go2:
    mov dl, al
    mov byte ptr [si], 0
lr_go:
    push dx
    push si
    mov si, [tokp]
    call add_guest
    pop si
    pop dx
    jc lr_ret
    test dl, dl
    jz lr_ret
    inc si
    jmp lr_line
lr_ws:
    inc si
    jmp lr_line
lr_cmt:
    mov al, [si]
    test al, al
    jz lr_ret
    cmp al, 10
    je lr_ws
    inc si
    jmp lr_cmt
lr_ret:
    ret

# add_guest: SI = task name (asciz), DI = arguments (asciz). CF=1 on failure (message printed).
add_guest:
    cmp word ptr [nvm], MAXVM
    jae ag_full
    mov [ag_args], di
    mov bx, [next_vcb]
    mov [ag_vcb], bx
    mov bx, [nvm]
    shl bx, 1
    mov ax, [bx + wintab]
    mov [ag_win], ax
    mov di, [ag_vcb]                # display name: upper case, without extension
    add di, V_NAME
    mov cx, 11
    push si
ag_nm:
    lodsb
    test al, al
    jz ag_nmend
    cmp al, '.'
    je ag_nmend
    call upc
    stosb
    loop ag_nm
ag_nmend:
    xor al, al
    stosb
    pop si
    mov di, offset fname            # file name: as typed, ".COM" added if it has no extension
    xor dx, dx
ag_fn:
    lodsb
    test al, al
    jz ag_fnend
    cmp al, '.'
    jne ag_fs
    mov dx, 1
ag_fs:
    call upc
    stosb
    jmp ag_fn
ag_fnend:
    test dx, dx
    jnz ag_term
    mov al, '.'
    stosb
    mov al, 'C'
    stosb
    mov al, 'O'
    stosb
    mov al, 'M'
    stosb
ag_term:
    xor al, al
    stosb
    mov ax, [ag_win]                # clear the guest's 64 KB window
    mov es, ax
    xor di, di
    xor ax, ax
    mov cx, 0x8000
    rep stosw
    push cs
    pop es
    mov dx, offset fname
    mov ax, 0x3D00
    int 0x21
    jc ag_nofile
    mov [ag_h], ax
    mov bx, ax
    push ds
    mov ax, [ag_win]
    mov ds, ax
    mov dx, 0x100                   # the file is read straight to window offset 100h
    mov cx, 0xF000
    mov ah, 0x3F
    int 0x21
    pop ds
    jc ag_rderr
    mov [ag_len], ax
    mov bx, [ag_h]
    mov ah, 0x3E
    int 0x21
    cmp word ptr [ag_len], 0xF000
    jae ag_big
    cmp word ptr [ag_len], 0
    je ag_empty
    mov ax, [ag_win]                # PSP, command tail and the "RET to PSP:0" word
    mov es, ax
    xor di, di
    mov ax, 0x20CD
    stosw
    mov ax, 0xA000
    stosw
    mov si, [ag_args]
    cmp byte ptr [si], 0
    je ag_noargs
    mov di, 0x81
    mov al, ' '
    stosb
    mov cx, 1
ag_cp:
    lodsb
    test al, al
    jz ag_cpd
    stosb
    inc cx
    cmp cx, 120
    jb ag_cp
ag_cpd:
    mov al, 13
    stosb
    mov di, 0x80
    mov al, cl
    stosb
    jmp ag_stk
ag_noargs:
    mov di, 0x81
    mov al, 13
    stosb
ag_stk:
    mov di, 0xFFFC
    xor ax, ax
    stosw
    push cs
    pop es
    mov di, [ag_vcb]                # initial register state = what MOSFETQ DOS gives a .COM program
    mov word ptr [di + V_STATE], ST_READY
    mov word ptr [di + V_R + 0], 0
    mov word ptr [di + V_R + 2], 0x00FF
    mov word ptr [di + V_R + 4], 0
    mov word ptr [di + V_R + 6], 0
    mov word ptr [di + V_R + 8], 0xFFFC
    mov word ptr [di + V_R + 10], 0
    mov word ptr [di + V_R + 12], 0
    mov word ptr [di + V_R + 14], 0
    mov word ptr [di + V_S + 0], 0x1000
    mov word ptr [di + V_S + 2], 0x1000
    mov word ptr [di + V_S + 4], 0x1000
    mov word ptr [di + V_S + 6], 0x1000
    mov word ptr [di + V_IP], 0x0100
    mov word ptr [di + V_FL], 0x0202
    mov ax, [ag_win]
    mov [di + V_HOST], ax
    mov ax, [nvm]
    inc ax
    mov [di + V_PID], ax
    mov word ptr [di + V_FILT], 0xFFFF
    mov word ptr [di + V_EXIT], 0
    mov bx, [nvm]
    shl bx, 1
    mov [bx + vptr], di
    inc word ptr [nvm]
    add word ptr [next_vcb], VSZ
    clc
    ret
ag_full:
    mov si, offset s_full
    jmp ag_msg
ag_nofile:
    mov si, offset s_nofile
    jmp ag_msgf
ag_rderr:
    mov si, offset s_rderr
    jmp ag_msgf
ag_big:
    mov si, offset s_big
    jmp ag_msgf
ag_empty:
    mov si, offset s_empty
ag_msgf:
    call ps
    mov si, offset fname
ag_msg:
    call ps
    call crlf
    mov byte ptr [abort], 1
    mov byte ptr [exit_code], 1
    stc
    ret

# ================================================================ scheduler
scheduler:
    mov word ptr [cur_idx], 0xFFFF
sc_loop:
    mov cx, [nvm]
    mov bx, [cur_idx]
sc_scan:
    inc bx
    cmp bx, [nvm]
    jb sc_ok
    xor bx, bx
sc_ok:
    mov si, bx
    shl si, 1
    mov si, [si + vptr]
    cmp word ptr [si + V_STATE], ST_READY
    je sc_run
    loop sc_scan
    call blocked_count              # nothing can run: finished, or deadlocked?
    test ax, ax
    jz sc_done
    call deadlock
sc_done:
    ret
sc_run:
    mov [cur_idx], bx
    call run_vm
    jmp sc_loop

# run_vm: SI = VCB. Runs one time slice.
run_vm:
    mov [cur_vcb], si
    call load_state
    mov word ptr [quantum_left], QUANTUM
    mov byte ptr [vm_event], 0
rv_step:
    call step
    cmp byte ptr [vm_event], 0
    jne rv_end
    dec word ptr [quantum_left]
    jnz rv_step
rv_end:
    call save_state
    ret

load_state:
    push cs
    pop es
    mov si, [cur_vcb]
    add si, V_R
    mov di, offset g_ax
    mov cx, 14
    rep movsw
    mov si, [cur_vcb]
    mov ax, [si + V_HOST]
    mov [g_host], ax
    mov ax, [si + V_PID]
    mov [g_pid], ax
    ret

save_state:
    push cs
    pop es
    mov di, [cur_vcb]
    add di, V_R
    mov si, offset g_ax
    mov cx, 14
    rep movsw
    ret

blocked_count:                      # -> AX = number of tasks waiting in SEND/RECEIVE
    push bx
    push cx
    push si
    xor ax, ax
    mov cx, [nvm]
    xor bx, bx
bc_lp:
    mov si, bx
    shl si, 1
    mov si, [si + vptr]
    cmp word ptr [si + V_STATE], ST_RECV
    je bc_yes
    cmp word ptr [si + V_STATE], ST_SEND
    jne bc_next
bc_yes:
    inc ax
bc_next:
    inc bx
    loop bc_lp
    pop si
    pop cx
    pop bx
    ret

deadlock:
    xor bx, bx
dl_lp:
    cmp bx, [nvm]
    jae dl_done
    push bx
    mov si, bx
    shl si, 1
    mov si, [si + vptr]
    mov ax, [si + V_STATE]
    cmp ax, ST_RECV
    je dl_blk
    cmp ax, ST_SEND
    jne dl_next
dl_blk:
    mov [cur_vcb], si
    mov ax, [si + V_PID]
    mov [g_pid], ax
    call task_hdr
    mov si, offset s_deadlock
    call ps
    mov si, [cur_vcb]
    mov word ptr [si + V_STATE], ST_DEAD
dl_next:
    pop bx
    inc bx
    jmp dl_lp
dl_done:
    mov byte ptr [exit_code], 2
    ret

# ================================================================ task exit / faults
task_hdr:                           # prints "[oeneye] task N (NAME)"
    mov si, offset s_tag
    call ps
    mov ax, [g_pid]
    call pdec
    mov al, ' '
    call pc
    mov al, '('
    call pc
    mov si, [cur_vcb]
    add si, V_NAME
    call ps
    mov al, ')'
    call pc
    ret

vm_kill:                            # current task ends; blocked partners are woken with an error
    mov si, [cur_vcb]
    mov word ptr [si + V_STATE], ST_DEAD
    call wake_waiters
    mov byte ptr [vm_event], 1
    ret

vm_exit:                            # AL = exit code
    mov si, [cur_vcb]
    xor ah, ah
    mov [si + V_EXIT], ax
    test al, al
    jz ve_quiet
    push ax
    call task_hdr
    mov si, offset s_exited
    call ps
    pop ax
    call pdec
    call crlf
ve_quiet:
    jmp vm_kill

wake_waiters:                       # tasks waiting for the ending task get error 2
    push ax
    push bx
    push cx
    push si
    mov cx, [nvm]
    xor bx, bx
ww_lp:
    mov si, bx
    shl si, 1
    mov si, [si + vptr]
    mov ax, [si + V_STATE]
    cmp ax, ST_SEND
    jne ww_r
    mov ax, [si + V_DEST]
    cmp ax, [g_pid]
    jne ww_next
    jmp ww_wake
ww_r:
    cmp ax, ST_RECV
    jne ww_next
    mov ax, [si + V_FILT]
    cmp ax, [g_pid]
    jne ww_next
ww_wake:
    mov word ptr [si + V_STATE], ST_READY
    mov word ptr [si + V_R], 2
ww_next:
    inc bx
    loop ww_lp
    pop si
    pop cx
    pop bx
    pop ax
    ret

# fault_common: SI = message. Prints "[oeneye] task N (NAME): msg [XX] at CS:IP", ends the task
# and abandons the current instruction.
fault_common:
    push si
    call task_hdr
    mov al, ':'
    call pc
    mov al, ' '
    call pc
    pop si
    call ps
    cmp byte ptr [fa_flag], 0
    je fc_noarg
    mov al, ' '
    call pc
    mov al, [fa_val]
    call phex8
fc_noarg:
    mov si, offset s_at
    call ps
    mov ax, [g_cs]
    call phex16
    mov al, ':'
    call pc
    mov ax, [ip_start]
    call phex16
    call crlf
    mov byte ptr [exit_code], 1
    call vm_kill
unwind:
    mov sp, [step_sp]
    ret

mem_fault:
    mov byte ptr [fa_flag], 0
    mov si, offset s_memf
    jmp fault_common
f_div:
    mov byte ptr [fa_flag], 0
    mov si, offset s_divf
    jmp fault_common
h_bad:
    mov al, [opc]
    mov [fa_val], al
    mov byte ptr [fa_flag], 1
    mov si, offset s_badop
    jmp fault_common

# ================================================================ console helpers (host DOS)
pc:                                 # AL -> console
    push ax
    push dx
    mov dl, al
    mov ah, 2
    int 0x21
    pop dx
    pop ax
    ret

ps:                                 # SI = asciz string
    push ax
    push si
ps_lp:
    lodsb
    test al, al
    jz ps_end
    call pc
    jmp ps_lp
ps_end:
    pop si
    pop ax
    ret

crlf:
    push ax
    mov al, 13
    call pc
    mov al, 10
    call pc
    pop ax
    ret

pdec:                               # AX = unsigned number
    push ax
    push bx
    push cx
    push dx
    xor cx, cx
    mov bx, 10
pd_d:
    xor dx, dx
    div bx
    push dx
    inc cx
    test ax, ax
    jnz pd_d
pd_o:
    pop ax
    add al, '0'
    call pc
    loop pd_o
    pop dx
    pop cx
    pop bx
    pop ax
    ret

phn:
    add al, '0'
    cmp al, '9'
    jbe phn_ok
    add al, 7
phn_ok:
    call pc
    ret

phex8:
    push ax
    shr al, 4
    call phn
    pop ax
    push ax
    and al, 0x0F
    call phn
    pop ax
    ret

phex16:
    push ax
    mov al, ah
    call phex8
    pop ax
    call phex8
    ret

upc:                                # AL -> upper case
    cmp al, 'a'
    jb up_r
    cmp al, 'z'
    ja up_r
    sub al, 32
up_r:
    ret
