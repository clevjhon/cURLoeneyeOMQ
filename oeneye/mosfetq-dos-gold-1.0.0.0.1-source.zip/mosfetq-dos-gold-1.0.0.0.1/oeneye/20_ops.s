# ================================================================ instruction execution
# step: execute one guest instruction (with its prefixes). A handler ends with RET back to run_vm.
step:
    mov [step_sp], sp               # a fault unwinds to here
    mov ax, [g_ip]
    mov [ip_start], ax
    mov byte ptr [p_seg], 0xFF
    mov byte ptr [p_rep], 0
st_next:
    call fetch8
    mov [opc], al
    mov bl, al
    xor bh, bh
    shl bx, 1
    jmp word ptr [bx + optab]

h_ret:
    ret
h_nop:
    ret

h_pf_seg:
    mov al, [opc]
    shr al, 3
    and al, 3
    mov [p_seg], al
    jmp st_next
h_pf_rep:
    mov al, [opc]
    mov [p_rep], al
    jmp st_next
h_pf_lock:
    jmp st_next

set_aop:
    mov al, [opc]
    shr al, 3
    and al, 7
    mov [aop], al
    ret

# ---- ALU: ADD OR ADC SBB AND SUB XOR CMP in all encodings ----
h_alu_rm_r8:
    call modrm
    call set_aop
    call rd_rm8
    mov dl, al
    mov bl, [m_reg]
    call get_r8
    mov bl, al
    mov al, dl
    call alu8
    cmp byte ptr [aop], 7
    je h_ret
    call wr_rm8
    ret
h_alu_rm_r16:
    call modrm
    call set_aop
    call rd_rm16
    mov dx, ax
    mov bl, [m_reg]
    call get_r16
    mov bx, ax
    mov ax, dx
    call alu16
    cmp byte ptr [aop], 7
    je h_ret
    call wr_rm16
    ret
h_alu_r_rm8:
    call modrm
    call set_aop
    mov bl, [m_reg]
    call get_r8
    mov dl, al
    call rd_rm8
    mov bl, al
    mov al, dl
    call alu8
    cmp byte ptr [aop], 7
    je h_ret
    mov bl, [m_reg]
    call set_r8
    ret
h_alu_r_rm16:
    call modrm
    call set_aop
    mov bl, [m_reg]
    call get_r16
    mov dx, ax
    call rd_rm16
    mov bx, ax
    mov ax, dx
    call alu16
    cmp byte ptr [aop], 7
    je h_ret
    mov bl, [m_reg]
    call set_r16
    ret
h_alu_al_imm:
    call set_aop
    call fetch8
    mov bl, al
    mov al, [g_ax]
    call alu8
    cmp byte ptr [aop], 7
    je h_ret
    mov [g_ax], al
    ret
h_alu_ax_imm:
    call set_aop
    call fetch16
    mov bx, ax
    mov ax, [g_ax]
    call alu16
    cmp byte ptr [aop], 7
    je h_ret
    mov [g_ax], ax
    ret

h_grp1_8:                           # 80 / 82
    call modrm
    mov al, [m_reg]
    mov [aop], al
    call rd_rm8
    mov dl, al
    call fetch8
    mov bl, al
    mov al, dl
    call alu8
    cmp byte ptr [aop], 7
    je h_ret
    call wr_rm8
    ret
h_grp1_16:                          # 81
    call modrm
    mov al, [m_reg]
    mov [aop], al
    call rd_rm16
    mov dx, ax
    call fetch16
    mov bx, ax
    mov ax, dx
    call alu16
    cmp byte ptr [aop], 7
    je h_ret
    call wr_rm16
    ret
h_grp1_16s:                         # 83 (sign-extended imm8)
    call modrm
    mov al, [m_reg]
    mov [aop], al
    call rd_rm16
    mov dx, ax
    call fetch8
    cbw
    mov bx, ax
    mov ax, dx
    call alu16
    cmp byte ptr [aop], 7
    je h_ret
    call wr_rm16
    ret

h_test8:
    call modrm
    call rd_rm8
    mov dl, al
    mov bl, [m_reg]
    call get_r8
    mov bl, al
    mov al, dl
    mov byte ptr [aop], 8
    call alu8
    ret
h_test16:
    call modrm
    call rd_rm16
    mov dx, ax
    mov bl, [m_reg]
    call get_r16
    mov bx, ax
    mov ax, dx
    mov byte ptr [aop], 8
    call alu16
    ret
h_test_al_imm:
    call fetch8
    mov bl, al
    mov al, [g_ax]
    mov byte ptr [aop], 8
    call alu8
    ret
h_test_ax_imm:
    call fetch16
    mov bx, ax
    mov ax, [g_ax]
    mov byte ptr [aop], 8
    call alu16
    ret

# ---- INC / DEC / stack ----
h_incdec_r16:
    mov bl, [opc]
    and bl, 7
    call get_r16
    mov byte ptr [uop], 0
    test byte ptr [opc], 8
    jz idc
    mov byte ptr [uop], 1
idc:
    call un16
    mov bl, [opc]
    and bl, 7
    call set_r16
    ret
h_push_r16:
    mov bl, [opc]
    and bl, 7
    call get_r16
    call gpush
    ret
h_pop_r16:
    call gpop
    mov bl, [opc]
    and bl, 7
    call set_r16
    ret
h_push_seg:
    mov bl, [opc]
    shr bl, 3
    and bl, 3
    xor bh, bh
    shl bx, 1
    mov ax, [bx + g_s]
    call gpush
    ret
h_pop_seg:
    call gpop
    mov bl, [opc]
    shr bl, 3
    and bl, 3
    xor bh, bh
    shl bx, 1
    mov [bx + g_s], ax
    ret
h_pushf:
    mov ax, [g_fl]
    call gpush
    ret
h_popf:
    call gpop
    or ax, 2
    mov [g_fl], ax
    ret

# ---- MOV / XCHG / LEA ----
h_mov_rm_r8:
    call modrm
    mov bl, [m_reg]
    call get_r8
    call wr_rm8
    ret
h_mov_rm_r16:
    call modrm
    mov bl, [m_reg]
    call get_r16
    call wr_rm16
    ret
h_mov_r_rm8:
    call modrm
    call rd_rm8
    mov bl, [m_reg]
    call set_r8
    ret
h_mov_r_rm16:
    call modrm
    call rd_rm16
    mov bl, [m_reg]
    call set_r16
    ret
h_mov_rm_sreg:
    call modrm
    mov bl, [m_reg]
    and bl, 3
    xor bh, bh
    shl bx, 1
    mov ax, [bx + g_s]
    call wr_rm16
    ret
h_mov_sreg_rm:
    call modrm
    mov bl, [m_reg]
    and bl, 3
    cmp bl, 1
    je h_bad                        # MOV CS,x does not exist
    call rd_rm16
    xor bh, bh
    shl bx, 1
    mov [bx + g_s], ax
    ret
h_lea:
    call modrm
    cmp byte ptr [m_mod], 3
    je h_bad
    mov ax, [m_off]
    mov bl, [m_reg]
    call set_r16
    ret
h_pop_rm:
    call modrm
    call gpop
    call wr_rm16
    ret
h_xchg8:
    call modrm
    call rd_rm8
    mov dl, al
    mov bl, [m_reg]
    call get_r8
    call wr_rm8
    mov al, dl
    mov bl, [m_reg]
    call set_r8
    ret
h_xchg16:
    call modrm
    call rd_rm16
    mov dx, ax
    mov bl, [m_reg]
    call get_r16
    call wr_rm16
    mov ax, dx
    mov bl, [m_reg]
    call set_r16
    ret
h_xchg_ax:
    mov bl, [opc]
    and bl, 7
    call get_r16
    mov dx, ax
    mov ax, [g_ax]
    call set_r16
    mov [g_ax], dx
    ret
h_mov_al_m:
    call fetch16
    mov bx, ax
    call seg_dsov
    call rdb
    mov [g_ax], al
    ret
h_mov_ax_m:
    call fetch16
    mov bx, ax
    call seg_dsov
    call rdw
    mov [g_ax], ax
    ret
h_mov_m_al:
    call fetch16
    mov bx, ax
    call seg_dsov
    mov al, [g_ax]
    call wrb
    ret
h_mov_m_ax:
    call fetch16
    mov bx, ax
    call seg_dsov
    mov ax, [g_ax]
    call wrw
    ret
h_mov_r8_imm:
    call fetch8
    mov bl, [opc]
    and bl, 7
    call set_r8
    ret
h_mov_r16_imm:
    call fetch16
    mov bl, [opc]
    and bl, 7
    call set_r16
    ret
h_mov_rm_imm8:
    call modrm
    call fetch8
    call wr_rm8
    ret
h_mov_rm_imm16:
    call modrm
    call fetch16
    call wr_rm16
    ret
h_les:
    call modrm
    cmp byte ptr [m_mod], 3
    je h_bad
    call ea_load
    call rdw
    mov [t1], ax
    add bx, 2
    call rdw
    mov [t2], ax
    mov ax, [t1]
    mov bl, [m_reg]
    call set_r16
    mov ax, [t2]
    test byte ptr [opc], 1
    jnz les_ds
    mov [g_es], ax
    ret
les_ds:
    mov [g_ds], ax
    ret
h_xlat:
    mov al, [g_ax]
    xor ah, ah
    add ax, [g_bx]
    mov bx, ax
    call seg_dsov
    call rdb
    mov [g_ax], al
    ret

h_cbw:
    mov al, [g_ax]
    cbw
    mov [g_ax], ax
    ret
h_cwd:
    mov ax, [g_ax]
    cwd
    mov [g_dx], dx
    ret
h_lahf:
    mov al, [g_fl]
    mov [g_ax + 1], al
    ret
h_sahf:
    mov al, [g_ax + 1]
    and al, 0xD5
    or al, 2
    mov [g_fl], al
    ret
h_cmc:
    xor word ptr [g_fl], 1
    ret
h_clc:
    and word ptr [g_fl], 0xFFFE
    ret
h_stc:
    or word ptr [g_fl], 1
    ret
h_cli:
    and word ptr [g_fl], 0xFDFF
    ret
h_sti:
    or word ptr [g_fl], 0x0200
    ret
h_cld:
    and word ptr [g_fl], 0xFBFF
    ret
h_std:
    or word ptr [g_fl], 0x0400
    ret
h_hlt:
    xor al, al
    call vm_exit
    ret

# ---- control flow ----
h_jcc:
    call fetch8
    cbw
    mov cx, ax
    mov al, [opc]
    and al, 15
    call cond_eval
    jz h_ret
    add [g_ip], cx
    ret
h_jmp_short:
    call fetch8
    cbw
    add [g_ip], ax
    ret
h_jmp:
    call fetch16
    add [g_ip], ax
    ret
h_call:
    call fetch16
    mov cx, ax
    mov ax, [g_ip]
    call gpush
    add [g_ip], cx
    ret
h_ret_near:
    call gpop
    mov [g_ip], ax
    ret
h_ret_imm:
    call fetch16
    mov cx, ax
    call gpop
    mov [g_ip], ax
    add [g_sp], cx
    ret
h_retf:
    call gpop
    mov [g_ip], ax
    call gpop
    mov [g_cs], ax
    ret
h_retf_imm:
    call fetch16
    mov cx, ax
    call gpop
    mov [g_ip], ax
    call gpop
    mov [g_cs], ax
    add [g_sp], cx
    ret
h_call_far:
    call fetch16
    mov [t1], ax
    call fetch16
    mov [t2], ax
    jmp far_call_go
h_jmp_far:
    call fetch16
    mov [t1], ax
    call fetch16
    mov [t2], ax
    jmp far_jmp_go
far_call_go:
    mov ax, [g_cs]
    call gpush
    mov ax, [g_ip]
    call gpush
far_jmp_go:
    mov ax, [t1]
    mov [g_ip], ax
    mov ax, [t2]
    mov [g_cs], ax
    ret
h_iret:
    call gpop
    mov [g_ip], ax
    call gpop
    mov [g_cs], ax
    call gpop
    or ax, 2
    mov [g_fl], ax
    ret
h_loop:
    call fetch8
    cbw
    dec word ptr [g_cx]
    jz h_ret
    add [g_ip], ax
    ret
h_loope:
    call fetch8
    cbw
    dec word ptr [g_cx]
    jz h_ret
    test byte ptr [g_fl], 0x40
    jz h_ret
    add [g_ip], ax
    ret
h_loopne:
    call fetch8
    cbw
    dec word ptr [g_cx]
    jz h_ret
    test byte ptr [g_fl], 0x40
    jnz h_ret
    add [g_ip], ax
    ret
h_jcxz:
    call fetch8
    cbw
    cmp word ptr [g_cx], 0
    jne h_ret
    add [g_ip], ax
    ret
h_0f:                               # 386 near conditional jump: 0F 8x rel16 (what the assembler emits for far targets)
    call fetch8
    cmp al, 0x80
    jb h_0f_bad
    cmp al, 0x8F
    ja h_0f_bad
    mov [opc], al
    call fetch16
    mov cx, ax
    mov al, [opc]
    and al, 15
    call cond_eval
    jz h_ret
    add [g_ip], cx
    ret
h_0f_bad:
    mov byte ptr [opc], 0x0F
    jmp h_bad

h_int:
    call fetch8
    cmp al, 0x21
    je do_int21
    cmp al, 0x20
    je do_int20
    cmp al, 0x60
    je do_int60
    cmp al, 0x48
    je do_int48
    mov [fa_val], al
    mov byte ptr [fa_flag], 1
    mov si, offset s_int
    jmp fault_common

# ---- shifts and rotates ----
h_sh8_1:
    call modrm
    mov byte ptr [sh_cnt], 1
    jmp sh8_go
h_sh8_cl:
    call modrm
    mov al, [g_cx]
    mov [sh_cnt], al
    jmp sh8_go
h_sh8_imm:
    call modrm
    call fetch8
    mov [sh_cnt], al
sh8_go:
    call rd_rm8
    call shift8
    call wr_rm8
    ret
h_sh16_1:
    call modrm
    mov byte ptr [sh_cnt], 1
    jmp sh16_go
h_sh16_cl:
    call modrm
    mov al, [g_cx]
    mov [sh_cnt], al
    jmp sh16_go
h_sh16_imm:
    call modrm
    call fetch8
    mov [sh_cnt], al
sh16_go:
    call rd_rm16
    call shift16
    call wr_rm16
    ret

# ---- F6 / F7: TEST NOT NEG MUL IMUL DIV IDIV ----
h_grp3_8:
    call modrm
    mov al, [m_reg]
    cmp al, 2
    jb g3t8
    je g3n8
    cmp al, 3
    je g3g8
    cmp al, 4
    je g3mul8
    cmp al, 5
    je g3imul8
    cmp al, 6
    je g3div8
    jmp g3idiv8
g3t8:
    call rd_rm8
    mov dl, al
    call fetch8
    mov bl, al
    mov al, dl
    mov byte ptr [aop], 8
    call alu8
    ret
g3n8:
    mov byte ptr [uop], 2
    jmp g3un8
g3g8:
    mov byte ptr [uop], 3
g3un8:
    call rd_rm8
    call un8
    call wr_rm8
    ret
g3mul8:
    call rd_rm8
    mov bl, al
    mov al, [g_ax]
    mov si, offset m8_mul
    jmp g3mul8_go
g3imul8:
    call rd_rm8
    mov bl, al
    mov al, [g_ax]
    mov si, offset m8_imul
g3mul8_go:
    mov word ptr [nmask], 0x0801
    call nat
    mov [g_ax], ax
    ret
g3div8:
    call rd_rm8
    mov bl, al
    mov ax, [g_ax]
    test bl, bl
    jz f_div
    cmp ah, bl
    jae f_div
    mov si, offset m8_div
    jmp g3div8_go
g3idiv8:
    call rd_rm8
    mov bl, al
    mov ax, [g_ax]
    call idiv_chk8
    jc f_div
    mov si, offset m8_idiv
g3div8_go:
    mov word ptr [nmask], 0
    call nat
    mov [g_ax], ax
    ret

h_grp3_16:
    call modrm
    mov al, [m_reg]
    cmp al, 2
    jb g3t16
    je g3n16
    cmp al, 3
    je g3g16
    cmp al, 4
    je g3mul16
    cmp al, 5
    je g3imul16
    cmp al, 6
    je g3div16
    jmp g3idiv16
g3t16:
    call rd_rm16
    mov dx, ax
    call fetch16
    mov bx, ax
    mov ax, dx
    mov byte ptr [aop], 8
    call alu16
    ret
g3n16:
    mov byte ptr [uop], 2
    jmp g3un16
g3g16:
    mov byte ptr [uop], 3
g3un16:
    call rd_rm16
    call un16
    call wr_rm16
    ret
g3mul16:
    call rd_rm16
    mov bx, ax
    mov ax, [g_ax]
    mov si, offset m16_mul
    jmp g3mul16_go
g3imul16:
    call rd_rm16
    mov bx, ax
    mov ax, [g_ax]
    mov si, offset m16_imul
g3mul16_go:
    mov word ptr [nmask], 0x0801
    call nat
    mov [g_ax], ax
    mov [g_dx], dx
    ret
g3div16:
    call rd_rm16
    mov bx, ax
    mov ax, [g_ax]
    mov dx, [g_dx]
    test bx, bx
    jz f_div
    cmp dx, bx
    jae f_div
    mov si, offset m16_div
    jmp g3div16_go
g3idiv16:
    call rd_rm16
    mov bx, ax
    mov ax, [g_ax]
    mov dx, [g_dx]
    call idiv_chk16
    jc f_div
    mov si, offset m16_idiv
g3div16_go:
    mov word ptr [nmask], 0
    call nat
    mov [g_ax], ax
    mov [g_dx], dx
    ret

# ---- FE / FF ----
h_grp4:
    call modrm
    mov al, [m_reg]
    cmp al, 1
    ja h_bad
    mov [uop], al
    call rd_rm8
    call un8
    call wr_rm8
    ret
h_grp5:
    call modrm
    mov al, [m_reg]
    cmp al, 0
    je g5_inc
    cmp al, 1
    je g5_dec
    cmp al, 2
    je g5_call
    cmp al, 3
    je g5_callf
    cmp al, 4
    je g5_jmp
    cmp al, 5
    je g5_jmpf
    cmp al, 6
    je g5_push
    jmp h_bad
g5_inc:
    mov byte ptr [uop], 0
    jmp g5_un
g5_dec:
    mov byte ptr [uop], 1
g5_un:
    call rd_rm16
    call un16
    call wr_rm16
    ret
g5_call:
    call rd_rm16
    mov cx, ax
    mov ax, [g_ip]
    call gpush
    mov [g_ip], cx
    ret
g5_jmp:
    call rd_rm16
    mov [g_ip], ax
    ret
g5_push:
    call rd_rm16
    call gpush
    ret
g5_callf:
    call g5_farptr
    jmp far_call_go
g5_jmpf:
    call g5_farptr
    jmp far_jmp_go
g5_farptr:                          # far pointer at the memory operand -> t1 (offset), t2 (segment)
    cmp byte ptr [m_mod], 3
    je h_bad
    call ea_load
    call rdw
    mov [t1], ax
    add bx, 2
    call rdw
    mov [t2], ax
    ret

# ---- string instructions (one iteration per step: REP is interruptible, like the real 8086) ----
sdelta:
    mov al, [opc]
    and al, 1
    inc al
    xor ah, ah
    mov [ssz], ax
    test word ptr [g_fl], 0x0400
    jz sdl_ok
    neg ax
sdl_ok:
    mov [sdel], ax
    ret

rep_go:                             # REP: CX != 0 ? -> True in ZF=0
    cmp byte ptr [p_rep], 0
    je rg_yes
    cmp word ptr [g_cx], 0
    je rg_no
rg_yes:
    or al, 1                        # ZF=0
    ret
rg_no:
    xor al, al                      # ZF=1
    ret

rep_tail:                           # MOVS / STOS / LODS
    cmp byte ptr [p_rep], 0
    je h_ret
    dec word ptr [g_cx]
    jz h_ret
    mov ax, [ip_start]
    mov [g_ip], ax
    ret

rep_tail_z:                         # CMPS / SCAS: REPE (F3) continues while ZF=1, REPNE (F2) while ZF=0
    cmp byte ptr [p_rep], 0
    je h_ret
    dec word ptr [g_cx]
    jz h_ret
    mov al, [g_fl]
    and al, 0x40
    cmp byte ptr [p_rep], 0xF3
    je rtz_e
    test al, al
    jnz h_ret
    jmp rtz_again
rtz_e:
    test al, al
    jz h_ret
rtz_again:
    mov ax, [ip_start]
    mov [g_ip], ax
    ret

h_movs:
    call rep_go
    jz h_ret
    call sdelta
    call seg_dsov
    mov bx, [g_si]
    cmp word ptr [ssz], 1
    jne mv_w
    call rdb
    mov bx, [g_di]
    mov dx, [g_es]
    call wrb
    jmp mv_fin
mv_w:
    call rdw
    mov bx, [g_di]
    mov dx, [g_es]
    call wrw
mv_fin:
    mov ax, [sdel]
    add [g_si], ax
    add [g_di], ax
    jmp rep_tail

h_stos:
    call rep_go
    jz h_ret
    call sdelta
    mov bx, [g_di]
    mov dx, [g_es]
    cmp word ptr [ssz], 1
    jne st_w
    mov al, [g_ax]
    call wrb
    jmp st_fin
st_w:
    mov ax, [g_ax]
    call wrw
st_fin:
    mov ax, [sdel]
    add [g_di], ax
    jmp rep_tail

h_lods:
    call rep_go
    jz h_ret
    call sdelta
    call seg_dsov
    mov bx, [g_si]
    cmp word ptr [ssz], 1
    jne ld_w
    call rdb
    mov [g_ax], al
    jmp ld_fin
ld_w:
    call rdw
    mov [g_ax], ax
ld_fin:
    mov ax, [sdel]
    add [g_si], ax
    jmp rep_tail

h_scas:
    call rep_go
    jz h_ret
    call sdelta
    mov bx, [g_di]
    mov dx, [g_es]
    mov byte ptr [aop], 7
    cmp word ptr [ssz], 1
    jne sc_w
    call rdb
    mov bl, al
    mov al, [g_ax]
    call alu8
    jmp sc_fin
sc_w:
    call rdw
    mov bx, ax
    mov ax, [g_ax]
    call alu16
sc_fin:
    mov ax, [sdel]
    add [g_di], ax
    jmp rep_tail_z

h_cmps:
    call rep_go
    jz h_ret
    call sdelta
    call seg_dsov
    mov bx, [g_si]
    mov byte ptr [aop], 7
    cmp word ptr [ssz], 1
    jne cm_w
    call rdb
    mov [t1], ax
    mov bx, [g_di]
    mov dx, [g_es]
    call rdb
    mov bl, al
    mov al, [t1]
    call alu8
    jmp cm_fin
cm_w:
    call rdw
    mov [t1], ax
    mov bx, [g_di]
    mov dx, [g_es]
    call rdw
    mov bx, ax
    mov ax, [t1]
    call alu16
cm_fin:
    mov ax, [sdel]
    add [g_si], ax
    add [g_di], ax
    jmp rep_tail_z
