# ================================================================ guest memory
# A guest sees a 1 MB address space, but only the 64 KB at linear 10000h-1FFFFh (segment 1000h)
# exists: it maps to the task's private window. Anything else is a memory fault.

# xlat: DX = guest segment, BX = guest offset -> ES:BX = host address. CF=1 if outside the window.
xlat:
    push ax
    push cx
    mov ax, dx
    shl ax, 4
    add ax, bx                      # low 16 bits of the linear address
    sbb cx, cx                      # CX = -carry
    mov bx, ax
    mov ax, dx
    shr ax, 12
    sub ax, cx                      # high nibble (+carry)
    cmp ax, 1
    jne xl_fault
    mov ax, [g_host]
    mov es, ax
    clc
    jmp xl_out
xl_fault:
    stc
xl_out:
    pop cx
    pop ax
    ret

rdb:                                # DX:BX -> AL
    push bx
    push es
    call xlat
    jc mem_fault
    mov al, es:[bx]
    pop es
    pop bx
    ret

rdw:                                # DX:BX -> AX
    push bx
    push es
    call xlat
    jc mem_fault
    mov ax, es:[bx]
    pop es
    pop bx
    ret

wrb:                                # AL -> DX:BX
    push bx
    push es
    call xlat
    jc mem_fault
    mov es:[bx], al
    pop es
    pop bx
    ret

wrw:                                # AX -> DX:BX
    push bx
    push es
    call xlat
    jc mem_fault
    mov es:[bx], ax
    pop es
    pop bx
    ret

fetch8:                             # next instruction byte -> AL
    push bx
    push dx
    push es
    mov dx, [g_cs]
    mov bx, [g_ip]
    call xlat
    jc mem_fault
    mov al, es:[bx]
    inc word ptr [g_ip]
    pop es
    pop dx
    pop bx
    ret

fetch16:                            # -> AX (clobbers CL)
    call fetch8
    mov cl, al
    call fetch8
    mov ah, al
    mov al, cl
    ret

gpush:                              # AX -> guest stack
    push bx
    push dx
    sub word ptr [g_sp], 2
    mov bx, [g_sp]
    mov dx, [g_ss]
    call wrw
    pop dx
    pop bx
    ret

gpop:                               # guest stack -> AX
    push bx
    push dx
    mov bx, [g_sp]
    mov dx, [g_ss]
    call rdw
    add word ptr [g_sp], 2
    pop dx
    pop bx
    ret

# ================================================================ registers
get_r8:                             # BL = 0-7 (AL CL DL BL AH CH DH BH) -> AL (preserves BX)
    push bx
    test bl, 4
    jnz gr8_hi
    and bx, 3
    shl bx, 1
    mov ax, [bx + g_r]
    pop bx
    ret
gr8_hi:
    and bx, 3
    shl bx, 1
    mov ax, [bx + g_r]
    mov al, ah
    pop bx
    ret

set_r8:                             # AL -> register BL
    push bx
    test bl, 4
    jnz sr8_hi
    and bx, 3
    shl bx, 1
    mov [bx + g_r], al
    pop bx
    ret
sr8_hi:
    and bx, 3
    shl bx, 1
    mov [bx + g_r + 1], al
    pop bx
    ret

get_r16:                            # BL = 0-7 -> AX
    push bx
    and bx, 7
    shl bx, 1
    mov ax, [bx + g_r]
    pop bx
    ret

set_r16:                            # AX -> register BL
    push bx
    and bx, 7
    shl bx, 1
    mov [bx + g_r], ax
    pop bx
    ret

# ================================================================ ModRM
# modrm decodes the ModRM byte (and displacement): m_reg, m_mod, m_rm, and for memory operands
# m_sidx (0=ES 1=CS 2=SS 3=DS, after segment override) and m_off.
modrm:
    call fetch8
    mov ah, al
    and al, 7
    mov [m_rm], al
    mov al, ah
    shr al, 3
    and al, 7
    mov [m_reg], al
    mov al, ah
    shr al, 6
    mov [m_mod], al
    cmp al, 3
    je mm_ret
    mov byte ptr [m_sidx], 3
    mov al, [m_rm]
    cmp al, 0
    jne mo1
    mov ax, [g_bx]
    add ax, [g_si]
    jmp mm_disp
mo1:
    cmp al, 1
    jne mo2
    mov ax, [g_bx]
    add ax, [g_di]
    jmp mm_disp
mo2:
    cmp al, 2
    jne mo3
    mov ax, [g_bp]
    add ax, [g_si]
    mov byte ptr [m_sidx], 2
    jmp mm_disp
mo3:
    cmp al, 3
    jne mo4
    mov ax, [g_bp]
    add ax, [g_di]
    mov byte ptr [m_sidx], 2
    jmp mm_disp
mo4:
    cmp al, 4
    jne mo5
    mov ax, [g_si]
    jmp mm_disp
mo5:
    cmp al, 5
    jne mo6
    mov ax, [g_di]
    jmp mm_disp
mo6:
    cmp al, 6
    jne mo7
    cmp byte ptr [m_mod], 0
    jne mm6b
    call fetch16                    # [disp16]
    jmp mm_done
mm6b:
    mov ax, [g_bp]
    mov byte ptr [m_sidx], 2
    jmp mm_disp
mo7:
    mov ax, [g_bx]
mm_disp:
    cmp byte ptr [m_mod], 1
    jne mm_d2
    push ax
    call fetch8
    cbw
    mov cx, ax
    pop ax
    add ax, cx
    jmp mm_done
mm_d2:
    cmp byte ptr [m_mod], 2
    jne mm_done
    push ax
    call fetch16
    mov cx, ax
    pop ax
    add ax, cx
mm_done:
    mov [m_off], ax
    mov al, [p_seg]
    cmp al, 0xFF
    je mm_ret
    mov [m_sidx], al
mm_ret:
    ret

ea_load:                            # -> DX:BX = segment:offset of the memory operand (AX preserved)
    push ax
    mov bl, [m_sidx]
    xor bh, bh
    shl bx, 1
    mov dx, [bx + g_s]
    mov bx, [m_off]
    pop ax
    ret

seg_dsov:                           # DX = segment value: the override, else DS (preserves AX, BX)
    push bx
    mov bl, [p_seg]
    cmp bl, 0xFF
    jne sd_ok
    mov bl, 3
sd_ok:
    xor bh, bh
    shl bx, 1
    mov dx, [bx + g_s]
    pop bx
    ret

rd_rm8:                             # operand -> AL (all other registers preserved)
    push bx
    push dx
    cmp byte ptr [m_mod], 3
    jne r8_mem
    mov bl, [m_rm]
    call get_r8
    jmp r8_out
r8_mem:
    call ea_load
    call rdb
r8_out:
    pop dx
    pop bx
    ret

rd_rm16:
    push bx
    push dx
    cmp byte ptr [m_mod], 3
    jne r16_mem
    mov bl, [m_rm]
    call get_r16
    jmp r16_out
r16_mem:
    call ea_load
    call rdw
r16_out:
    pop dx
    pop bx
    ret

wr_rm8:                             # AL -> operand
    push bx
    push dx
    cmp byte ptr [m_mod], 3
    jne w8_mem
    mov bl, [m_rm]
    call set_r8
    jmp w8_out
w8_mem:
    call ea_load
    call wrb
w8_out:
    pop dx
    pop bx
    ret

wr_rm16:
    push bx
    push dx
    cmp byte ptr [m_mod], 3
    jne w16_mem
    mov bl, [m_rm]
    call set_r16
    jmp w16_out
w16_mem:
    call ea_load
    call wrw
w16_out:
    pop dx
    pop bx
    ret

# ================================================================ native execution
# nat: run the stub whose address is in SI with the guest's arithmetic flags loaded into the real
# CPU, then merge the flag bits selected by [nmask] back into the guest flags. Clobbers SI, DI.
nat:
    mov di, [g_fl]
    and di, FLMASK
    or di, 0x0200
    push di
    popf
    call si
    pushf
    pop di
    mov si, [nmask]
    and di, si
    not si
    and [g_fl], si
    or [g_fl], di
    ret

alu8:                               # [aop] = 0-7 (ADD OR ADC SBB AND SUB XOR CMP) or 8 (TEST); AL op BL -> AL
    push cx
    push si
    push di
    mov cl, [aop]
    xor ch, ch
    mov si, cx
    shl si, 1
    mov si, [si + alu8_tab]
    mov word ptr [nmask], FLMASK
    call nat
    pop di
    pop si
    pop cx
    ret

alu16:                              # AX op BX -> AX
    push cx
    push si
    push di
    mov cl, [aop]
    xor ch, ch
    mov si, cx
    shl si, 1
    mov si, [si + alu16_tab]
    mov word ptr [nmask], FLMASK
    call nat
    pop di
    pop si
    pop cx
    ret

un8:                                # [uop] = 0 INC, 1 DEC, 2 NOT, 3 NEG: AL -> AL
    push bx
    push si
    push di
    mov bl, [uop]
    xor bh, bh
    mov si, bx
    shl si, 1
    mov bx, [si + un_mask]
    mov [nmask], bx
    mov si, [si + un8_tab]
    call nat
    pop di
    pop si
    pop bx
    ret

un16:
    push bx
    push si
    push di
    mov bl, [uop]
    xor bh, bh
    mov si, bx
    shl si, 1
    mov bx, [si + un_mask]
    mov [nmask], bx
    mov si, [si + un16_tab]
    call nat
    pop di
    pop si
    pop bx
    ret

shift8:                             # [m_reg] = ROL ROR RCL RCR SHL SHR SAL SAR, count in [sh_cnt]: AL -> AL
    push bx
    push cx
    push si
    push di
    mov cl, [sh_cnt]
    mov bl, [m_reg]
    xor bh, bh
    shl bx, 1
    mov si, [bx + sh8_tab]
    mov word ptr [nmask], FLMASK
    call nat
    pop di
    pop si
    pop cx
    pop bx
    ret

shift16:
    push bx
    push cx
    push si
    push di
    mov cl, [sh_cnt]
    mov bl, [m_reg]
    xor bh, bh
    shl bx, 1
    mov si, [bx + sh16_tab]
    mov word ptr [nmask], FLMASK
    call nat
    pop di
    pop si
    pop cx
    pop bx
    ret

cond_eval:                          # AL = condition 0-15 -> ZF=0 if it holds
    push bx
    push cx
    push dx
    mov cl, al
    shr al, 1
    xor ah, ah
    mov bx, [g_fl]
    cmp al, 0
    je ce_o
    cmp al, 1
    je ce_c
    cmp al, 2
    je ce_z
    cmp al, 3
    je ce_be
    cmp al, 4
    je ce_s
    cmp al, 5
    je ce_p
    cmp al, 6
    je ce_l
    mov ax, bx                      # 7: LE = ZF or (SF != OF)
    shr ax, 7
    mov dx, bx
    shr dx, 11
    xor ax, dx
    and ax, 1
    mov dx, bx
    and dx, 0x40
    or ax, dx
    jmp ce_inv
ce_o:
    mov ax, bx
    and ax, 0x0800
    jmp ce_inv
ce_c:
    mov ax, bx
    and ax, 1
    jmp ce_inv
ce_z:
    mov ax, bx
    and ax, 0x40
    jmp ce_inv
ce_be:
    mov ax, bx
    and ax, 0x41
    jmp ce_inv
ce_s:
    mov ax, bx
    and ax, 0x80
    jmp ce_inv
ce_p:
    mov ax, bx
    and ax, 4
    jmp ce_inv
ce_l:
    mov ax, bx
    shr ax, 7
    mov dx, bx
    shr dx, 11
    xor ax, dx
    and ax, 1
ce_inv:
    test cl, 1
    jz ce_out
    test ax, ax
    jz ce_inv1
    xor ax, ax
    jmp ce_out
ce_inv1:
    mov ax, 1
ce_out:
    test ax, ax
    pop dx
    pop cx
    pop bx
    ret

# signed-division overflow checks (a real IDIV that overflows would raise INT 0 on the host)
idiv_chk8:                          # AX / BL -> CF=1 if it would overflow or BL = 0
    push ax
    push bx
    push dx
    xor dl, dl
    test ah, 0x80
    jz ic8_a
    neg ax
    xor dl, 1
ic8_a:
    test bl, 0x80
    jz ic8_b
    neg bl
    xor dl, 1
ic8_b:
    test bl, bl
    jz ic8_bad
    cmp ah, bl
    jae ic8_bad
    div bl
    cmp al, 0x80
    ja ic8_bad
    jb ic8_ok
    test dl, 1
    jz ic8_bad
ic8_ok:
    clc
    jmp ic8_out
ic8_bad:
    stc
ic8_out:
    pop dx
    pop bx
    pop ax
    ret

idiv_chk16:                         # DX:AX / BX
    push ax
    push bx
    push cx
    push dx
    xor cl, cl
    test dh, 0x80
    jz ic16_a
    neg dx
    neg ax
    sbb dx, 0
    xor cl, 1
ic16_a:
    test bh, 0x80
    jz ic16_b
    neg bx
    xor cl, 1
ic16_b:
    test bx, bx
    jz ic16_bad
    cmp dx, bx
    jae ic16_bad
    div bx
    cmp ax, 0x8000
    ja ic16_bad
    jb ic16_ok
    test cl, 1
    jz ic16_bad
ic16_ok:
    clc
    jmp ic16_out
ic16_bad:
    stc
ic16_out:
    pop dx
    pop cx
    pop bx
    pop ax
    ret
