# ================================================================ native stubs
alu8_tab:
    .word a8_add, a8_or, a8_adc, a8_sbb, a8_and, a8_sub, a8_xor, a8_cmp, a8_test
alu16_tab:
    .word a16_add, a16_or, a16_adc, a16_sbb, a16_and, a16_sub, a16_xor, a16_cmp, a16_test
a8_add:  add al, bl
    ret
a8_or:   or al, bl
    ret
a8_adc:  adc al, bl
    ret
a8_sbb:  sbb al, bl
    ret
a8_and:  and al, bl
    ret
a8_sub:  sub al, bl
    ret
a8_xor:  xor al, bl
    ret
a8_cmp:  cmp al, bl
    ret
a8_test: test al, bl
    ret
a16_add: add ax, bx
    ret
a16_or:  or ax, bx
    ret
a16_adc: adc ax, bx
    ret
a16_sbb: sbb ax, bx
    ret
a16_and: and ax, bx
    ret
a16_sub: sub ax, bx
    ret
a16_xor: xor ax, bx
    ret
a16_cmp: cmp ax, bx
    ret
a16_test: test ax, bx
    ret

un_mask:  .word 0x08D4, 0x08D4, 0x0000, FLMASK
un8_tab:  .word u8_inc, u8_dec, u8_not, u8_neg
un16_tab: .word u16_inc, u16_dec, u16_not, u16_neg
u8_inc:  inc al
    ret
u8_dec:  dec al
    ret
u8_not:  not al
    ret
u8_neg:  neg al
    ret
u16_inc: inc ax
    ret
u16_dec: dec ax
    ret
u16_not: not ax
    ret
u16_neg: neg ax
    ret

sh8_tab:  .word s8_rol, s8_ror, s8_rcl, s8_rcr, s8_shl, s8_shr, s8_shl, s8_sar
sh16_tab: .word s16_rol, s16_ror, s16_rcl, s16_rcr, s16_shl, s16_shr, s16_shl, s16_sar
s8_rol:  rol al, cl
    ret
s8_ror:  ror al, cl
    ret
s8_rcl:  rcl al, cl
    ret
s8_rcr:  rcr al, cl
    ret
s8_shl:  shl al, cl
    ret
s8_shr:  shr al, cl
    ret
s8_sar:  sar al, cl
    ret
s16_rol: rol ax, cl
    ret
s16_ror: ror ax, cl
    ret
s16_rcl: rcl ax, cl
    ret
s16_rcr: rcr ax, cl
    ret
s16_shl: shl ax, cl
    ret
s16_shr: shr ax, cl
    ret
s16_sar: sar ax, cl
    ret

m8_mul:   mul bl
    ret
m8_imul:  imul bl
    ret
m8_div:   div bl
    ret
m8_idiv:  idiv bl
    ret
m16_mul:  mul bx
    ret
m16_imul: imul bx
    ret
m16_div:  div bx
    ret
m16_idiv: idiv bx
    ret

# ================================================================ data
wintab:   .word 0x3000, 0x4000, 0x5000, 0x6000, 0x7000, 0x8000, 0x9000

s_usage:    .asciz "Usage: OENEYE task [task ...]   (or list the tasks in OENEYE.RC)\r\n"
s_tag:      .asciz "[oeneye] task "
s_exited:   .asciz " exited "
s_deadlock: .asciz ": deadlock - waiting forever\r\n"
s_at:       .asciz " at "
s_memf:     .asciz "memory fault"
s_divf:     .asciz "divide error"
s_badop:    .asciz "illegal or unsupported opcode"
s_int:      .asciz "unsupported INT"
s_nofile:   .asciz "oeneye: cannot open "
s_rderr:    .asciz "oeneye: cannot read "
s_big:      .asciz "oeneye: too big: "
s_empty:    .asciz "oeneye: empty file: "
s_full:     .asciz "oeneye: too many tasks (7 at most)"
s_noargs:   .asciz ""
s_rcname:   .asciz "OENEYE.RC"

# ---- working registers of the running task (same order as the VCB, so they copy in one piece)
g_r:
g_ax:  .word 0
g_cx:  .word 0
g_dx:  .word 0
g_bx:  .word 0
g_sp:  .word 0
g_bp:  .word 0
g_si:  .word 0
g_di:  .word 0
g_s:
g_es:  .word 0
g_cs:  .word 0
g_ss:  .word 0
g_ds:  .word 0
g_ip:  .word 0
g_fl:  .word 0
g_host: .word 0
g_pid:  .word 0

psp_seg:   .word 0
nvm:       .word 0
next_vcb:  .word 0
cur_vcb:   .word 0
cur_idx:   .word 0
quantum_left: .word 0
step_sp:   .word 0
ip_start:  .word 0
tmp16:     .word 0
tokp:      .word 0
argp:      .word 0
rclen:     .word 0
nmask:     .word 0
t1:        .word 0
t2:        .word 0
ssz:       .word 0
sdel:      .word 0
rv_filt:   .word 0
ag_args:   .word 0
ag_vcb:    .word 0
ag_win:    .word 0
ag_h:      .word 0
ag_len:    .word 0
m_off:     .word 0
vm_event:  .byte 0
abort:     .byte 0
exit_code: .byte 0
fa_flag:   .byte 0
fa_val:    .byte 0
p_seg:     .byte 0
p_rep:     .byte 0
opc:       .byte 0
aop:       .byte 0
uop:       .byte 0
sh_cnt:    .byte 0
m_reg:     .byte 0
m_mod:     .byte 0
m_rm:      .byte 0
m_sidx:    .byte 0

vptr:      .space 16
vcbs:      .space MAXVM * VSZ
tail:      .space 130
tele_l:    .space 32
fname:     .space 40
rcbuf:     .space 1004
