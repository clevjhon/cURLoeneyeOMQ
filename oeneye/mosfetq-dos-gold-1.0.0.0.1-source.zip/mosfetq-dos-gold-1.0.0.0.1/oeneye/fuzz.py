#!/usr/bin/env python3
"""Differential fuzzer for oeneye. Generates random 8086 .COM programs; the same program is run natively
under MOSFETQ DOS and as a task under OENEYE. Both runs dump all registers, the flags and a checksum of
a 256-byte data area three times: the outputs must be identical."""
import random, subprocess, tempfile, os, sys

R16 = ["ax", "bx", "cx", "dx", "si", "di"]
R8 = ["al", "cl", "dl", "bl", "ah", "ch", "dh", "bh"]
ALU = ["add", "or", "adc", "sbb", "and", "sub", "xor", "cmp"]
SHF = ["rol", "ror", "rcl", "rcr", "shl", "shr", "sar"]
MEM = ["[bx]", "[bx+si]", "[bx+di]", "[bx+4]", "[bx+si+6]", "[si]", "[di]", "[si+2]", "[bx+di+9]", "[bx+si-3]", "es:[bx]", "cs:[bx+si]", "ss:[bx+di]", "ds:[si+5]", "[bp]", "[bp+si]", "[bp+di+2]", "[bp+8]", "ss:[bp-4]", "es:[bp+si]"]
CC = ["jo", "jno", "jb", "jae", "je", "jne", "jbe", "ja", "js", "jns", "jp", "jnp", "jl", "jge", "jle", "jg"]

class Gen:
    def __init__(self, seed):
        self.r = random.Random(seed); self.n = 0; self.subs = []
    def lab(self): self.n += 1; return f"L{self.n}"
    def imm16(self): return self.r.choice([0, 1, 2, 0x7F, 0x80, 0xFF, 0x7FFF, 0x8000, 0xFFFF, self.r.randrange(65536), self.r.randrange(65536)])
    def imm8(self): return self.r.choice([0, 1, 0x7F, 0x80, 0xFF, self.r.randrange(256), self.r.randrange(256)])
    def reg(self, w, safe=False):
        pool = (["ax", "bx", "dx", "si", "di"] if safe else R16) if w == 16 else (["al", "bl", "dl", "ah", "bh", "dh"] if safe else R8)
        return self.r.choice(pool)
    def memsetup(self):
        return [f"mov bx, offset buf+16", f"mov si, {self.r.randrange(8)}", f"mov di, {self.r.randrange(8)}", "mov bp, offset buf+24"]
    def simple(self, safe):
        """one instruction group (list of lines); 'safe' = no stack, no cx, no jumps: usable inside loops/blocks"""
        r = self.r; w = r.choice([8, 16]); k = r.randrange(16 if safe else 26); sz = "byte" if w == 8 else "word"
        if k == 0: return [f"{r.choice(ALU)} {self.reg(w, safe)}, {self.reg(w, safe)}"]
        if k == 1: return [f"{r.choice(ALU)} {self.reg(w, safe)}, {self.imm8() if w == 8 else self.imm16()}"]
        if k == 2: return self.memsetup() + [f"{r.choice(ALU)} {self.reg(w, safe)}, {sz} ptr {r.choice(MEM)}"]
        if k == 3: return self.memsetup() + [f"{r.choice(ALU)} {sz} ptr {r.choice(MEM)}, {self.reg(w, safe)}"]
        if k == 4: return self.memsetup() + [f"{r.choice(ALU)} {sz} ptr {r.choice(MEM)}, {self.imm8() if w == 8 else self.imm16()}"]
        if k == 5: return [f"{r.choice(['inc', 'dec', 'neg', 'not'])} {self.reg(w, safe)}"]
        if k == 6: return self.memsetup() + [f"{r.choice(['inc', 'dec', 'neg', 'not'])} {sz} ptr {r.choice(MEM)}"]
        if k == 7: return [f"test {self.reg(w, safe)}, {self.reg(w, safe)}"] if r.random() < .5 else [f"test {self.reg(w, safe)}, {self.imm8() if w == 8 else self.imm16()}"]
        if k == 8: return [f"mov {self.reg(w, safe)}, {self.imm8() if w == 8 else self.imm16()}"]
        if k == 9: return [f"mov {self.reg(w, safe)}, {self.reg(w, safe)}"]
        if k == 10: return self.memsetup() + [f"mov {sz} ptr {r.choice(MEM)}, {self.reg(w, safe)}"]
        if k == 11: return self.memsetup() + [f"mov {self.reg(w, safe)}, {sz} ptr {r.choice(MEM)}"]
        if k == 12: return self.memsetup() + [f"mov {sz} ptr {r.choice(MEM)}, {self.imm8() if w == 8 else self.imm16()}"]
        if k == 13: return [f"xchg {self.reg(w, safe)}, {self.reg(w, safe)}"]
        if k == 14:
            op = r.choice(SHF); cnt = r.choice(["1", "cl", "2", "3", "4", "5", "7"]); reg = self.reg(w, safe)
            pre = [f"mov cl, {r.randrange(18)}"] if cnt == "cl" and not safe else []
            if cnt == "cl" and safe: cnt = "1"
            return pre + [f"{op} {reg}, {cnt}"]
        if k == 15:
            return self.memsetup() + [f"{r.choice(SHF)} {sz} ptr {r.choice(MEM)}, {r.choice(['1', '2', '3'])}"]
        # ---- not for tight loops / blocks ----
        if k == 16: return self.memsetup() + [f"lea {self.reg(16)}, {r.choice(MEM).split(':')[-1]}"]
        if k == 17: return [r.choice(["cbw", "cwd", "lahf", "sahf", "cmc", "clc", "stc", "nop"])]
        if k == 18:
            if w == 8:
                d = r.choice(["mul", "imul"]); x = r.choice(["cl", "bl", "dh", "bh"]); return [f"{d} {x}"]
            d = r.choice(["mul", "imul"]); return [f"{d} {r.choice(['cx', 'bx', 'si', 'di'])}"]
        if k == 19:
            if w == 8:
                if r.random() < .5: return ["xor ah, ah", f"mov cl, {r.randrange(1, 256)}", "div cl"]
                return ["cbw", f"mov cl, {r.choice([-100, -37, -2, 2, 3, 50, 99])}", "idiv cl"]
            if r.random() < .5: return ["xor dx, dx", f"mov cx, {r.randrange(1, 65536)}", "div cx"]
            return ["cwd", f"mov cx, {r.choice([-30000, -1000, -2, 2, 7, 1234, 32000])}", "idiv cx"]
        if k == 20:
            a, b = r.choice([("push", "pop"), ("push", "pop")]); x, y = self.reg(16), self.reg(16); return [f"push {x}", f"pop {y}"]
        if k == 21:
            body = [ln for _ in range(r.randrange(1, 4)) for ln in self.simple(True)]
            return ["pushf"] + body + ["popf"]
        if k == 22: return self.memsetup() + [f"push word ptr {r.choice(MEM)}", f"pop {self.reg(16)}"]
        if k == 23: return [f"mov dl, {r.randrange(65, 91)}", "mov ah, 2", "int 0x21"]
        if k == 24: return [r.choice([f"mov al, byte ptr [buf+{r.randrange(200)}]", f"mov ax, word ptr [buf+{r.randrange(200)}]", f"mov byte ptr [buf+{r.randrange(200)}], al", f"mov word ptr [buf+{r.randrange(200)}], ax"])]
        if k == 25: return ["mov bx, offset buf", "xlat"] if r.random() < .5 else ["mov bx, offset buf", "es: xlat"] if False else ["mov bx, offset buf", ".byte 0x26", "xlat"]
    def string(self):
        r = self.r; op = r.choice(["movs", "stos", "lods", "scas", "cmps"]); s = r.choice(["b", "w"]); rep = r.choice(["", "rep ", "repe ", "repne "])
        if op in ("movs", "stos", "lods") and rep in ("repe ", "repne "): rep = "rep "
        pre = ["std" if r.random() < .3 else "cld", "mov si, offset buf+100", "mov di, offset buf+160", f"mov cx, {r.randrange(0, 9)}"]
        seg = [".byte 0x26"] if op in ("movs", "lods", "cmps") and r.random() < .3 else []   # ES: override prefix
        return pre + seg + [f"{rep}{op}{s}", "cld"]
    def item(self):
        r = self.r; k = r.random()
        if k < .58: return self.simple(False)
        if k < .70: return self.string()
        if k < .80:
            lab = self.lab(); body = [ln for _ in range(r.randrange(9, 16) if r.random() < .3 else r.randrange(1, 4)) for ln in self.simple(True)]   # big blocks -> the assembler emits 0F 8x (386 near Jcc)
            return [f"{r.choice(CC)} {lab}"] + body + [f"{lab}:"]
        if k < .87:
            lab = self.lab(); body = [ln for _ in range(r.randrange(1, 3)) for ln in self.simple(True)]
            return [f"mov cx, {r.randrange(1, 5)}", f"{lab}:"] + body + [f"loop {lab}"]
        if k < .90:
            lab = self.lab(); body = [ln for _ in range(r.randrange(1, 3)) for ln in self.simple(True)]
            return [f"mov cx, {r.randrange(1, 5)}", f"{lab}:"] + body + [f"{r.choice(['loope', 'loopne'])} {lab}"]
        if k < .92:
            lab = self.lab(); body = [ln for _ in range(r.randrange(1, 3)) for ln in self.simple(True)]
            return [f"mov cx, {r.choice([0, 1])}", f"jcxz {lab}"] + body + [f"{lab}:"]
        if k < .96:
            name = f"sub{len(self.subs)}"; self.subs.append((name, [ln for _ in range(r.randrange(1, 4)) for ln in self.simple(True)]))
            return [f"call {name}"] if r.random() < .6 else ["mov bx, offset " + name, "call bx"]
        lab = self.lab(); return ["mov bx, offset " + lab, "jmp bx", "add ax, 1", f"{lab}:"]

def program(seed, ninsn=45):
    g = Gen(seed); r = g.r; lines = []
    lines += ["cld", "sti", "xor ax, ax"]   # start-up flags are not defined by DOS: normalise them
    for reg in ["ax", "bx", "cx", "dx", "si", "di", "bp"]: lines.append(f"mov {reg}, {g.imm16()}")
    for i in range(ninsn):
        lines += g.item()
        if i in (ninsn // 3, 2 * ninsn // 3): lines.append("call dump")
    lines += ["call dump", "mov ax, 0x4C00", "int 0x21"]
    for name, body in g.subs: lines += [f"{name}:"] + body + ["ret"]
    lines += DUMP
    lines += ["buf:"] + [".byte " + ", ".join(str(r.randrange(256)) for _ in range(16)) for _ in range(16)]
    lines += ["regs: .space 24"]
    src = ".intel_syntax noprefix\n.code16\n.global _start\n.text\n_start:\n" + "\n".join("    " + l if not l.endswith(":") else l for l in lines) + "\n"
    return src

DUMP = """dump:
mov [regs+0], ax
mov [regs+2], bx
mov [regs+4], cx
mov [regs+6], dx
mov [regs+8], si
mov [regs+10], di
mov [regs+12], bp
pushf
pop ax
mov [regs+20], ax
and ax, 0x08D5
mov [regs+14], ax
mov si, offset buf
mov cx, 256
xor ax, ax
xor dx, dx
xor bx, bx
dcs:
mov bl, [si]
add ax, bx
add dx, ax
inc si
loop dcs
mov [regs+16], ax
mov [regs+18], dx
mov si, offset regs
mov cx, 10
dpr:
lodsw
call hex16
mov dl, 32
mov ah, 2
int 0x21
loop dpr
mov dl, 13
mov ah, 2
int 0x21
mov dl, 10
int 0x21
mov ax, [regs+0]
mov bx, [regs+2]
mov cx, [regs+4]
mov dx, [regs+6]
mov si, [regs+8]
mov di, [regs+10]
mov bp, [regs+12]
push word ptr [regs+20]
popf
ret
hex16:
push cx
mov cx, 4
hx:
rol ax, 4
push ax
and al, 15
add al, 48
cmp al, 57
jbe hd
add al, 7
hd:
mov dl, al
mov ah, 2
int 0x21
pop ax
loop hx
pop cx
ret""".split("\n")

def assemble(src, name="fuzz"):
    d = tempfile.mkdtemp()
    open(f"{d}/{name}.s", "w").write(src)
    subprocess.run(["as", "--32", "-o", f"{d}/{name}.o", f"{d}/{name}.s"], check=True, capture_output=True)
    subprocess.run(["ld", "-m", "elf_i386", "-Ttext=0x100", "--oformat", "binary", "-o", f"{d}/{name}.bin", f"{d}/{name}.o"], check=True, capture_output=True)
    return open(f"{d}/{name}.bin", "rb").read()

if __name__ == "__main__":
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    print(program(seed))
